/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LOGICAL_LORA_CHANNEL_HELPER_H
#define LOGICAL_LORA_CHANNEL_HELPER_H

#include "ns3/object.h"
#include "ns3/logical-lora-channel.h"
#include "ns3/nstime.h"
#include "ns3/packet.h"
#include <list>
#include <iterator>
#include <vector>

namespace ns3 {

  /**
   * This class holds a list of all the logical channels that are currently
   * employed by the network, and establishes their relationship with SubBands.
   * Furthermore, this class contains the logic to compute time on air of a packet.
   */
  class LogicalLoraChannelHelper : public Object
  {
  public:

    static TypeId GetTypeId (void);

    LogicalLoraChannelHelper();
    virtual ~LogicalLoraChannelHelper();

    ////////////////////////////////////////////////////////////////
    // /**
    //  * Get the duty cycle prescribed by the regulation starting from the
    //  * center frequency.
    //  */
    // double GetDutyCycleFromFrequency (double frequency);

    // /**
    //  * Get the subband index based on the channel number
    //  */
    // int GetSubBandFromFrequency (double frequency);

    /**
     * Get the time it is necessary to wait for before transmitting on a given
     * channel.
     * \param packet the packet we need to send
     * \param channel the number of the channel we want to send this packet
     * on
     */
    Time GetWaitingTime (Ptr<LogicalLoraChannel> channel);

    /**
     * Register the transmission of a packet
     */
    void AddEvent (Time duration, Ptr<LogicalLoraChannel> channel);

    /**
     * Return the list of logical lora channels
     */
    std::list<Ptr <LogicalLoraChannel> > GetChannelList (void);

    /**
     * Add a new channel
     * \returns the id of the newly created channel
     * \param frequency the frequency of the channel to create
     * \param bandwidth the bandwidth of the channel to create
     */
    void AddChannel (double frequency, double bandwidth);

    /**
     * Add a new channel
     * \returns the id of the newly created channel
     * \param A pointer to the channel to add
     */
    void AddChannel (Ptr<LogicalLoraChannel> logicalChannel);

    /**
     * Add a new subband
     * \param firstFrequency the first frequency of the subband, in MHz
     * \param lastFrequency the last frequency of the subband, in MHz
     * \param dutyCycle the duty cycle that needs to be enforced on this subband
     */
    void AddSubBand (double firstFrequency, double lastFrequency, double dutyCycle);

    /**
     * Add a new subband
     */
    void AddSubBand (Ptr<SubBand> subBand);

    /**
     * Remove a channel
     * \param channel a pointer to the channel we want to remove
     */
    void RemoveChannel (Ptr<LogicalLoraChannel> channel);

    /**
     * Get the channel with the specified channel number
     * \returns the channel
     */
    std::vector<Ptr<LogicalLoraChannel> > GetLogicalChannels ();

    // TODO: Substitute bandwidth with pointer to channel, and get bandwidth from there.
    Time GetOnAirTime (Ptr<Packet> packet, uint8_t sf, bool headerDisabled,
                       uint8_t cr, double bandwidth, int nPreamble);

  private:
    /**
     * A list of the SubBands that are currently registered within
     * this helper.
     */
    std::list<Ptr <SubBand> > m_subBandList;

    /**
     * A list of the LogicalLoraChannels that are currently registered within
     * this helper.
     */
    std::list<Ptr <LogicalLoraChannel> > m_channelList;
  };
}

#endif /* LOGICAL_LORA_CHANNEL_HELPER_H */
