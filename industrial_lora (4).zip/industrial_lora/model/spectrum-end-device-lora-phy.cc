/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Michele Luvisotto <michele.luvisotto@dei.unipd.it>, Romagnolo Stefano <romagnolostefano93@gmail.com>
 */

#include <algorithm>
#include <cmath>
#include "ns3/simulator.h"
#include "ns3/logical-lora-channel.h"
#include "ns3/lora-tag.h"
#include "ns3/log.h"
#include "ns3/spectrum-end-device-lora-phy.h"
#include "ns3/spectrum-channel.h"
#include "ns3/spectrum-value.h"
#include "ns3/assert.h"
#include "ns3/double.h"
#include "ns3/boolean.h"
#include "ns3/lora-spectrum-signal-parameters.h"
#include "ns3/antenna-model.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("SpectrumEndDeviceLoraPhy");
  
  /*****************************
  *  This destructor is needed.*
  *****************************/

  LoraEndDevicePhyListener::~LoraEndDevicePhyListener ()
  {
  }
  
  /****************************
  *  The actual WifiPhy class *
  ****************************/

  NS_OBJECT_ENSURE_REGISTERED (SpectrumEndDeviceLoraPhy);

  TypeId
  SpectrumEndDeviceLoraPhy::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::SpectrumEndDeviceLoraPhy")
      .SetParent<LoraPhy> ()
      .SetGroupName ("Lora")
      .AddConstructor<SpectrumEndDeviceLoraPhy> ()
      .AddTraceSource ("SignalArrival",
                     "Signal arrival",
                     MakeTraceSourceAccessor (&SpectrumEndDeviceLoraPhy::m_signalCb),
                     "ns3::SpectrumEndDeviceLoraPhy::SignalArrivalCallback")
      .AddTraceSource ("LostPacketBecauseFailedDecoding",
                       "Trace source indicating a packet "
                       "could not be correctly received because"
                       "the SNR is too low for successful decoding",
                       MakeTraceSourceAccessor (&SpectrumEndDeviceLoraPhy::m_failedDecoding),
                       "ns3::Packet::TracedCallback")
    ;
    return tid;
  }

  // Constructor
  SpectrumEndDeviceLoraPhy::SpectrumEndDeviceLoraPhy () :
    //m_state (STANDBY),
    m_state (SLEEP),
    m_txPowerdBm (14) 
  {
    m_logicalChannel = CreateObject<LogicalLoraChannel> (868.1, 0.125);
    m_random = CreateObject<UniformRandomVariable> ();
    m_spectrumInterference.SetNoiseFigure(6);
    NS_LOG_FUNCTION_NOARGS ();
  }

  SpectrumEndDeviceLoraPhy::~SpectrumEndDeviceLoraPhy ()
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  // Downlink sensitivity (from Lebreton)
  // {SF7, SF8, SF9, SF10, SF11, SF12}
  const double SpectrumEndDeviceLoraPhy::sensitivity[6] =
    {-124.5, -127, -129.5, -132, -134.5, -137};

  double
  SpectrumEndDeviceLoraPhy::GetTxPowerdBm ()
  {
    return m_txPowerdBm;
  }

  void
  SpectrumEndDeviceLoraPhy::SetTxPowerdBm (double power)
  {
    m_txPowerdBm = power;
  }

  void
  SpectrumEndDeviceLoraPhy::Send (Ptr<Packet> packet, uint8_t sf, Time duration,
                          Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << packet << unsigned(sf) << duration << logicalChannel);
    
    // DEBUG
    //std::cout << "ED ID: " << LoraPhy::GetDevice()->GetNode()->GetId() << "; ";

    // We must be either in idle or sleep to send a packet
    //NS_ASSERT (m_state == STANDBY || m_state == SLEEP);
    NS_ASSERT (m_state == IDLE|| m_state == SLEEP);

    // Switch to the TX state
    SwitchToTx (duration, GetTxPowerdBm());

    // Tag the packet with information about its Spreading Factor
    uint32_t id = LoraPhy::GetDevice()->GetNode()->GetId();
    
    // DEBUG
    //std::cout << "LoraPhy::GetDevice()->GetNode()->GetId() = " << LoraPhy::GetDevice()->GetNode()->GetId() << std::endl;
    
    //LoraTag tag (sf, id);
    LoraTag tag (sf);
    tag.SetSenderId(id);
    
    // DEBUG
    //std::cout << "spectrum-end-device-lora-phy.cc tag.GetSenderId() = " << tag.GetSenderId() << std::endl;
     
    // DEBUG
    //std::cout << "ED ID using \"tag.GetSenderId()\": " << tag.GetSenderId() << std::endl;
    
    packet->AddPacketTag (tag);
    
    // Obtain non-const Packet
    Ptr<Packet> newPacket = packet->Copy ();    

    // Add spectrum elements and send the packet over the channel
    NS_LOG_INFO ("Sending the packet in the channel");
    NS_LOG_DEBUG ("Transmission signal power before antenna gain: " << GetTxPowerdBm() << " dBm");
    double bandwidthMHz = logicalChannel->GetBandwidth();
    double frequencyMHz = logicalChannel->GetFrequency();
	  double txPowerWatts = (std::pow (10.0, GetTxPowerdBm() / 10.0)) / 1000.0;
    Ptr<SpectrumValue> txPowerSpectrum = GetTxPowerSpectralDensity (frequencyMHz, bandwidthMHz, txPowerWatts);	
	Ptr<LoraSpectrumSignalParameters> txParams = Create<LoraSpectrumSignalParameters> ();
	txParams->duration = duration;
	txParams->psd = txPowerSpectrum;
	txParams->logicalChannel = logicalChannel;
	NS_ASSERT_MSG (m_loraEdSpectrumPhyInterface, "SpectrumPhy() is not set; maybe forgot to call CreateLoraEdSpectrumPhyInterface?");
	txParams->txPhy = m_loraEdSpectrumPhyInterface->GetObject<SpectrumPhy> ();
	txParams->txAntenna = m_antenna;
	txParams->packet = newPacket;
  //std::cout << "PHY: Node " << LoraPhy::GetDevice()->GetNode()->GetId() << " is sending on channel " << logicalChannel->GetFrequency() << ", packet of size " << newPacket->GetSize() << " at time " << Simulator::Now().GetMilliSeconds() << " ms\n";
	NS_LOG_DEBUG ("Starting transmission with integrated spectrum power " << (10.0 * std::log10 ((Integral (*txPowerSpectrum)) * 1000.0)) << " dBm; spectrum model Uid: " << txPowerSpectrum->GetSpectrumModel ()->GetUid ());
	m_spectrumChannel->StartTx (txParams);

    // Schedule the callback, if it was set by an upper layer
    if (!m_txFinishedCallback.IsNull ())
      {
        Simulator::Schedule (duration, &SpectrumEndDeviceLoraPhy::m_txFinishedCallback,
                             this, packet);
      }

	// Callbacks
	m_phyMonitorSniffTxTrace (packet, frequencyMHz, bandwidthMHz, sf);	
	m_startSending (packet);
  }

  void
  SpectrumEndDeviceLoraPhy::StartReceive (Ptr<Packet> packet, double rxPowerDbm, uint8_t
                                  sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel)
  {
	NS_LOG_FUNCTION (this << packet << rxPowerDbm << unsigned(sf) << logicalChannel);

    // Notify the SpectrumLoraInterferenceHelper of the impinging signal, and remember
    // the event it creates. This will be used then to correctly handle the end
    // of reception event.
    Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event;
    event = m_spectrumInterference.Add (duration, rxPowerDbm, sf, packet, logicalChannel);

    // Switch on the current PHY state
    switch (m_state) {
      // In these cases, we cannot receive the packet: we only add it to the
      // list of interferers and do not schedule an EndReceive event for it.
    case SLEEP:
      {
        NS_LOG_INFO ("Dropping packet because device is in SLEEP state");
        break;
      }
    case TX:
      {
        NS_LOG_INFO ("Dropping packet because device is in TX state");
        break;
      }
    case RX:
      {
        NS_LOG_INFO ("Dropping packet because device is already in RX state");
        break;
      }
      // If we are in IDLE mode, we can lock on the current packet.
    case IDLE://case STANDBY:
      {
        // See whether the reception power is above or below the sensitivity for
        // that spreading factor.
        double sensitivity = SpectrumEndDeviceLoraPhy::sensitivity[unsigned(sf)-7];

        if (rxPowerDbm < sensitivity)
          {
            NS_LOG_INFO ("Dropping packet reception of packet with sf = " <<
                         unsigned(sf) << " because under the sensitivity of " <<
                         sensitivity << " dBm");

            // Fire the trace source for this event.
            m_underSensitivity(packet);
          }
        else
          {
            NS_LOG_INFO ("Scheduling reception of a packet");
            
            // Switch to RX state
            m_state = RX;
				  
			// Schedule the end of the reception of the packet
			Simulator::Schedule (duration, &SpectrumEndDeviceLoraPhy::SpectrumEndReceive, this, packet,
                                 event);
              
            // Fire the beginning of reception trace source
			m_phyRxBeginTrace (packet);
          }
      }
    }
  }
  
  void
  SpectrumEndDeviceLoraPhy::EndReceive (Ptr<Packet> packet,
                                Ptr<LoraInterferenceHelper::Event> event)
  {
  }

  void
  SpectrumEndDeviceLoraPhy::SpectrumEndReceive (Ptr<Packet> packet,
                                Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event)
  {
	NS_LOG_FUNCTION (this << packet << event);
	NS_ASSERT (m_state == RX);
	NS_ASSERT (event->GetEndTime () == Simulator::Now ());
	
	// Call the trace source
    m_phyRxEndTrace (packet);

    // Check error probability
	double per = m_spectrumInterference.CalculatePer (event);
	NS_LOG_DEBUG ("PER = " << per);

	if (m_random->GetValue () > per) // decoding succeeded
	  {
		// If there is one, perform the callback to inform the upper layer
        if (!m_rxOkCallback.IsNull ())
          {
            m_rxOkCallback (packet);
          }
        Ptr<LogicalLoraChannel> channel = event->GetLogicalChannel();
		m_phyMonitorSniffRxTrace (packet, channel->GetFrequency(), channel->GetBandwidth(), event->GetSpreadingFactor());	
        
        SwitchToStandby ();         
	  
	  }
	else // decoding failed
	  {
		
		// Fire the trace source for this event.
		m_failedDecoding(packet);
		
		// Handle state
        SwitchToStandby ();
      }

  }

  void
  SpectrumEndDeviceLoraPhy::SetReceiveOkCallback (RxOkCallback callback)
  {
    m_rxOkCallback = callback;
  }

  void
  SpectrumEndDeviceLoraPhy::SetTxFinishedCallback (TxFinishedCallback callback)
  {
    m_txFinishedCallback = callback;
  }

  bool
  SpectrumEndDeviceLoraPhy::IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    // EndDeviceLoraPhys, differently from GatewayLoraPhys, can be only on one
    // channel at a time.

    NS_LOG_DEBUG ("m_logicalChannel: " << m_logicalChannel);

    return m_logicalChannel == logicalChannel;
  }

  void
  SpectrumEndDeviceLoraPhy::SetLogicalChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    m_logicalChannel = logicalChannel;
  }

  void
  SpectrumEndDeviceLoraPhy::SwitchToStandby (void)
  {
    m_state = IDLE;
    for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyStandby ();
    }
    // DEBUG
    //std::cout << "SpectrumEndDeviceLoraPhy::SwitchToStandby: m_state = " << m_state << std::endl;
  }

  void
  SpectrumEndDeviceLoraPhy::SwitchToRx (Time duration)
  {
    m_state = RX;
    for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyRxStart (duration);
    }
    // DEBUG
    //std::cout << "SpectrumEndDeviceLoraPhy::SwitchToRx: m_state = " << m_state << std::endl;
  }

  void
  SpectrumEndDeviceLoraPhy::SwitchToTx (Time duration, double txPowerDbm)
  {
    m_state = TX;
    for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifyTxStart (duration, txPowerDbm);
    }
    // DEBUG
    //std::cout << "SpectrumEndDeviceLoraPhy::SwitchToTx: m_state = " << m_state << std::endl;
  }

  void
  SpectrumEndDeviceLoraPhy::SwitchToSleep (void)
  {
    m_state = SLEEP;
    for (Listeners::const_iterator i = m_listeners.begin (); i != m_listeners.end (); i++)
    {
      (*i)->NotifySleep ();
    }
    // DEBUG
    //std::cout << "SpectrumEndDeviceLoraPhy::SwitchToSleep: m_state = " << m_state << std::endl;
  }
  
  void
  SpectrumEndDeviceLoraPhy::SetChannel (Ptr<SpectrumChannel> channel)
  {
    m_spectrumChannel = channel;
  }
  
  void
  SpectrumEndDeviceLoraPhy::SetPacketReceivedCallback (RxCallback callback)
  {
    m_rxCallback = callback;
  }

  void
  SpectrumEndDeviceLoraPhy::StartRx (Ptr<SpectrumSignalParameters> rxParams)
  {
	NS_LOG_FUNCTION (this << rxParams);
	
	// Recover duration, PSD and node ID
	Time rxDuration = rxParams->duration;
	Ptr<SpectrumValue> receivedSignalPsd = rxParams->psd;
	NS_LOG_DEBUG ("Received signal with PSD " << *receivedSignalPsd << " and duration " << rxDuration.As (Time::NS));
	uint32_t senderNodeId = 0;
	if (rxParams->txPhy)
      {
        senderNodeId = rxParams->txPhy->GetDevice ()->GetNode ()->GetId ();
      }
	NS_LOG_DEBUG ("Received signal from " << senderNodeId << " with unfiltered power " << (10.0 * std::log10 ((Integral (*receivedSignalPsd)) * 1000.0)) << " dBm");
  
	// TO DO: filtering
	double rxPowerW = Integral (*receivedSignalPsd);
	double rxPowerDbm = 10.0 * std::log10 (rxPowerW * 1000.0);
	NS_LOG_DEBUG ("Signal power received: " << rxPowerW << " W (" << rxPowerDbm << " dBm)");
	Ptr<LoraSpectrumSignalParameters> loraRxParams = DynamicCast<LoraSpectrumSignalParameters> (rxParams);

	// Log the signal arrival to the trace source
	m_signalCb (loraRxParams ? true : false, senderNodeId, rxPowerDbm, rxDuration);
	if (loraRxParams == 0)
      {
        NS_LOG_INFO ("Received non LoRa signal");
        m_spectrumInterference.AddForeignSignal (rxDuration, rxPowerW);
        return;
      }
    NS_LOG_INFO ("Received LoRa signal");
	Ptr<Packet> packet = loraRxParams->packet->Copy ();
	LoraTag tag;
	bool found = packet->PeekPacketTag (tag);
	if (!found)
	  {
		NS_FATAL_ERROR ("Received LoRa Spectrum Signal with no LoraTag");
		return;
	  }
	Ptr<LogicalLoraChannel> logicalChannel = loraRxParams->logicalChannel;
	uint8_t sf = tag.GetSpreadingFactor();
	
	// Schedule StartReceive
    Simulator::ScheduleNow (&SpectrumEndDeviceLoraPhy::StartReceive, this,
                                                      packet, rxPowerDbm, sf, rxDuration, logicalChannel);
    return;
  }
  
  Ptr<LoraEndDeviceSpectrumPhyInterface>
  SpectrumEndDeviceLoraPhy::GetSpectrumPhy (void) const
  {
    return m_loraEdSpectrumPhyInterface;
  }

  Ptr<AntennaModel>
  SpectrumEndDeviceLoraPhy::GetRxAntenna (void) const
  {
    return m_antenna;
  }

  void
  SpectrumEndDeviceLoraPhy::SetAntenna (Ptr<AntennaModel> a)
  {
    NS_LOG_FUNCTION (this << a);
    m_antenna = a;
  }

  void
  SpectrumEndDeviceLoraPhy::CreateLoraEdSpectrumPhyInterface (Ptr<NetDevice> device)
  {
    NS_LOG_FUNCTION (this << device);
    m_loraEdSpectrumPhyInterface = CreateObject<LoraEndDeviceSpectrumPhyInterface> ();
    m_loraEdSpectrumPhyInterface->SetSpectrumLoraPhy (this);
    m_loraEdSpectrumPhyInterface->SetDevice (device);
  }
  
  Ptr<SpectrumValue>
  SpectrumEndDeviceLoraPhy::GetTxPowerSpectralDensity (double centerFrequency, double channelWidth, double txPowerW) const
  {
    NS_LOG_FUNCTION (centerFrequency << channelWidth << txPowerW);
    Ptr<SpectrumValue> v = LoraSpectrumValueHelper::CreateLoraTxPowerSpectralDensity (centerFrequency, channelWidth, txPowerW);	
    return v;
  }
  
  void
  SpectrumEndDeviceLoraPhy::SetErrorRateModel (Ptr<LoraErrorRateModel> rate)
  {
    m_spectrumInterference.SetErrorRateModel (rate);
  }

  Ptr<LoraErrorRateModel>
  SpectrumEndDeviceLoraPhy::GetErrorRateModel (void) const
  {
    return m_spectrumInterference.GetErrorRateModel ();
  }
  
  /*
  void
  SpectrumEndDeviceLoraPhy::RegisterListener (LoraEndDevicePhyListener *listener)
  {
    m_state->RegisterListener (listener);
  }

  void
  SpectrumEndDeviceLoraPhy::UnregisterListener (LoraEndDevicePhyListener *listener)
  {
    m_state->UnregisterListener (listener);
  }
  */
  
  void
  SpectrumEndDeviceLoraPhy::RegisterListener (LoraEndDevicePhyListener *listener)
  {
    m_listeners.push_back (listener);
    // DEBUG
    //std::cout << "SpectrumEndDeviceLoraPhy::RegisterListener" << std::endl;
  }

  void
  SpectrumEndDeviceLoraPhy::UnregisterListener (LoraEndDevicePhyListener *listener)
  {
    ListenersI i = find (m_listeners.begin (), m_listeners.end (), listener);
    if (i != m_listeners.end ())
    {
      m_listeners.erase (i);
      // DEBUG
	  //std::cout << "SpectrumEndDeviceLoraPhy::UnregisterListener" << std::endl;
    }
  }

}
