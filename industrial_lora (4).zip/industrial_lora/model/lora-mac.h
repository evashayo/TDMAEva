/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LORA_MAC_H
#define LORA_MAC_H

#include "ns3/object.h"
#include "ns3/logical-lora-channel-helper.h"
#include "ns3/packet.h"
#include "ns3/lora-phy.h"
#include <deque>

namespace ns3 {

  class LoraPhy;

  class LoraMac : public Object
  {
  public:

    static TypeId GetTypeId (void);

    LoraMac();
    virtual ~LoraMac();

    /**
     * Get the underlying PHY layer
     */
    Ptr<LoraPhy> GetPhy (void);

    /**
     * Set the underlying PHY layer
     * \param phy the phy layer
     */
    void SetPhy (Ptr<LoraPhy> phy);
    
    /**
     * Set if the underlying PHY is spectrum-based or not
     * \param spectrumPhy boolean flag
     */
    void SetSpectrumPhy (bool spectrumPhy);

    /**
     * Send a packet
     * \param packet the packet to send
     */
    virtual void Send (Ptr<Packet> packet) = 0;

    /**
     * Receive a packet
     * \param packet the received packet
     */
    virtual void Receive (Ptr<Packet> packet) = 0;

    /**
     * Perform actions after sending a packet.
     */
    virtual void TxFinished (Ptr<Packet> packet) = 0;

    /**
     * Set the device this MAC layer is installed on.
     */
    void SetDevice (Ptr<NetDevice> device);

  private:

  protected:
    /**
     * The trace source fired when a packet cannot be sent immediately because
     * of duty cycle limitations.
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<const Packet> > m_cannotSendBecauseDutyCycle;

    /**
     * The PHY instance that sits under this MAC layer
     */
    Ptr<LoraPhy> m_phy;

    /**
     * The device this MAC layer is installed on
     */
    Ptr<NetDevice> m_device;

    /**
     * The transmit queue used by the MAC.
     */
    std::deque< Ptr< Packet> > m_txQueue;

    /**
     * The logical LoRa channel helper
     */
    LogicalLoraChannelHelper m_channelHelper;
    
    /**
     * Flag that indicates if the underlying PHY is spectrum-based or not
     */
    bool m_spectrumPhy;
  };

} /* namespace ns3 */

#endif /* LORA_MAC_H */
