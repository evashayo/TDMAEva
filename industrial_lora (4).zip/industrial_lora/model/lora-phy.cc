/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/lora-phy.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include <algorithm>

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LoraPhy");

  NS_OBJECT_ENSURE_REGISTERED (LoraPhy);


  TypeId
  LoraPhy::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::LoraPhy")
      .SetParent<Object> ()
      .SetGroupName ("Lora")
      .AddTraceSource ("PhyRxBegin",
                       "Trace source indicating a packet "
                       "has begun being received from the channel medium "
                       "by the device",
                       MakeTraceSourceAccessor (&LoraPhy::m_phyRxBeginTrace),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("PhyRxEnd",
                       "Trace source indicating a packet "
                       "has been completely received by the device",
                       MakeTraceSourceAccessor (&LoraPhy::m_phyRxEndTrace),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("LostPacketBecauseInterference",
                       "Trace source indicating a packet "
                       "could not be correctly decoded because of interfering"
                       "signals",
                       MakeTraceSourceAccessor (&LoraPhy::m_interferedPacket),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("LostPacketBecauseNoMoreReceivers",
                       "Trace source indicating a packet "
                       "could not be correctly received because"
                       "there are no more demodulators available",
                       MakeTraceSourceAccessor (&LoraPhy::m_noMoreDemodulators),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("LostPacketBecauseUnderSensitivity",
                       "Trace source indicating a packet "
                       "could not be correctly received because"
                       "its power is below the sensitivity of the receiver",
                       MakeTraceSourceAccessor (&LoraPhy::m_underSensitivity),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("StartSending",
                       "Trace source indicating the PHY layer"
                       "has begun the sending process of a packet",
                       MakeTraceSourceAccessor (&LoraPhy::m_startSending),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("ReceivedPacket",
                       "Trace source indicating a packet "
                       "was correctly received",
                       MakeTraceSourceAccessor
                       (&LoraPhy::m_successfullyReceivedPacket),
                       "ns3::Packet::TracedCallback");
    return tid;
  }

  LoraPhy::LoraPhy ()
  {
    NS_LOG_FUNCTION (this);
  }

  LoraPhy::~LoraPhy ()
  {
    NS_LOG_FUNCTION (this);
  }

  Ptr<NetDevice>
  LoraPhy::GetDevice (void) const
  {
    return m_device;
  }

  void
  LoraPhy::SetDevice (Ptr<NetDevice> device)
  {
    NS_LOG_FUNCTION (this << device);
    m_device = device;
  }

  Ptr<LoraChannel>
  LoraPhy::GetChannel (void) const
  {
    return m_channel;
  }

  Ptr<MobilityModel>
  LoraPhy::GetMobility (void)
  {
    if (m_mobility != 0)
      {
        return m_mobility;
      }
    else
      {
        return m_device->GetNode ()->GetObject<MobilityModel> ();
      }
  }

  void
  LoraPhy::SetMobility (Ptr<MobilityModel> mobility)
  {
    m_mobility = mobility;
  }

  void
  LoraPhy::SetChannel (Ptr<LoraChannel> channel)
  {
    NS_LOG_FUNCTION (this << channel);
    m_channel = channel;
  }
}
