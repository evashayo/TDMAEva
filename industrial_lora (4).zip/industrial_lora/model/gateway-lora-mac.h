/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef GATEWAY_LORA_MAC_H
#define GATEWAY_LORA_MAC_H

#include "ns3/lora-mac.h"

namespace ns3 {

  class GatewayLoraMac : public LoraMac
  {
  public:

    static TypeId GetTypeId (void);

    GatewayLoraMac();
    virtual ~GatewayLoraMac();

    /**
     * Send a packet
     * \param packet the packet to send
     */
    virtual void Send (Ptr<Packet> packet);

    /**
     * Receive a packet
     * \param packet the received packet
     */
    virtual void Receive (Ptr<Packet> packet);

    /**
     * Take action when a packet has finished transmitting.
     * In the case of the gateway, once a packet has finished transmitting we
     * can send it over to the Network Server.
     */
    virtual void TxFinished (Ptr<Packet> packet);

  private:

  protected:

  };

} /* namespace ns3 */

#endif /* GATEWAY_LORA_MAC_H */
