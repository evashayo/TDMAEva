/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/lora-frame-header.h"
#include "ns3/log.h"
#include <bitset>

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LoraFrameHeader");

  LoraFrameHeader::LoraFrameHeader () : m_fPort (1)
  {
  }

  LoraFrameHeader::~LoraFrameHeader ()
  {
  }

  TypeId
  LoraFrameHeader::GetTypeId (void)
  {
    static TypeId tid = TypeId ("LoraFrameHeader")
      .SetParent<Header> ()
      .AddConstructor<LoraFrameHeader> ()
      ;
    return tid;
  }

  TypeId
  LoraFrameHeader::GetInstanceTypeId (void) const
  {
    return GetTypeId ();
  }

  uint32_t
  LoraFrameHeader::GetSerializedSize (void) const
  {
    NS_LOG_FUNCTION_NOARGS ();

    // 4 for DevAddr + 1 for FCtrl + 2 for FCnt + 0-15 for FOpts + 1 for FPort, in bytes
    return 8;
  }

  void
  LoraFrameHeader::Serialize (Buffer::Iterator start) const
  {
    NS_LOG_FUNCTION_NOARGS ();

    // TODO
    // For now, we assume we only transmit the FPort and that it's always
    // 1. All other fields are zero, but are there nonetheless. Since the
    // FPort is in the least significant octet, this dummy header, when
    // serialized, is an uint64_t of value 1 if m_fPort=1.
    uint64_t serialized = m_fPort;

    start.WriteU64 (serialized);

    NS_LOG_DEBUG ("Serialization of frame header: " << std::bitset<64>(serialized));
  }

  uint32_t
  LoraFrameHeader::Deserialize (Buffer::Iterator start)
  {
    NS_LOG_FUNCTION_NOARGS ();

    m_fPort = uint8_t (start.ReadU64 ());

    return 8; // the number of bytes consumed.
  }

  void
  LoraFrameHeader::Print (std::ostream &os) const
  {
    os << "FPort=" << unsigned(m_fPort);
  }

  void
  LoraFrameHeader::SetFPort (uint8_t fPort)
  {
    m_fPort = fPort;
  }

  uint8_t
  LoraFrameHeader::GetFPort (void) const
  {
    return m_fPort;
  }
}
