/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 *
 * The structure of this class is inspired by the YansWifiChannel
 * contained in the WiFi module.
 */

#ifndef LORA_CHANNEL_H
#define LORA_CHANNEL_H

#include <vector>
#include "ns3/mobility-model.h"
#include "ns3/channel.h"
#include "ns3/net-device.h"
#include "ns3/propagation-loss-model.h"
#include "ns3/propagation-delay-model.h"
#include "ns3/lora-phy.h"
#include "ns3/logical-lora-channel.h"
#include "ns3/packet.h"
#include "ns3/nstime.h"

namespace ns3 {

  class NetDevice;
  class LoraPhy;
  class PropagationLossModel;
  class PropagationDelayModel;

  /**
   * Hold the parameters of a received packet: received power, spreading factor
   * and on-air duration.
   */
  struct Parameters {
    double rxPowerDbm;
    uint8_t sf;
    Ptr<LogicalLoraChannel> logicalChannel;
    Time duration;
  };

  class LoraChannel : public Channel
  {
  public:
    // TypeId
    static TypeId GetTypeId (void);

    // Constructor and destructor
    LoraChannel();
    virtual ~LoraChannel();

    // Inherited from Channel.
    virtual uint32_t GetNDevices (void) const;
    virtual Ptr<NetDevice> GetDevice (uint32_t i) const;

    /**
     * Custom constructor
     * \param loss The loss model to associate to this channel
     * \param delay The delay model to associate to this channel
     */
    LoraChannel(Ptr<PropagationLossModel> loss, Ptr<PropagationDelayModel> delay);

    /**
     * Connect a physical layer to the LoraChannel.
     * This method is needed so that the channel knows it has to notify this
     * phy of incoming transmissions.
     * \param phy The physical layer to add.
     */
    void Add (Ptr<LoraPhy> phy);

    /**
     * Remove a physical layer from the LoraChannel.
     * This method removes a phy from the list of devices we have to notify.
     * \param phy The physical layer to remove.
     */
    void Remove (Ptr<LoraPhy> phy);

    /**
     * Send a packet over the channel.
     * This method is invoked by a PHY that is sending a packet over the
     * channel. When this method is called, the channel schedules a reception
     * event to deliver the packet to every phy on the list.
     * \param sender The phy that is sending this packet.
     * \param packet The PHY layer packet that is being sent over the
     * channel.
     * \param txPowerDbm The power of the transmission.
     * \param sf The spreading factor this packet is using.
     * \param duration The on-air duration of this packet.
     * \param logicalChannel A pointer to the LogicalLoraChannel this transmission is on
     * being sent on.
     */
    void Send (Ptr< LoraPhy > sender, Ptr< Packet > packet, double txPowerDbm, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel) const;

    /**
     * Compute the received power when transmitting from a point to another one.
     * \param txPowerDbm the power of the transmitter.
     * \param senderMobility the mobility of the sender.
     * \param receiverMobility the mobility of the receiver.
     * \returns the received power in dBm.
     */
    double GetRxPower (double txPowerDbm, Ptr<MobilityModel> senderMobility, Ptr<MobilityModel> receiverMobility) const;

  private:

    /**
     * Private method that is scheduled by Send to happen after the channel
     * delay.
     * This private method is scheduled by Send. It's here that the Receive
     * method of the PHY is called to initiate packet reception at the PHY.
     * \param i The index of the phy to start reception on.
     * \param packet The packet the phy will receive.
     * \param parameters The set of information about this packet's
     * transmission on the channel (sf, rxPower, and so on).
     */
    void Receive (uint32_t i, Ptr<Packet> packet, struct Parameters parameters) const;

    /**
     * A vector containing the PHYs that are currently connected to the channel.
     */
    std::vector< Ptr< LoraPhy > > m_phyList;

    /**
     * Pointer to the loss model.
     * This loss model can be a concatenation of multiple loss models,
     * obtained via PropagationLossModel's SetNext method.
     */
    Ptr<PropagationLossModel> m_loss;

    /**
     * Pointer to the delay model.
     */
    Ptr<PropagationDelayModel> m_delay;

    /**
     * Callback for when a packet is being sent on the channel.
     */
    TracedCallback<Ptr<const Packet> > m_packetSent;

    /**
     * Threshold under which packet is not delivered.
     * This is used to speed up computation: if a device would receive a
     * packet with a power under this threshold, the channel won't even
     * deliver it to that device.
     */
    double m_dontDeliverThreshold;

    /**
     * Trace source that is fired whenever a packet isn't scheduled for
     * delivery because its receive power would be too low.
     * This is called whenever a packet's reception power is under
     * m_dontDeliverThreshold.
     */
    TracedCallback<Ptr<const Packet> > m_belowChannelThreshold;

  };

} /* namespace ns3 */

#endif /* LORA_CHANNEL_H */
