/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LORA_FRAME_HEADER_H
#define LORA_FRAME_HEADER_H

#include "ns3/header.h"

namespace ns3 {

  /**
   * This class represents the Frame header (FHDR) used in a LoraWAN network.
   * Although the specification divides the FHDR from the FPort field, this
   * implementation considers them as a unique entity (i.e., FPort is treated
   * as if it were a part of FHDR).
   */
  class LoraFrameHeader : public Header
  {
  public:

    LoraFrameHeader ();
    ~LoraFrameHeader ();

    static TypeId GetTypeId (void);
    virtual TypeId GetInstanceTypeId (void) const;
    virtual uint32_t GetSerializedSize (void) const;

    /**
     * Serialize the header.
     *
     * See Page 15 of LoraWAN specification for a representation of fields.
     */
    virtual void Serialize (Buffer::Iterator start) const;
    virtual uint32_t Deserialize (Buffer::Iterator start);
    virtual void Print (std::ostream &os) const;

    void SetFPort (uint8_t fPort);
    uint8_t GetFPort (void) const;

  private:

    // uint32_t m_devAddr;

    uint8_t m_fPort;

  };
}

#endif

