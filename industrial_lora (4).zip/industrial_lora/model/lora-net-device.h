/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LORA_NET_DEVICE_H
#define LORA_NET_DEVICE_H

#include "ns3/net-device.h"
#include "ns3/lora-channel.h"
#include "ns3/lora-phy.h"
#include "ns3/lora-mac.h"

namespace ns3 {

  class LoraChannel;
  class LoraPhy;
  class LoraMac;

  /**
   * \brief Hold together all LoRa related objects.
   * \ingroup lora
   *
   * This class holds together pointers to ns3::LoraChannel, ns3::LoraPhy,
   * ns3::LoraMac.
   */
  class LoraNetDevice : public NetDevice
  {
  public:
    static TypeId GetTypeId (void);

    // Constructor and destructor
    LoraNetDevice ();
    virtual ~LoraNetDevice ();

    /**
     * \param mac the mac layer to use.
     */
    void SetMac (Ptr<LoraMac> mac);

    /**
     * \param phy the phy layer to use.
     */
    void SetPhy (Ptr<LoraPhy> phy);

    /**
     * \returns the mac we are currently using.
     */
    Ptr<LoraMac> GetMac (void) const;

    /**
     * \returns the phy we are currently using.
     */
    Ptr<LoraPhy> GetPhy (void) const;

    /**
     * Sends a packet coming from the Application layer
     * \param packet the packet to send
     */
    void Send (Ptr<Packet> packet);

    // From class NetDevice
    virtual void SetIfIndex (const uint32_t index);
    virtual uint32_t GetIfIndex (void) const;
    virtual Ptr<Channel> GetChannel (void) const;
    virtual void SetAddress (Address address);
    virtual Address GetAddress (void) const;
    virtual bool SetMtu (const uint16_t mtu);
    virtual uint16_t GetMtu (void) const;
    virtual bool IsLinkUp (void) const;
    virtual void AddLinkChangeCallback (Callback<void> callback);
    virtual bool IsBroadcast (void) const;
    virtual Address GetBroadcast (void) const;
    virtual bool IsMulticast (void) const;
    virtual Address GetMulticast (Ipv4Address multicastGroup) const;
    virtual Address GetMulticast (Ipv6Address addr) const;
    virtual bool IsBridge (void) const;
    virtual bool IsPointToPoint (void) const;
    virtual bool Send (Ptr<Packet> packet, const Address& dest, uint16_t protocolNumber);
    virtual bool SendFrom (Ptr<Packet> packet, const Address& source, const Address& dest, uint16_t protocolNumber);
    virtual Ptr<Node> GetNode (void) const;
    virtual void SetNode (Ptr<Node> node);
    virtual bool NeedsArp (void) const;
    virtual void SetReceiveCallback (NetDevice::ReceiveCallback cb);
    virtual void SetPromiscReceiveCallback (PromiscReceiveCallback cb);
    virtual bool SupportsSendFrom (void) const;

protected:
    /**
     * Receive a packet from the lower layer and pass the
     * packet up the stack.
     *
     * \param packet The packet we need to forward
     * \param from The from address
     * \param to The to address
     */
    void ForwardUp (Ptr<Packet> packet, Mac48Address from, Mac48Address to);

  private:

    /**
     * Return the LoraChannel this device is connected to.
     */
    Ptr<LoraChannel> DoGetChannel (void) const;

    /**
     * Complete the configuration of this LoRa device by
     * connecting all lower components (PHY, MAC, Channel) together.
     */
    void CompleteConfig (void);

    // Member variables
    Ptr<Node> m_node;
    Ptr<LoraPhy> m_phy;
    Ptr<LoraMac> m_mac;
    bool m_configComplete;

    /**
     * Upper layer callback used for notification of new data packet arrivals.
     */
    NetDevice::ReceiveCallback m_receiveCallback;
  };

} //namespace ns3

#endif /* LORA_NET_DEVICE_H */
