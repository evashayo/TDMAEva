/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#include "ns3/spectrum-lora-interference-helper.h"
#include "ns3/log.h"
#include "ns3/lora-error-rate-model.h"
#include "ns3/simulator.h"
#include <algorithm>
#include <limits>

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("SpectrumLoraInterferenceHelper");

  /****************************************************************************
   *      SpectrumLoraInterferenceHelper::SpectrumEvent                       *
   ****************************************************************************/

  // Event Constructor
  SpectrumLoraInterferenceHelper::SpectrumEvent::SpectrumEvent (Time duration, double rxPowerdBm,
                                        uint8_t spreadingFactor, Ptr<Packet>
                                        packet, Ptr<LogicalLoraChannel> logicalChannel) :
    m_startTime (Simulator::Now ()),
    m_endTime (m_startTime + duration),
    m_sf (spreadingFactor),
    m_rxPowerdBm (rxPowerdBm),
    m_packet (packet),
    m_logicalChannel (logicalChannel)
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  // Event Destructor
  SpectrumLoraInterferenceHelper::SpectrumEvent::~SpectrumEvent ()
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  // Getters
  Time
  SpectrumLoraInterferenceHelper::SpectrumEvent::GetStartTime (void) const
  {
    return m_startTime;
  }

  Time
  SpectrumLoraInterferenceHelper::SpectrumEvent::GetEndTime (void) const
  {
    return m_endTime;
  }

  Time
  SpectrumLoraInterferenceHelper::SpectrumEvent::GetDuration (void) const
  {
    return m_endTime - m_startTime;
  }

  double
  SpectrumLoraInterferenceHelper::SpectrumEvent::GetRxPowerdBm (void) const
  {
    return m_rxPowerdBm;
  }

  uint8_t
  SpectrumLoraInterferenceHelper::SpectrumEvent::GetSpreadingFactor (void) const
  {
    return m_sf;
  }

  Ptr<Packet>
  SpectrumLoraInterferenceHelper::SpectrumEvent::GetPacket (void) const
  {
    return m_packet;
  }

  Ptr<LogicalLoraChannel>
  SpectrumLoraInterferenceHelper::SpectrumEvent::GetLogicalChannel (void) const
  {
    return m_logicalChannel;
  }

  /****************************************************************************
   *                  SpectrumLoraInterferenceHelper                          *
   ****************************************************************************/

  NS_OBJECT_ENSURE_REGISTERED (SpectrumLoraInterferenceHelper);

  TypeId
  SpectrumLoraInterferenceHelper::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::SpectrumLoraInterferenceHelper")
      .SetParent<Object> ()
      .SetGroupName ("Lora");

    return tid;
  }

  SpectrumLoraInterferenceHelper::SpectrumLoraInterferenceHelper ()
    : m_errorRateModel (0)
  {
    NS_LOG_FUNCTION (this);
  }

  SpectrumLoraInterferenceHelper::~SpectrumLoraInterferenceHelper ()
  {
    NS_LOG_FUNCTION (this);
    m_errorRateModel = 0;
  }
  
  // Equivalent SIR factor
  const double SpectrumLoraInterferenceHelper::equivalentSirFactor[6][6] =
  {
  //  SF7  SF8  SF9  SF10  SF11  SF12
  {  0.0446683592150963,	7.07945784384138,	11.2201845430196,	14.1253754462275,	14.1253754462275,	17.7827941003892},  // SF7
  {25.1188643150958,	0.0251188643150958,	10,	15.8489319246111,	15.8489319246111,	15.8489319246111},  // SF8
  {28.1838293126445,	28.1838293126445,	0.0141253754462275,	11.2201845430196,	17.7827941003892,	17.7827941003892},  // SF9
  {31.6227766016838,	31.6227766016838,	31.6227766016838,	0.00794328234724281,	12.5892541179417,	19.9526231496888},  // SF10
  {35.4813389233576,	35.4813389233576,	35.4813389233576,	35.4813389233576,	0.00446683592150963,	14.1253754462275},  // SF11
  {39.8107170553497,	39.8107170553497,	39.8107170553497,	39.8107170553497,	39.8107170553497,	0.00251188643150958}   // SF12
  };

  Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent>
  SpectrumLoraInterferenceHelper::Add (Time duration, double rxPower, uint8_t
                               spreadingFactor, Ptr<Packet> packet,
                               Ptr<LogicalLoraChannel> logicalChannel)
  {
    // Create an event based on the parameters
    Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event =
      Create<SpectrumLoraInterferenceHelper::SpectrumEvent> (duration, rxPower, spreadingFactor,
                                             packet, logicalChannel);

    // Cycle the events, and clean up if an event is old.
    // "Old" is a totally arbitrary number of seconds.
    std::list<Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> >::iterator it;
    for (it = m_events.begin(); it != m_events.end();)
      {
        if ((*it)->GetEndTime () + Seconds (10) < Simulator::Now ())
          {
            it = m_events.erase (it);
          }
        it++;
      }


    // Add the event to the list
    m_events.push_back (event);
    return event;
  }
  
  void
  SpectrumLoraInterferenceHelper::AddForeignSignal (Time duration, double rxPower)
  {
	// Parameters other than duration and rxPowerW are unused for this type
	// of signal, so we provide dummy versions
	Ptr<Packet> fakePacket;
	Ptr<LogicalLoraChannel> fakeChannel;
	Add (duration, rxPower, 0,  fakePacket, fakeChannel);
  }
  
  void
  SpectrumLoraInterferenceHelper::SetNoiseFigure (double value)
  {
    m_noiseFigureDb = value;
  }

  double
  SpectrumLoraInterferenceHelper::GetNoiseFigure (void) const
  {
    return m_noiseFigureDb;
  }

  void
  SpectrumLoraInterferenceHelper::SetErrorRateModel (Ptr<LoraErrorRateModel> rate)
  {
    m_errorRateModel = rate;
  }

  Ptr<LoraErrorRateModel>
  SpectrumLoraInterferenceHelper::GetErrorRateModel (void) const
  {
    return m_errorRateModel;
  }

  std::list< Ptr< SpectrumLoraInterferenceHelper::SpectrumEvent > >
  SpectrumLoraInterferenceHelper::GetInterferers()
  {
    return m_events;
  }
  
  void
  SpectrumLoraInterferenceHelper::CalculateInterferenceChanges (Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event, IntChanges *ic) const
  {
	 
	// Handy information about the time frame the packet was received
    Time now = Simulator::Now ();
    Time duration = event->GetDuration ();
    Time packetStartTime = now - duration;
    Time packetEndTime = now; 
    
    // Get Logical Channel
    Ptr<LogicalLoraChannel> logicalChannel = event->GetLogicalChannel ();
	  
	// Insert end of packet
	ic->push_back(duration);  
    
    // Get the list of interfering events
    std::list<Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> >::const_iterator it;
 
    // Cycle over the events
    for (it = m_events.begin(); it != m_events.end();)
      {
		  // Pointer to the current interferer
          Ptr< SpectrumLoraInterferenceHelper::SpectrumEvent > interferer = *it;
          
          // Only consider the current event if the channel is the same:
          // there's no interchannel interference. Also skip the current event
          // if it's the same that we want to analyze.
          if ((interferer->GetLogicalChannel () != logicalChannel) || interferer == event)
            {
              it++;
              continue; // Continues from the first line inside the for cycle
            }
          
          // Skip current event if it happened before or after the event we want to analyze
          if ((interferer->GetEndTime() <= packetStartTime) || (interferer->GetStartTime() >= packetEndTime))
            {
              it++;
              continue; // Continues from the first line inside the for cycle
            }
            
          // Add (in order) beginning of interferer
          Time startInterference = interferer->GetStartTime(); 
          if (startInterference > packetStartTime)
            {
			  for (IntChanges::const_iterator i = ic->begin () + 1; i != ic->end (); i++)
				{
				  if (startInterference <= *i)
					{
					  ic->push_back (startInterference-packetStartTime);
					  break;
					}
				
				}  
			}
			
		 // Add (in order) end of interferer
		 Time endInterference = interferer->GetEndTime();
         if (endInterference < packetEndTime)
           {
			  for (IntChanges::const_iterator i = ic->begin () + 1; i != ic->end (); i++)
			    {
				  if (endInterference <= *i)
					{
					  ic->push_back (endInterference-packetStartTime);
					  break;
					}
				
				}  
			}	
    
      }

  }
  
  double
  SpectrumLoraInterferenceHelper::CalculateSnr (double signal, double channelWidth) const
  {
    //thermal noise at 290K in J/s = W
    static const double BOLTZMANN = 1.3803e-23;
    //Nt is the power of thermal noise in W
    double Nt = BOLTZMANN * 290.0 * channelWidth * 1000000;
    //receiver noise Floor (W) which accounts for thermal noise and non-idealities of the receiver
    double noiseFigure = std::pow(10,m_noiseFigureDb/10);
    double noiseFloor = noiseFigure * Nt;
    double snr = signal / noiseFloor; //linear scale
    NS_LOG_DEBUG ("bandwidth(MHz)=" << channelWidth << ", signal(W)= " << signal << ", noise(W)=" << noiseFloor << ", snr(linear)=" << snr);
    return snr;
  }
  
  double
  SpectrumLoraInterferenceHelper::CalculateChunkSuccessRate (double sinrEq, Time duration, uint8_t sf, double channelWidthHz) const
  {
    if (duration == NanoSeconds (0))
      {
        return 1.0;
      }
    double symbolTime = std::pow(2, sf) / channelWidthHz;  
    double rate = sf / symbolTime;
    uint64_t nbits = (uint64_t)(rate * duration.GetSeconds ());
    double csr = m_errorRateModel->GetChunkSuccessRate (sf, sinrEq, (uint32_t)nbits);
    //std::cout << "ESINR: " << 10*std::log10(sinrEq) << ", bits: " << nbits << ", SF: " << sf << " => CSR: " << csr << std::endl;
    return csr;
}
  
  double
  SpectrumLoraInterferenceHelper::CalculatePer (Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event)
  {
	  
	NS_LOG_FUNCTION (this << event);
    NS_LOG_DEBUG("Current number of events in SpectrumLoraInterferenceHelper: " << m_events.size());  

	// We want to see the interference caused on this event: cycle through
    // events that overlap with this one and compute the total PER.
    
    // Determine starting instants of different chunks
    IntChanges ic;
	CalculateInterferenceChanges (event, &ic);

    // Info about the event
    double rxPowerDbm = event->GetRxPowerdBm ();
    double rxPowerW = (std::pow (10.0, rxPowerDbm / 10.0) / 1000.0);
    uint8_t packetSf = event->GetSpreadingFactor ();
    Ptr<LogicalLoraChannel> logicalChannel = event->GetLogicalChannel ();
    double packetChannelWidthHz = logicalChannel->GetBandwidth() * 1e6;
    Time packetStartTime = event->GetStartTime();
    
    // Overall packet success rate
    double psr = 1;
    
    // Compute SNR (linear) for current packet
    double snr = CalculateSnr (rxPowerW, logicalChannel->GetBandwidth());
    
    // Cycle over different chunks
    Time chunkStartTime = packetStartTime, chunkEndTime;
    for (IntChanges::const_iterator i = ic.begin (); i != ic.end (); i++)
	  {
	    double totalIntPowerW[6] = {0, 0, 0, 0, 0, 0};
	    chunkEndTime = *i;
	    std::list<Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> >::iterator it;
	    
	    // Cycle over all interferers
		for (it = m_events.begin(); it != m_events.end();)
          {
		    // Pointer to the current interferer
            Ptr< SpectrumLoraInterferenceHelper::SpectrumEvent > interferer = *it;
          
            // Skip the interferer if needed
            if ((interferer->GetLogicalChannel () != logicalChannel) || interferer == event || 
				(interferer->GetEndTime() <= chunkStartTime) || (interferer->GetStartTime() >= chunkEndTime))
              {
                it++;
                continue; // Continues from the first line inside the for cycle
              }
          
            // Add interference
            double intPowerW = (std::pow (10.0, interferer->GetRxPowerdBm() / 10.0) / 1000.0); 
			uint8_t isf = interferer->GetSpreadingFactor();
			if (isf != 0)	// Consider only LoRa interference
			  {
			    totalIntPowerW[isf-7] += intPowerW;
			  }
	    	      	
		  }
		   
	   // Compute equivalent SINR
	   double recSinrEq = 1/snr;
	   for (uint8_t currentSf = uint8_t(7); currentSf <= uint8_t(12); currentSf++)
	     {
		    double sir = rxPowerW/totalIntPowerW[currentSf-7];
		    double sirEq = sir * equivalentSirFactor [packetSf-7][currentSf-7];
		    recSinrEq += 1/sirEq;	 
		 }
	   double sinrEq = 1/recSinrEq;	
       
	   // Update packet success rate
	   psr *= CalculateChunkSuccessRate(sinrEq, chunkEndTime-chunkStartTime, packetSf,packetChannelWidthHz); 
	   if (psr == 0)
	     {
		   break; 	 
		 }
		 
	   // Update chunk start time
	   chunkStartTime = chunkEndTime;

      }

    return 1 - psr;
}

}
