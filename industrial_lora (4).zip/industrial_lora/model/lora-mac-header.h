/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LORA_MAC_HEADER_H
#define LORA_MAC_HEADER_H

#include "ns3/header.h"

namespace ns3 {

  class LoraMacHeader : public Header
  {
  public:

    enum MType {
      JOIN_REQUEST = 0,
      JOIN_ACCEPT = 1,
      UNCONFIRMED_DATA_UP = 2,
      UNCONFIRMED_DATA_DOWN = 3,
      CONFIRMED_DATA_UP = 4,
      CONFIRMED_DATA_DOWN = 5,
      PROPRIETARY = 7
    };

    LoraMacHeader ();
    ~LoraMacHeader ();

    // must be implemented to become a valid new header.
    static TypeId GetTypeId (void);
    virtual TypeId GetInstanceTypeId (void) const;
    virtual uint32_t GetSerializedSize (void) const;

    /**
     * Serialize the header.
     *
     * See Page 15 of LoraWAN specification for a representation of fields.
     */
    virtual void Serialize (Buffer::Iterator start) const;

    /**
     * Deserialize the header.
     */
    virtual uint32_t Deserialize (Buffer::Iterator start);

    virtual void Print (std::ostream &os) const;

    /**
     * Set the message type
     */
    void SetMType (enum MType mtype);

    /**
     * Get the message type from the header
     */
    uint8_t GetMType (void) const;

  private:
    /**
     * The Message Type
     */
    uint8_t m_mtype;

    /**
     * The major version this header is using
     */
    uint8_t m_major;
  };
}

#endif
