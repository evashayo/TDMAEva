/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Michele Luvisotto <michele.luvisotto@dei.unipd.it>, Romagnolo Stefano <romagnolostefano93@gmail.com>
 */

#ifndef SPECTRUM_END_DEVICE_LORA_PHY_H
#define SPECTRUM_END_DEVICE_LORA_PHY_H

#include "ns3/object.h"
#include "ns3/net-device.h"
#include "ns3/nstime.h"
#include "ns3/mobility-model.h"
#include "ns3/node.h"
#include "ns3/lora-phy.h"
#include "ns3/antenna-model.h"
#include "ns3/spectrum-lora-interference-helper.h"
#include "ns3/lora-end-device-spectrum-phy-interface.h"
#include "ns3/lora-spectrum-value-helper.h"
#include "ns3/spectrum-channel.h"
#include "ns3/spectrum-interference.h"

namespace ns3 {

/**
 * \brief receive notifications about phy events.
 */
class LoraEndDevicePhyListener
{
public:
  virtual ~LoraEndDevicePhyListener ();

  /**
   * \param duration the expected duration of the packet reception.
   *
   * We have received the first bit of a packet. We decided
   * that we could synchronize on this packet. It does not mean
   * we will be able to successfully receive completely the
   * whole packet. It means that we will report a BUSY status until
   * one of the following happens:
   *   - NotifyRxEndOk
   *   - NotifyRxEndError
   *   - NotifyTxStart
   */
  virtual void NotifyRxStart (Time duration) = 0;
  /**
   * \param duration the expected transmission duration.
   * \param txPowerDbm the nominal tx power in dBm
   *
   * We are about to send the first bit of the packet.
   * We do not send any event to notify the end of
   * transmission. Listeners should assume that the
   * channel implicitely reverts to the idle state
   * unless they have received a cca busy report.
   */
  virtual void NotifyTxStart (Time duration, double txPowerDbm) = 0;
  /**
   * Notify listeners that we went to sleep
   */
  virtual void NotifySleep (void) = 0;
  /**
   * Notify listeners that we woke up
   */
  virtual void NotifyStandby (void) = 0;
};



  class SpectrumEndDeviceLoraPhy : public LoraPhy
  {
  public:

	// Similar to EndDeviceLoraPhy
	
    enum State
      {
        SLEEP,
        IDLE, //STANDBY,
        TX,
        RX
      };

    static TypeId GetTypeId (void);

    SpectrumEndDeviceLoraPhy();
    virtual ~SpectrumEndDeviceLoraPhy();
    
   /**
   * \param listener the new listener
   *
   * Add the input listener to the list of objects to be notified of
   * PHY-level events.
   */
   void RegisterListener (LoraEndDevicePhyListener *listener);
   /**
   * \param listener the listener to be unregistered
   *
   * Remove the input listener from the list of objects to be notified of
   * PHY-level events.
   */
   void UnregisterListener (LoraEndDevicePhyListener *listener);

    Ptr<NetDevice> GetDevice (void) const;
    // Ptr<MobilityModel> GetMobility();

    virtual void StartReceive (Ptr<Packet> packet, double rxPowerDbm, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);
    virtual void EndReceive (Ptr<Packet> packet, Ptr<LoraInterferenceHelper::Event> event);
    virtual void Send (Ptr<Packet> packet, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);
    void SpectrumEndReceive (Ptr<Packet> packet, Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event);

    virtual void SetReceiveOkCallback (RxOkCallback callback);
    virtual void SetTxFinishedCallback (TxFinishedCallback callback);
    
    virtual bool IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel);

    double GetTxPowerdBm ();
    void SetTxPowerdBm (double power);

    void SetLogicalChannel (Ptr<LogicalLoraChannel> logicalChannel);

    void SwitchToRx (Time duration);
    void SwitchToTx (Time duration, double txPowerDbm);
    void SwitchToStandby (void);
    void SwitchToSleep (void);
    
    State m_state; 
    
    // Similar to WifiPhy
    
    void SetErrorRateModel (Ptr<LoraErrorRateModel> rate);
    Ptr<LoraErrorRateModel> GetErrorRateModel (void) const;
    
    // Similar to SpectrumWifiPhy
    
    void StartRx (Ptr<SpectrumSignalParameters> rxParams);
    
    void CreateLoraEdSpectrumPhyInterface (Ptr<NetDevice> device);
	Ptr<LoraEndDeviceSpectrumPhyInterface> GetSpectrumPhy (void) const;
	
	void SetAntenna (Ptr<AntennaModel> antenna);
    Ptr<AntennaModel> GetRxAntenna (void) const;
    
    typedef Callback<void,bool> RxCallback;
	void SetPacketReceivedCallback (RxCallback callback);
	typedef void (* SignalArrivalCallback) (bool signalType, uint32_t senderNodeId, double rxPower, Time duration);
    
    void SetChannel (Ptr<SpectrumChannel> channel);
	
  private:

	// Similar to EndDeviceLoraPhy

    double m_txPowerdBm; 
    static const double sensitivity[6]; 
    Ptr<LogicalLoraChannel> m_logicalChannel; 
    
    // Similar to WifiPhy
    
    TracedCallback<Ptr<const Packet>, double, double, uint8_t> m_phyMonitorSniffRxTrace;
	TracedCallback<Ptr<const Packet>, double, double, uint8_t> m_phyMonitorSniffTxTrace;
    
    SpectrumLoraInterferenceHelper m_spectrumInterference;     
    
    Ptr<UniformRandomVariable> m_random; 
    
    // Similar to SpectrumWifiPhy
    
    Ptr<SpectrumValue> GetTxPowerSpectralDensity (double centerFrequency, double channelWidth, double txPowerW) const;

	Ptr<SpectrumChannel> m_spectrumChannel;        

	Ptr<LoraEndDeviceSpectrumPhyInterface> m_loraEdSpectrumPhyInterface;
	Ptr<AntennaModel> m_antenna;
	
	RxCallback m_rxCallback;
	TracedCallback<bool, uint32_t, double, Time> m_signalCb;
	
	
	// Similar to WifiPhyStateHelper
	
    /**
    * typedef for a list of LoraEndDevicePhyListener
    */
    typedef std::vector<LoraEndDevicePhyListener *> Listeners;
    /**
    * typedef for a list of LoraEndDevicePhyListener iterator
    */
    typedef std::vector<LoraEndDevicePhyListener *>::iterator ListenersI;
   
    Listeners m_listeners; //< listeners
	
	// New ones
	
	TracedCallback<Ptr<Packet> > m_failedDecoding;

  };

} /* namespace ns3 */

#endif /* SPECTRUM_END_DEVICE_LORA_PHY_H */
