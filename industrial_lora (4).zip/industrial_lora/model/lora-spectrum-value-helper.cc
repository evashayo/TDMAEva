/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#include <map>
#include <cmath>
#include "lora-spectrum-value-helper.h"
#include "ns3/log.h"
#include "ns3/fatal-error.h"
#include "ns3/assert.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("LoraSpectrumValueHelper");

struct LoraSpectrumModelId
{
  LoraSpectrumModelId (double f, double w);
  double m_centerFrequency;
  double m_channelWidth;
};

LoraSpectrumModelId::LoraSpectrumModelId (double f, double w)
  : m_centerFrequency (f),
    m_channelWidth (w)
{
  NS_LOG_FUNCTION (this << f << w);
}

bool
operator < (const LoraSpectrumModelId& a, const LoraSpectrumModelId& b)
{
  return ( (a.m_centerFrequency < b.m_centerFrequency) || ( (a.m_centerFrequency == b.m_centerFrequency) && (a.m_channelWidth < b.m_channelWidth)));
}

static std::map<LoraSpectrumModelId, Ptr<SpectrumModel> > g_loraSpectrumModelMap;

Ptr<SpectrumModel>
LoraSpectrumValueHelper::GetSpectrumModel (double centerFrequency, double channelWidth)
{
  NS_LOG_FUNCTION (centerFrequency << channelWidth);
  Ptr<SpectrumModel> ret;
  LoraSpectrumModelId key (centerFrequency, channelWidth);
  std::map<LoraSpectrumModelId, Ptr<SpectrumModel> >::iterator it = g_loraSpectrumModelMap.find (key);
  if (it != g_loraSpectrumModelMap.end ())
    {
      ret = it->second;
    }
  else
    {
      Bands bands;
      double centerFrequencyHz = centerFrequency * 1e6;
      // Overall bandwidth will be channelWidth
      double bandwidth = channelWidth * 1e6;
      // Single carrier modulation
      BandInfo info;
      double f = centerFrequencyHz - bandwidth/2;
      info.fl = f;
      f += bandwidth/2;
      info.fc = f;
      f += bandwidth/2;
      info.fh = f;
      NS_LOG_DEBUG ("creating band (" << info.fl << ":" << info.fc << ":" << info.fh << ")");
      bands.push_back (info);
      ret = Create<SpectrumModel> (bands);
      g_loraSpectrumModelMap.insert (std::pair<LoraSpectrumModelId, Ptr<SpectrumModel> > (key, ret));
    }
  NS_LOG_LOGIC ("returning SpectrumModel::GetUid () == " << ret->GetUid ());
  return ret;
}

Ptr<SpectrumValue>
LoraSpectrumValueHelper::CreateLoraTxPowerSpectralDensity (double centerFrequency, double channelWidth, double txPowerW)
{
  NS_LOG_FUNCTION (centerFrequency << channelWidth << txPowerW);
  Ptr<SpectrumValue> c = Create<SpectrumValue> (GetSpectrumModel (centerFrequency, channelWidth));
  Values::iterator vit = c->ValuesBegin ();
  Bands::const_iterator bit = c->ConstBandsBegin ();
  NS_ASSERT_MSG (c->GetSpectrumModel ()->GetNumBands () == 1, "Unexpected number of bands");
  for (size_t i = 0; i < c->GetSpectrumModel ()->GetNumBands (); i++, vit++, bit++)
    {
      *vit = txPowerW/ (bit->fh - bit->fl);
    }
  NS_LOG_DEBUG ("Integrated power " << Integral (*c));
  NS_ASSERT_MSG (std::abs (txPowerW - Integral (*c)) < 1e-6, "Power allocation failed"); 
  return c;
}

Ptr<SpectrumValue>
LoraSpectrumValueHelper::CreateNoisePowerSpectralDensity (double centerFrequency, double channelWidth, double noiseFigure)
{
  Ptr<SpectrumModel> model = GetSpectrumModel (centerFrequency, channelWidth);
  return CreateNoisePowerSpectralDensity (noiseFigure, model);
}

Ptr<SpectrumValue>
LoraSpectrumValueHelper::CreateNoisePowerSpectralDensity (double noiseFigureDb, Ptr<SpectrumModel> spectrumModel)
{
  NS_LOG_FUNCTION (noiseFigureDb << spectrumModel);

  // see "LTE - From theory to practice"
  // Section 22.4.4.2 Thermal Noise and Receiver Noise Figure
  const double kT_dBm_Hz = -174.0;  // dBm/Hz
  double kT_W_Hz = std::pow (10.0, (kT_dBm_Hz - 30) / 10.0);
  double noiseFigureLinear = std::pow (10.0, noiseFigureDb / 10.0);
  double noisePowerSpectralDensity =  kT_W_Hz * noiseFigureLinear;

  Ptr<SpectrumValue> noisePsd = Create <SpectrumValue> (spectrumModel);
  (*noisePsd) = noisePowerSpectralDensity;
  NS_LOG_DEBUG ("NoisePowerSpectralDensity has integrated power of " << Integral (*noisePsd));
  return noisePsd;
}

Ptr<SpectrumValue>
LoraSpectrumValueHelper::CreateRfFilter (double centerFrequency, double channelWidth)
{
  NS_LOG_FUNCTION (centerFrequency << channelWidth);
  Ptr<SpectrumValue> c = Create <SpectrumValue> (GetSpectrumModel (centerFrequency, channelWidth));
  size_t numBands = c->GetSpectrumModel ()->GetNumBands ();
  Bands::const_iterator bit = c->ConstBandsBegin ();
  Values::iterator vit = c->ValuesBegin ();
  uint32_t bandBandwidth = static_cast<double> (((bit->fh - bit->fl)));
  NS_LOG_DEBUG ("Band bandwidth: " << bandBandwidth);
  size_t numBandsInFilter = static_cast<size_t> (channelWidth * 1e6 / bandBandwidth); 
  NS_LOG_DEBUG ("Num bands in filter: " << numBandsInFilter);
  // Set the value of the filter to 1 for the center-most numBandsInFilter
  NS_ASSERT_MSG ((numBandsInFilter % 2 == 1) && (numBands % 2 == 1), "Should have odd number of bands");
  size_t startIndex = (numBands - numBandsInFilter) / 2;
  vit += startIndex;
  bit += startIndex;
  for (size_t i = startIndex; i < startIndex + numBandsInFilter; i++, vit++, bit++)
    {
      *vit = 1;
    }
  NS_LOG_DEBUG ("Added subbands " << startIndex << " to " << startIndex + numBandsInFilter << " to filter");
  return c;
}

static Ptr<SpectrumModel> g_LoraSpectrumModel;

LoraSpectrumValueHelper::~LoraSpectrumValueHelper ()
{
}

} // namespace ns3
