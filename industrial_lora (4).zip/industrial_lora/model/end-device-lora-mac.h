/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef END_DEVICE_LORA_MAC_H
#define END_DEVICE_LORA_MAC_H

#include "ns3/lora-mac.h"
#include "ns3/lora-mac-header.h"
#include "ns3/lora-frame-header.h"
#include "ns3/random-variable-stream.h"
#include "ns3/lora-device-address.h"

namespace ns3 {

  class EndDeviceLoraMac : public LoraMac
  {
  public:

    static TypeId GetTypeId (void);

    EndDeviceLoraMac();
    virtual ~EndDeviceLoraMac();

    /**
     * Send a packet.
     * \param packet the packet to send
     */
    virtual void Send (Ptr<Packet> packet);

    /**
     * Receive a packet.
     * This method is usually registered as a callback to the underlying PHY
     * layer so that it's called when a packet is going up the stack.
     * \param packet the received packet.
     */
    virtual void Receive (Ptr<Packet> packet);

    /**
     * Set the spreading factor this end device will use when transmitting. For
     * end devices, this value is assumed to be fixed, and can be modified via
     * MAC commands issued by the GW.
     * \param sf the spreading factor to use when transmitting.
     */
    void SetSpreadingFactor (uint8_t sf);

    /**
     * Get the spreading factor this end device is set to use.
     * \returns the spreading factor this device uses when transmitting
     */
    uint8_t GetSpreadingFactor (void);

    /**
     * Perform the actions that are required after a packet send.
     * Typically, this means opening a window after a predefined window in
     * which the device listens for downlink messages.
     */
    void TxFinished (Ptr<Packet> packet);

    /**
     * Perform operations needed to open the first receive window.
     */
    void OpenFirstReceiveWindow (void);

    /**
     * Perform operations needed to open the second receive window.
     */
    void OpenSecondReceiveWindow (void);

    /**
     * Perform operations needed to close a receive window.
     */
    void CloseReceiveWindow (void);

    /**
     * Perform operations needed to close a receive window.
     */
    Ptr<LogicalLoraChannel> GetCurrentLogicalChannel (void);

    /**
     * Get the network address of this device
     */
    LoraDeviceAddress GetDeviceAddress (void);

    /**
     * Set the network address of this device
     */
    void SetDeviceAddress (LoraDeviceAddress address);

  private:

    /**
     * Randomly shuffle a Ptr<LogicalLoraChannel> vector.
     */
    std::vector<Ptr<LogicalLoraChannel> > Shuffle
                        (std::vector<Ptr<LogicalLoraChannel> > vector);

    /**
     * An uniform random variable, used to randomly decide on which channel
     * to transmit first.
     */
    Ptr<UniformRandomVariable> m_uniformRV;

    /**
     * The Spreading Factor this end device is currently using to transmit.
     * This value can be modified if the gateway issues the appropriate MAC
     * command.
     */
    uint8_t m_spreadingFactor;

    /**
     * The coding rate used by this device.
     */
    uint8_t m_codingRate;

    /**
     * Whether or not the header is disabled for communications by this
     * device.
     */
    bool m_headerDisabled;

    /**
     * The interval between when a packet is done sending and when the first
     * receive window is opened.
     */
    Time m_receiveDelay1;

    /**
     * The interval between when a packet is done sending and when the second
     * receive window is opened.
     */
    Time m_receiveDelay2;

    /**
     * The duration of a receive window
     */
    Time m_receiveWindowDuration;

    /**
     * The event of the closing of a receive window.
     * This EventId will be canceled if there's a successful reception of a
     * packet.
     */
    EventId m_closeWindow;

    /**
     * The event of the second receive window opening.
     * This EventId is used to cancel the second window in case the first one
     * is successful.
     */
    EventId m_secondReceiveWindow;

    /**
     * The next, autonomously scheduled, send event. This event is scheduled if
     * a packet cannot be sent immediately. This acts as a queue containing a
     * single element, and blocks new arrivals from the Application layer until
     * it this packet is sent.
     */
    EventId m_resend;

    /**
     * The logical channel this device is currently listening to
     */
    Ptr<LogicalLoraChannel> m_currentLogicalChannel;

    /**
     * The address of this MAC
     */
    LoraDeviceAddress m_address;
  };

} /* namespace ns3 */

#endif /* END_DEVICE_LORA_MAC_H */
