/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef END_DEVICE_LORA_PHY_H
#define END_DEVICE_LORA_PHY_H

#include "ns3/object.h"
#include "ns3/net-device.h"
#include "ns3/nstime.h"
#include "ns3/mobility-model.h"
#include "ns3/node.h"
#include "ns3/lora-phy.h"

namespace ns3 {

  class LoraChannel;

  class EndDeviceLoraPhy : public LoraPhy
  {
  public:

    /**
     * In EndDeviceLoraPhy, it makes sense to define a state since there's only
     * one demodulator which can either send, receive, stay idle or go in deep
     * sleep.
     */
    enum State
      {
        /**
         * The PHY layer is sleeping.
         * During sleep, a device cannot receive or transmit messages.
         */
        SLEEP,
        /**
         * The PHY layer is in STANDBY.
         * When the PHY is in this state, it's listening to the channel, and
         * it's also ready to transmit data passed to it by the MAC layer.
         */
        IDLE,//STANDBY
        /**
         * The PHY layer is sending a packet.
         * During transmission, the device cannot receive any packet or send
         * any additional packet.
         */
        TX,
        /**
         * The PHY layer is receiving a packet.
         * While the device is locked on an incoming packet, transmission is
         * not possible.
         */
        RX
      };

    static TypeId GetTypeId (void);

    // Constructor and destructor
    EndDeviceLoraPhy();
    virtual ~EndDeviceLoraPhy();

    Ptr<NetDevice> GetDevice (void) const;

    virtual void StartReceive (Ptr<Packet> packet, double rxPowerDbm,
                               uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);

    virtual void EndReceive (Ptr<Packet> packet,
                             Ptr<LoraInterferenceHelper::Event> event);

    virtual void SetReceiveOkCallback (RxOkCallback callback);

    virtual void SetTxFinishedCallback (TxFinishedCallback callback);

    Ptr<MobilityModel> GetMobility();

    virtual void Send (Ptr<Packet> packet, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);

    double GetTxPowerdBm ();

    void SetTxPowerdBm (double power);

    virtual bool IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel);

    void SetLogicalChannel (Ptr<LogicalLoraChannel> logicalChannel);

    /**
     * Switch to the RX state
     */
    void SwitchToRx (void);

    /**
     * Switch to the TX state
     */
    void SwitchToTx (void);

    /**
     * Switch to the IDLE (=STANDBY) state
     */
    void SwitchToStandby (void);

    /**
     * Switch to the SLEEP state
     */
    void SwitchToSleep (void);

    State m_state; //!< The state this PHY is currently in.

  private:

    double m_txPowerdBm; //<! The EIRP power this device transmits at
    //!< Transmit power (dBm)
    /**
     * The sensitivity required to receive different spreading factors.
     */
    static const double sensitivity[6]; //<! The sensitivity vector of this device to different SFs

    Ptr<LogicalLoraChannel> m_logicalChannel; //<! The number of the channel this transceiver is listening on

  };

} /* namespace ns3 */

#endif /* END_DEVICE_LORA_PHY_H */
