/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LOGICAL_LORA_CHANNEL_H
#define LOGICAL_LORA_CHANNEL_H

#include "ns3/object.h"
#include "ns3/sub-band.h"

namespace ns3 {

  class SubBand;

  /**
   * This class represents a logical LoRaWAN channel. A logical channel has, as
   * its characteristics, a central frequency, a bandwidth and a channel number
   * to help with its identification.
   */
  class LogicalLoraChannel : public Object
  {
  public:

    static TypeId GetTypeId (void);

    LogicalLoraChannel();
    virtual ~LogicalLoraChannel();

    LogicalLoraChannel (double frequency, double bandwidth);
    LogicalLoraChannel (double frequency, double bandwidth, Ptr<SubBand> subBand);

    /**
     * Get the frequency (MHz)
     */
    double GetFrequency (void) const;

    /**
     * Get the bandwidth (MHz)
     */
    double GetBandwidth (void) const;

    /**
     * Get the this channel belongs to
     */
    Ptr<SubBand> GetSubBand (void) const;

  private:
    /**
     * The central frequency of this channel, in MHz
     */
    double m_frequency;

    /**
     * The bandwidth of this channel, in MHz
     */
    double m_bandwidth;

    /**
     * The subband this channel belongs to
     */
    Ptr<SubBand> m_subBand;
  };

  /**
   * Overload of the == operator to compare different instances of the same LogicalLoraChannel
   */
  bool operator== (const Ptr<LogicalLoraChannel>& first, const Ptr<LogicalLoraChannel>& second);

}

#endif /* LOGICAL_LORA_CHANNEL_H */
