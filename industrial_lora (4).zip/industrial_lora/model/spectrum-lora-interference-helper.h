/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#ifndef SPECTRUM_LORA_INTERFERENCE_HELPER_H
#define SPECTRUM_LORA_INTERFERENCE_HELPER_H

#include "ns3/nstime.h"
#include "ns3/simulator.h"
#include "ns3/object.h"
#include "ns3/traced-callback.h"
#include "ns3/callback.h"
#include "ns3/packet.h"
#include "ns3/logical-lora-channel.h"
#include <list>
#include <stdint.h>
#include "ns3/simple-ref-count.h"
#include "ns3/lora-error-rate-model.h"

namespace ns3 {

  class SpectrumLoraInterferenceHelper
  {
  public:
    /**
     * A class representing a signal in time.
     */
    class SpectrumEvent : public SimpleRefCount<SpectrumLoraInterferenceHelper::SpectrumEvent>
    {

    public:

      SpectrumEvent (Time duration, double rxPowerdBm, uint8_t spreadingFactor,
             Ptr<Packet> packet, Ptr<LogicalLoraChannel> logicalLoraChannel);
      ~SpectrumEvent ();

      /**
       * Get the duration of the event
       */
      Time GetDuration (void) const;

      /**
       * Get the starting time of the event
       */
      Time GetStartTime (void) const;

      /**
       * Get the ending time of the event
       */
      Time GetEndTime (void) const;

      /**
       * Get the power of the event
       */
      double GetRxPowerdBm (void) const;

      /**
       * Get the spreading factor used by this signal
       */
      uint8_t GetSpreadingFactor (void) const;

      /**
       * Get the packet this event was generated for
       */
      Ptr<Packet> GetPacket (void) const;

      /**
       * Get the number of the channel this event was on
       */
      Ptr<LogicalLoraChannel> GetLogicalChannel (void) const;

    private:

      /**
       * The time this signal begins (at the device)
       */
      Time m_startTime;

      /**
       * The time this signal ends (at the device)
       */
      Time m_endTime;

      /**
       * The spreading factor of this signal
       */
      uint8_t m_sf;

      /**
       * The power of this event in dBm (at the device)
       */
      double m_rxPowerdBm;

      /**
       * The packet this event was generated for
       */
      Ptr<Packet> m_packet;

      /**
       * The number of the channel this event was on
       */
      Ptr<LogicalLoraChannel> m_logicalChannel;

    };

    static TypeId GetTypeId (void);

    SpectrumLoraInterferenceHelper();
    virtual ~SpectrumLoraInterferenceHelper();
    
   /**
     * Set the noise figure (in Db).
     *
     * \param value noise figure (Db)
     */
    void SetNoiseFigure (double value);
    /**
     * Set the error rate model for this interference helper.
     *
     * \param rate Error rate model
     */
    void SetErrorRateModel (Ptr<LoraErrorRateModel> rate);

    /**
     * Return the noise figure (in Db).
     *
     * \return the noise figure
     */
    double GetNoiseFigure (void) const;
    /**
     * Return the error rate model.
     *
     * \return Error rate model
     */
    Ptr<LoraErrorRateModel> GetErrorRateModel (void) const;

    /**
     * Add an event to the InterferenceHelper
     * \param duration the duration of the packet
     * \param rxPower the received power in dBm
     * \param spreadingFactor the spreading factor used by the transmission
     * \returns the newly created event
     */
    Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> Add (Time duration, double rxPower,
                                            uint8_t spreadingFactor, Ptr<Packet>
                                            packet, Ptr<LogicalLoraChannel> logicalChannel);
    
    /**
     * Add a non-lora signal to interference helper.
     * \param duration the duration of the signal
     * \param rxPower receive power (W)
     */
    void AddForeignSignal (Time duration, double rxPower); 
    
    /**
     * Calculate the SINR at the start of the packet payload and accumulate
     * all SINR changes in the snir vector.
     *
     * \param event the event corresponding to the first time the corresponding packet arrives
     *
     * \return struct of SINR and PER
     */
    double CalculatePer (Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event);
                                          

    /**
     * Get a list of the interferers currently registered on this
     * InterferenceHelper
     */
    std::list< Ptr< SpectrumLoraInterferenceHelper::SpectrumEvent > > GetInterferers();

  private:
  
    /**
     * typedef for a vector of time values
     */
    typedef std::vector <Time> IntChanges;
  
    /**
     * Calculate changes of interferers.
     *
     * \param event
     * \param ic
     *
     */
    void CalculateInterferenceChanges (Ptr<SpectrumEvent> event, IntChanges *ic) const;	
    
    /**
     * Calculate SNR (linear ratio) from the given signal power 
     *
     * \param signal
     * \param channelWidth
     *
     * \return SNR in linear ratio
     */
    double CalculateSnr (double signal, double channelWidth) const;
    
    /**
     * Calculate the success rate of the chunk given the SINR, duration, and SF.
     * The duration and SF are used to calculate how many bits are present in the chunk.
     *
     * \param sinr SINR
     * \param duration
     * \param sf
     *
     * \return the success rate
     */
    double CalculateChunkSuccessRate (double sinr, Time duration, uint8_t sf, double channelWidthHz) const;
    
	double m_noiseFigureDb; /**< noise figure (dB) */
	Ptr<LoraErrorRateModel> m_errorRateModel;

    /**
     * A list of the events this LoraInterferenceHelper is keeping track of.
     */
    std::list< Ptr< SpectrumLoraInterferenceHelper::SpectrumEvent > > m_events;
    
    /**
     * The matrix containing information about equivalent SIR computation.
     */
    static const double equivalentSirFactor[6][6];

  };
}

#endif /* SPECTRUM_LORA_INTERFERENCE_HELPER_H */
