/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#include <ns3/ptr.h>
#include <ns3/object.h>
#include <ns3/net-device.h>
#include <ns3/mobility-model.h>
#include <ns3/lora-phy.h>
#include <ns3/spectrum-phy.h>
#include <ns3/spectrum-signal-parameters.h>
#include <ns3/log.h>
#include <ns3/spectrum-value.h>
#include <ns3/antenna-model.h>
#include "ns3/lora-end-device-spectrum-phy-interface.h"
#include "ns3/spectrum-end-device-lora-phy.h"

NS_LOG_COMPONENT_DEFINE ("LoraEndDeviceSpectrumPhyInterface");

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (LoraEndDeviceSpectrumPhyInterface);

TypeId
LoraEndDeviceSpectrumPhyInterface::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoraEndDeviceSpectrumPhyInterface")
    .SetParent<SpectrumPhy> ()
    .SetGroupName ("Lora");
  return tid;
}

LoraEndDeviceSpectrumPhyInterface::LoraEndDeviceSpectrumPhyInterface ()
{
  NS_LOG_FUNCTION (this);
}

void
LoraEndDeviceSpectrumPhyInterface::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  m_spectrumEdLoraPhy = 0;
  m_netDevice = 0;
  m_channel = 0;
}

void LoraEndDeviceSpectrumPhyInterface::SetSpectrumLoraPhy (Ptr<SpectrumEndDeviceLoraPhy> spectrumEdLoraPhy)
{
  m_spectrumEdLoraPhy = spectrumEdLoraPhy;
}

Ptr<NetDevice>
LoraEndDeviceSpectrumPhyInterface::GetDevice () const
{
  return m_netDevice;
}

Ptr<MobilityModel>
LoraEndDeviceSpectrumPhyInterface::GetMobility ()
{
  return m_spectrumEdLoraPhy->GetMobility ();
}

void
LoraEndDeviceSpectrumPhyInterface::SetDevice (Ptr<NetDevice> d)
{
  m_netDevice = d;
}

void
LoraEndDeviceSpectrumPhyInterface::SetMobility (Ptr<MobilityModel> m)
{
  m_spectrumEdLoraPhy->SetMobility (m);
}

void
LoraEndDeviceSpectrumPhyInterface::SetChannel (Ptr<SpectrumChannel> c)
{
  NS_LOG_FUNCTION (this << c);
  m_channel = c;
}

Ptr<const SpectrumModel>
LoraEndDeviceSpectrumPhyInterface::GetRxSpectrumModel () const
{
  // EndDevice reception is currently not supported	
  return 0;
}

Ptr<AntennaModel>
LoraEndDeviceSpectrumPhyInterface::GetRxAntenna (void)
{
  NS_LOG_FUNCTION (this);
  return m_spectrumEdLoraPhy->GetRxAntenna ();
}

void
LoraEndDeviceSpectrumPhyInterface::StartRx (Ptr<SpectrumSignalParameters> params)
{
  m_spectrumEdLoraPhy->StartRx (params);
}


} //namespace ns3
