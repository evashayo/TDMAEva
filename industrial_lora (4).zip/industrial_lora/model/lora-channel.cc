/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/lora-channel.h"
#include "ns3/log.h"
#include "ns3/pointer.h"
#include "ns3/object-factory.h"
#include "ns3/packet.h"
#include "ns3/simulator.h"
#include "ns3/end-device-lora-phy.h"
#include "ns3/gateway-lora-phy.h"
#include <algorithm>

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LoraChannel");

  NS_OBJECT_ENSURE_REGISTERED (LoraChannel);

  TypeId
  LoraChannel::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::LoraChannel")
      .SetParent<Channel> ()
      .SetGroupName ("Lora")
      .AddConstructor<LoraChannel> ()
      .AddAttribute ("PropagationLossModel", "A pointer to the propagation loss model attached to this channel.",
                     PointerValue (),
                     MakePointerAccessor (&LoraChannel::m_loss),
                     MakePointerChecker<PropagationLossModel> ())
      .AddAttribute ("PropagationDelayModel", "A pointer to the propagation delay model attached to this channel.",
                     PointerValue (),
                     MakePointerAccessor (&LoraChannel::m_delay),
                     MakePointerChecker<PropagationDelayModel> ())
      .AddTraceSource ("PacketSent",
                       "Trace source fired whenever a packet goes out on the channel",
                       MakeTraceSourceAccessor (&LoraChannel::m_packetSent),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("BelowChannelThreshold",
                       "Trace source fired whenever a packet is not scheduled for delivery because its power is under the fixed threshold.",
                       MakeTraceSourceAccessor (&LoraChannel::m_belowChannelThreshold),
                       "ns3::Packet::TracedCallback");
    return tid;
  }

  LoraChannel::LoraChannel () : m_dontDeliverThreshold (-10000)
  {
  }

  LoraChannel::~LoraChannel ()
  {
    NS_LOG_FUNCTION_NOARGS ();
    m_phyList.clear ();
  }

  LoraChannel::LoraChannel(Ptr<PropagationLossModel> loss, Ptr<PropagationDelayModel> delay) :
    m_loss (loss),
    m_delay (delay),
    m_dontDeliverThreshold (-10000)
  {
  }

  void
  LoraChannel::Add(Ptr<LoraPhy> phy)
  {
    // Add the new phy to the vector
    m_phyList.push_back(phy);
  }

  void
  LoraChannel::Remove(Ptr<LoraPhy> phy)
  {
    // Remove a phy from the vector
    NS_LOG_FUNCTION (this << phy);
    m_phyList.erase(find(m_phyList.begin(), m_phyList.end(), phy));
  }

  uint32_t
  LoraChannel::GetNDevices (void) const
  {
    return m_phyList.size ();
  }

  Ptr<NetDevice>
  LoraChannel::GetDevice (uint32_t i) const
  {
    return m_phyList[i]->GetDevice ()->GetObject<NetDevice> ();
  }

  void
  LoraChannel::Send (Ptr< LoraPhy > sender, Ptr< Packet > packet,
                     double txPowerDbm, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel) const
  {

    NS_LOG_FUNCTION (this << sender << packet << txPowerDbm <<
                     unsigned(sf) << duration << logicalChannel);

    // Get the mobility model of the sender
    Ptr<MobilityModel> senderMobility = sender->GetMobility ()->GetObject<MobilityModel> ();

    NS_ASSERT (senderMobility != 0);

    NS_LOG_DEBUG ("Sender mobility: " << senderMobility->GetPosition ());
    NS_LOG_DEBUG ("Starting cycle over all " << m_phyList.size() << " PHYs");

    // Cycle over all registered PHYs
    uint32_t j = 0;
    std::vector< Ptr< LoraPhy > >::const_iterator i;
    for (i = m_phyList.begin (); i != m_phyList.end (); i++, j++)
    {
      // *i is the current PHY

      // Do not deliver to the sender
      if (sender != (*i))
      {
        // Only deliver to devices that are on the same logical channel
        NS_LOG_DEBUG ("logicalChannel: " << logicalChannel);
        NS_LOG_DEBUG ("logicalChannel freq: " << logicalChannel->GetFrequency());
        if ((*i)->IsOnChannel (logicalChannel))
        {
          // Get the receiver's mobility model
          Ptr<MobilityModel> receiverMobility = (*i)->GetMobility ()->GetObject<MobilityModel> ();

          NS_LOG_DEBUG ("Receiver mobility: " << receiverMobility->GetPosition ());

          // Compute delay using the delay model
          Time delay = m_delay->GetDelay (senderMobility, receiverMobility);

          // Compute received power using the loss model
          double rxPowerDbm = GetRxPower (txPowerDbm, senderMobility, receiverMobility);

          NS_LOG_DEBUG ("Propagation: txPower=" << txPowerDbm <<
                        "dbm, rxPower=" << rxPowerDbm << "dbm, " <<
                        "distance=" << senderMobility->GetDistanceFrom (receiverMobility) <<
                        "m, delay=" << delay);

          // Block delivery if the power is below the threshold.
          // This is a measure aimed at reducing computational burden
          if (rxPowerDbm < m_dontDeliverThreshold)
          {
            NS_LOG_DEBUG ("Blocking a delivery because power is too low");
            m_belowChannelThreshold (packet);
          }
          else // The receive power is above the threshold: schedule delivery
          {
            // Get the id of the destination PHY to correctly format the context
            NS_LOG_DEBUG ("Getting NetDevice from PHY");
            Ptr<Object> dstNetDevice = m_phyList[j]->GetDevice ();
            NS_LOG_DEBUG ("dstNetDevice " << dstNetDevice);

            uint32_t dstNode = 0;
            if (dstNetDevice != 0)
            {
              NS_LOG_DEBUG ("Getting node index from NetDevice, since it exists");
              dstNode = dstNetDevice->GetObject<NetDevice> ()->GetNode ()->GetId ();
              // NS_ASSERT (dstNode != 0);
              NS_LOG_DEBUG ("dstNode = " << dstNode);
            }
            else
            {
              NS_LOG_DEBUG ("No net device connected to the PHY, using context 0");
            }

            // Create the parameters structure
            struct Parameters parameters;
            parameters.rxPowerDbm = rxPowerDbm;       // Computed above based on mobility
            parameters.sf = sf;                       // Taken from the arguments
            parameters.logicalChannel = logicalChannel; // Taken from the arguments
            parameters.duration = duration;           // Taken from the arguments

            // Schedule the receive event
            NS_LOG_DEBUG ("Scheduling reception of the packet");
            Simulator::ScheduleWithContext (dstNode,
                                            delay, &LoraChannel::Receive, this,
                                            j, packet, parameters);

            // Fire the trace source for sent packet
            m_packetSent (packet);
          }
        }
      }
    }
  }

  void
  LoraChannel::Receive (uint32_t i, Ptr<Packet> packet, struct Parameters parameters) const
  {
    // Call the appropriate PHY instance to make it start receiving the packet
    m_phyList[i]->StartReceive (packet, parameters.rxPowerDbm, parameters.sf, parameters.duration, parameters.logicalChannel);
  }

  double
  LoraChannel::GetRxPower (double txPowerDbm, Ptr<MobilityModel> senderMobility, Ptr<MobilityModel> receiverMobility) const
  {
    return m_loss->CalcRxPower (txPowerDbm, senderMobility, receiverMobility);
  }
}
