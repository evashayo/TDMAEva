/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/logical-lora-channel-helper.h"
#include "ns3/simulator.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LogicalLoraChannelHelper");

  NS_OBJECT_ENSURE_REGISTERED (LogicalLoraChannelHelper);

  TypeId
  LogicalLoraChannelHelper::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::LogicalLoraChannelHelper")
      .SetParent<Object> ()
      .SetGroupName ("Lora");
    return tid;
  }

  LogicalLoraChannelHelper::LogicalLoraChannelHelper ()
  {
    NS_LOG_FUNCTION (this);
  }

  LogicalLoraChannelHelper::~LogicalLoraChannelHelper () {
    NS_LOG_FUNCTION (this);
  }

  std::list<Ptr <LogicalLoraChannel> >
  LogicalLoraChannelHelper::GetChannelList (void)
  {
    return m_channelList;
  }

  void
  LogicalLoraChannelHelper::AddChannel (double frequency, double bandwidth)
  {
    NS_LOG_FUNCTION (this << frequency << bandwidth);

    // Get the SubBand this frequency belongs to
    std::list< Ptr< SubBand > >::iterator it;
    Ptr<SubBand> subBand;
    for (it = m_subBandList.begin(); it != m_subBandList.end(); it++) {
      if ((*it)->BelongsToSubBand (frequency, bandwidth))
        {
          subBand = *it;
          break;
        }
    }
    if (it == m_subBandList.end()) // No SubBand was found
      {
        NS_LOG_ERROR ("Warning: you are attempting to create a channel outside a SubBand. No channel was created.");
      }

    // Create the new channel and increment the counter
    Ptr<LogicalLoraChannel> channel = Create<LogicalLoraChannel> (frequency,
                                                                  bandwidth,
                                                                  subBand);
    // Add it to the list
    m_channelList.push_back (channel);

    NS_LOG_DEBUG ("Added a channel. Current number of channels in list is " <<
                  m_channelList.size());
  }

  void
  LogicalLoraChannelHelper::AddChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << logicalChannel);

    // Add it to the list
    m_channelList.push_back (logicalChannel);
  }

  void
  LogicalLoraChannelHelper::AddSubBand (double firstFrequency, double lastFrequency, double dutyCycle)
  {
    NS_LOG_FUNCTION (this << firstFrequency << lastFrequency);

    Ptr<SubBand> subBand = Create<SubBand> (firstFrequency, lastFrequency, dutyCycle);
    m_subBandList.push_back (subBand);
  }

  void
  LogicalLoraChannelHelper::AddSubBand (Ptr<SubBand> subBand)
  {
    NS_LOG_FUNCTION (this << subBand);

    m_subBandList.push_back (subBand);
  }

  void
  LogicalLoraChannelHelper::RemoveChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    // Search and remove the channel from the list
    std::list< Ptr< LogicalLoraChannel > > list = m_channelList;
    std::list< Ptr< LogicalLoraChannel > >::iterator it;
    Ptr<LogicalLoraChannel> currentChannel;
    for (it = list.begin(); it != list.end(); it++)
      {
        currentChannel = *it;
        if (currentChannel == logicalChannel)
          {
            m_channelList.erase(it);
            return;
          }
      }
    return;
  }

  std::vector<Ptr<LogicalLoraChannel> >
  LogicalLoraChannelHelper::GetLogicalChannels ()
  {
    NS_LOG_FUNCTION (this);

    std::vector<Ptr<LogicalLoraChannel> > vector;
    vector.reserve(m_channelList.size());
    std::copy(m_channelList.begin(), m_channelList.end(), std::back_inserter(vector));

    return vector;
  }

  Time
  LogicalLoraChannelHelper::GetOnAirTime (Ptr<Packet> packet, uint8_t sf, bool headerDisabled, uint8_t cr, double bandwidth, int nPreamble)
  {
    NS_LOG_FUNCTION (packet << unsigned(sf) << headerDisabled << unsigned(cr) <<
                     bandwidth << nPreamble);

    // Compute the symbol duration
    double tSym = pow(2, int(sf))/(bandwidth*1000000); // Bandwidth is in MHz, we need it in Hz
    

    // Compute the preamble duration
    double tPreamble = (double(nPreamble) + 4.25) * tSym;

    // Payload size
    //uint32_t pl = packet->GetSerializedSize(); // Size in bytes OLD WRONG VERSION
    uint32_t pl = packet->GetSize(); // Size in bytes
    
    // DEBUG 08/07/17
    //std::cout << "GOTA: Packet of size (serialized) " << pl << " bytes " << "GOTA: Packet of size (!serialized) " << packet->GetSize() << " bytes ";
    NS_LOG_DEBUG ("Packet of size " << pl << " bytes");

    // de is 1 when the low data rate optimization is enabled,
    // 0 when it is disabled
    bool de = 0;

    double h;
    if (headerDisabled == true) {
      h = 1;
    } else {
      h = 0;
    }

    // Compute the number of symbols that make up the packet header and
    // payload
    double num = 8*pl - 4*sf + 28 + 16 - 20*h;
    double den = 4*(sf - 2*de);
    double payloadSymbNb = 8 + std::max(std::ceil(num/den)*(cr + 4), double(0));

    // Time to transmit the payload
    double tPayload = payloadSymbNb * tSym;
    
    NS_LOG_DEBUG ("Time computation: num = " << num << ", den = " << den <<
                  ", payloadSymbNb = " << payloadSymbNb << ", tSym = " << tSym);
    NS_LOG_DEBUG ("tPreamble = " << tPreamble);
    NS_LOG_DEBUG ("tPayload = " << tPayload);
    NS_LOG_DEBUG ("Total time = " << tPreamble+tPayload);

    // Compute and return the total packet on-air time
    return Seconds (tPreamble + tPayload);
  }

  Time
  LogicalLoraChannelHelper::GetWaitingTime (Ptr<LogicalLoraChannel> channel)
  {
    NS_LOG_FUNCTION (this << channel);

    Time waitingTime = channel->GetSubBand()->GetNextTransmissionTime() - Simulator::Now();

    // Handle case in which waiting time is negative
    waitingTime = Seconds(std::max (waitingTime.GetSeconds(), double(0)));
    NS_LOG_DEBUG ("Waiting time: " << waitingTime.GetSeconds());

    return waitingTime;
  }

  void
  LogicalLoraChannelHelper::AddEvent (Time duration, Ptr<LogicalLoraChannel> channel)
  {
    NS_LOG_FUNCTION (this << duration << channel);

    Ptr<SubBand> subBand = channel->GetSubBand ();

    double dutyCycle = subBand -> GetDutyCycle ();
    double timeOnAir = duration.GetSeconds ();

    subBand -> SetNextTransmissionTime (Simulator::Now () + Seconds(timeOnAir/dutyCycle - timeOnAir));

    NS_LOG_DEBUG ("Current time: " << Simulator::Now ().GetSeconds());
    NS_LOG_DEBUG ("Next transmission allowed at time: " <<
                  (subBand->GetNextTransmissionTime()).GetSeconds());
  }
}
