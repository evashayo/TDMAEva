/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#include <ns3/ptr.h>
#include <ns3/object.h>
#include <ns3/net-device.h>
#include <ns3/mobility-model.h>
#include <ns3/lora-phy.h>
#include <ns3/spectrum-phy.h>
#include <ns3/spectrum-signal-parameters.h>
#include <ns3/log.h>
#include <ns3/spectrum-value.h>
#include <ns3/antenna-model.h>
#include "ns3/lora-gateway-spectrum-phy-interface.h"
#include "ns3/spectrum-gateway-lora-phy.h"

NS_LOG_COMPONENT_DEFINE ("LoraGatewaySpectrumPhyInterface");

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (LoraGatewaySpectrumPhyInterface);

TypeId
LoraGatewaySpectrumPhyInterface::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoraGatewaySpectrumPhyInterface")
    .SetParent<SpectrumPhy> ()
    .SetGroupName ("Lora");
  return tid;
}

LoraGatewaySpectrumPhyInterface::LoraGatewaySpectrumPhyInterface ()
{
  NS_LOG_FUNCTION (this);
}

void
LoraGatewaySpectrumPhyInterface::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  m_spectrumGwLoraPhy = 0;
  m_netDevice = 0;
  m_channel = 0;
}

void LoraGatewaySpectrumPhyInterface::SetSpectrumLoraPhy (Ptr<SpectrumGatewayLoraPhy> spectrumGwLoraPhy)
{
  m_spectrumGwLoraPhy = spectrumGwLoraPhy;
}

void LoraGatewaySpectrumPhyInterface::SetIndex (uint8_t index)
{
  m_index = index;	
}

Ptr<NetDevice>
LoraGatewaySpectrumPhyInterface::GetDevice () const
{
  return m_netDevice;
}

Ptr<MobilityModel>
LoraGatewaySpectrumPhyInterface::GetMobility ()
{
  return m_spectrumGwLoraPhy->GetMobility ();
}

void
LoraGatewaySpectrumPhyInterface::SetDevice (Ptr<NetDevice> d)
{
  m_netDevice = d;
}

void
LoraGatewaySpectrumPhyInterface::SetMobility (Ptr<MobilityModel> m)
{
  m_spectrumGwLoraPhy->SetMobility (m);
}

void
LoraGatewaySpectrumPhyInterface::SetChannel (Ptr<SpectrumChannel> c)
{
  NS_LOG_FUNCTION (this << c);
  m_channel = c;
}

Ptr<const SpectrumModel>
LoraGatewaySpectrumPhyInterface::GetRxSpectrumModel () const
{
  return m_spectrumGwLoraPhy->GetRxSpectrumModel (m_index);
}

Ptr<AntennaModel>
LoraGatewaySpectrumPhyInterface::GetRxAntenna (void)
{
  NS_LOG_FUNCTION (this);
  return m_spectrumGwLoraPhy->GetRxAntenna ();
}

void
LoraGatewaySpectrumPhyInterface::StartRx (Ptr<SpectrumSignalParameters> params)
{
  m_spectrumGwLoraPhy->StartRx (params);
}


} //namespace ns3
