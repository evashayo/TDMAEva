/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/logical-lora-channel.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LogicalLoraChannel");

  NS_OBJECT_ENSURE_REGISTERED (LogicalLoraChannel);

  TypeId
  LogicalLoraChannel::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::LogicalLoraChannel")
      .SetParent<Object> ()
      .SetGroupName ("Lora");
    return tid;
  }

  LogicalLoraChannel::LogicalLoraChannel () :
    m_frequency (0),
    m_bandwidth (0.125) // Sensible default, based on LoraWAN

  {
    NS_LOG_FUNCTION (this);
  }

  LogicalLoraChannel::~LogicalLoraChannel () {
    NS_LOG_FUNCTION (this);
  }

  LogicalLoraChannel::LogicalLoraChannel (double frequency, double bandwidth) :
    m_frequency (frequency),
    m_bandwidth (bandwidth)
  {
    NS_LOG_FUNCTION (this);
  }

  LogicalLoraChannel::LogicalLoraChannel (double frequency, double bandwidth, Ptr<SubBand> subBand) :
    m_frequency (frequency),
    m_bandwidth (bandwidth),
    m_subBand (subBand)
  {
    NS_LOG_FUNCTION (this);
  }

  double
  LogicalLoraChannel::GetFrequency (void) const
  {
    return m_frequency;
  }

  double
  LogicalLoraChannel::GetBandwidth (void) const
  {
    return m_bandwidth;
  }

  Ptr<SubBand>
  LogicalLoraChannel::GetSubBand (void) const
  {
    return m_subBand;
  }

  bool
  operator==(const Ptr<LogicalLoraChannel>& first, const Ptr<LogicalLoraChannel>& second)
  {
    NS_LOG_DEBUG ("Checking equality between logical lora channels");

    double thisFreq = first->GetFrequency();
    double thisBw = first->GetBandwidth();
    double otherFreq = second->GetFrequency();
    double otherBw = second->GetBandwidth();

    NS_LOG_DEBUG ("Checking equality between logical lora channels: " << thisFreq << " " << thisBw << " " << otherFreq << " " << otherBw);

    return ((thisFreq == otherFreq) && (thisBw == otherBw));
  }
}
