/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include <algorithm>
#include "ns3/end-device-lora-phy.h"
#include "ns3/simulator.h"
#include "ns3/logical-lora-channel.h"
#include "ns3/lora-tag.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("EndDeviceLoraPhy");

  NS_OBJECT_ENSURE_REGISTERED (EndDeviceLoraPhy);

  TypeId
  EndDeviceLoraPhy::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::EndDeviceLoraPhy")
      .SetParent<LoraPhy> ()
      .SetGroupName ("Lora")
      .AddConstructor<EndDeviceLoraPhy> ();
    return tid;
  }

  // Constructor
  EndDeviceLoraPhy::EndDeviceLoraPhy () :
    //m_state (STANDBY),
    m_state (IDLE),
    m_txPowerdBm (14) // Sensible default based on european regulations
  {
    // TODO Initialize m_logicalChannel
    m_logicalChannel = CreateObject<LogicalLoraChannel> (868.1, 0.125);
    NS_LOG_FUNCTION_NOARGS ();
  }

  EndDeviceLoraPhy::~EndDeviceLoraPhy ()
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  // Downlink sensitivity (from Lebreton)
  // {SF7, SF8, SF9, SF10, SF11, SF12}
  const double EndDeviceLoraPhy::sensitivity[6] =
    {-124.5, -127, -129.5, -132, -134.5, -137};

  double
  EndDeviceLoraPhy::GetTxPowerdBm ()
  {
    return m_txPowerdBm;
  }

  void
  EndDeviceLoraPhy::SetTxPowerdBm (double power)
  {
    m_txPowerdBm = power;
  }

  void
  EndDeviceLoraPhy::Send (Ptr<Packet> packet, uint8_t sf, Time duration,
                          Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << packet << unsigned(sf) << duration << logicalChannel);

    // We must be either in idle (=standby) or sleep to send a packet
    //NS_ASSERT (m_state == STANDBY || m_state == SLEEP);
    NS_ASSERT (m_state == IDLE || m_state == SLEEP);

    // Switch to the TX state
    SwitchToTx ();

    // Tag the packet with information about its Spreading Factor
    LoraTag tag (sf);
    packet->AddPacketTag (tag);

    // Send the packet over the channel
    NS_LOG_INFO ("Sending the packet in the channel");
    m_channel -> Send (this, packet, m_txPowerdBm, sf, duration,
                       logicalChannel);

    // Schedule the callback, if it was set by an upper layer
    if (!m_txFinishedCallback.IsNull ())
      {
        Simulator::Schedule (duration, &EndDeviceLoraPhy::m_txFinishedCallback,
                             this, packet);
      }

    m_startSending (packet);
  }

  void
  EndDeviceLoraPhy::StartReceive (Ptr<Packet> packet, double rxPowerDbm, uint8_t
                                  sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel)
  {

    NS_LOG_FUNCTION (this << packet << rxPowerDbm << unsigned(sf) << logicalChannel);

    // Notify the LoraInterferenceHelper of the impinging signal, and remember
    // the event it creates. This will be used then to correctly handle the end
    // of reception event.

    Ptr<LoraInterferenceHelper::Event> event;
    event = m_interference.Add (duration, rxPowerDbm, sf, packet, logicalChannel);

    // Switch on the current PHY state
    switch (m_state) {
      // In these cases, we cannot receive the packet: we only add it to the
      // list of interferers and do not schedule an EndReceive event for it.
    case SLEEP:
      {
        NS_LOG_INFO ("Dropping packet because device is in SLEEP state");
        break;
      }
    case TX:
      {
        NS_LOG_INFO ("Dropping packet because device is in TX state");
        break;
      }
    case RX:
      {
        NS_LOG_INFO ("Dropping packet because device is already in RX state");
        break;
      }
      // If we are in IDLE (=STANDBY) mode, we can lock on the current packet.
    //case STANDBY:
    case IDLE:
      {
        // See whether the reception power is above or below the sensitivity for
        // that spreading factor.
        double sensitivity = EndDeviceLoraPhy::sensitivity[unsigned(sf)-7];

        if (rxPowerDbm < sensitivity)
          {
            NS_LOG_INFO ("Dropping packet reception of packet with sf = " <<
                         unsigned(sf) << " because under the sensitivity of " <<
                         sensitivity << " dBm");

            // Fire the trace source for this event.
            m_underSensitivity(packet);
          }
        else
          {
            NS_LOG_INFO ("Scheduling reception of a packet");

            // Switch to RX state
            m_state = RX;

            // Schedule the end of the reception of the packet
            Simulator::Schedule (duration, &LoraPhy::EndReceive, this, packet,
                                 event);

            // Fire the beginning of reception trace source
            m_phyRxBeginTrace (packet);
          }
      }
    }
  }

  void
  EndDeviceLoraPhy::EndReceive (Ptr<Packet> packet,
                                Ptr<LoraInterferenceHelper::Event> event)
  {
    NS_LOG_FUNCTION (this << packet << event);

    // Call the LoraInterferenceHelper to determine whether there was
    // destructive interference on our event.
    bool packetDestroyed = m_interference.IsDestroyedByInterference(event);

    // Fire the trace source if packet was destroyed
    if (packetDestroyed)
      {
        NS_LOG_INFO ("Packet destroyed by interference");

        m_interferedPacket(packet);

        // Handle state
        SwitchToStandby ();
      }
    else
      {
        NS_LOG_INFO ("Packet received correctly");

        // If there is one, perform the callback to inform the upper layer
        if (!m_rxOkCallback.IsNull ())
          {
            m_rxOkCallback (packet);
          }

        SwitchToStandby ();
      }
  }

  void
  EndDeviceLoraPhy::SetReceiveOkCallback (RxOkCallback callback)
  {
    m_rxOkCallback = callback;
  }

  void
  EndDeviceLoraPhy::SetTxFinishedCallback (TxFinishedCallback callback)
  {
    m_txFinishedCallback = callback;
  }

  bool
  EndDeviceLoraPhy::IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    // EndDeviceLoraPhys, differently from GatewayLoraPhys, can be only on one
    // channel at a time.

    NS_LOG_DEBUG ("m_logicalChannel: " << m_logicalChannel);

    return m_logicalChannel == logicalChannel;
  }

  void
  EndDeviceLoraPhy::SetLogicalChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    m_logicalChannel = logicalChannel;
  }

  void
  EndDeviceLoraPhy::SwitchToStandby (void)
  {
    m_state = IDLE;//m_state = STANDBY;
  }

  void
  EndDeviceLoraPhy::SwitchToRx (void)
  {
    m_state = RX;
  }

  void
  EndDeviceLoraPhy::SwitchToTx (void)
  {
    m_state = TX;
  }

  void
  EndDeviceLoraPhy::SwitchToSleep (void)
  {
    m_state = SLEEP;
  }
}
