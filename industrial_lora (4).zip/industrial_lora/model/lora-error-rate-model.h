/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#ifndef LORA_ERROR_RATE_MODEL_H
#define LORA_ERROR_RATE_MODEL_H

#include <stdint.h>
#include "ns3/object.h"

namespace ns3 {
/**
 * \ingroup lora
 * \brief the interface for Wifi's error models
 *
 */
class LoraErrorRateModel : public Object
{
public:
  static TypeId GetTypeId (void);
  
  LoraErrorRateModel ();

  /**
   * \param sf the used spreading factor
   * \param ber a target ber
   *
   * \return the snr which corresponds to the requested ber
   */
  double CalculateSnr (uint8_t sf, double ber) const;

  /**
   * 
   * This method returns the probability that the given 'chunk' of the
   * packet will be successfully received by the PHY.
   *
   * A chunk can be viewed as a part of a packet with equal SNR.
   * The probability of successfully receiving the chunk depends on
   * the mode, the SNR, and the size of the chunk.
   *
   * \param sf the used spreading factor
   * \param sinr the SINR of the chunk
   * \param nbits the number of bits in this chunk
   *
   * \return probability of successfully receiving the chunk
   */
  double GetChunkSuccessRate (uint8_t sf, double sinr, uint32_t nbits)  const;
  
private:

  static const double berSf7[51]; 
  static const double berSf8[51];
  static const double berSf9[51];
  static const double berSf10[51];
  static const double berSf11[51];
  static const double berSf12[51];

  /**
   * Return Chunk Success Rate of SF7 at the given SINR.
   *
   * \param sinr sinr ratio (not dB)
   * \param nbits the number of bits in the chunk
   *
   * \return CSR of SF7 at the given SINR
   */
  double GetSf7Csr (double sinr, uint32_t nbits) const;
  /**
   * Return Chunk Success Rate of SF8 at the given SINR.
   *
   * \param sinr sinr ratio (not dB)
   * \param nbits the number of bits in the chunk
   *
   * \return CSR of SF8 at the given SINR
   */
  double GetSf8Csr (double sinr, uint32_t nbits) const;
  /**
   * Return Chunk Success Rate of SF9 at the given SINR.
   *
   * \param sinr sinr ratio (not dB)
   * \param nbits the number of bits in the chunk
   *
   * \return CSR of SF9 at the given SINR
   */
  double GetSf9Csr (double sinr, uint32_t nbits) const;
  /**
   * Return Chunk Success Rate of SF10 at the given SINR.
   *
   * \param sinr sinr ratio (not dB)
   * \param nbits the number of bits in the chunk
   *
   * \return CSR of SF10 at the given SINR
   */
  double GetSf10Csr (double sinr, uint32_t nbits) const;
  /**
   * Return Chunk Success Rate of SF11 at the given SINR.
   *
   * \param sinr sinr ratio (not dB)
   * \param nbits the number of bits in the chunk
   *
   * \return CSR of SF11 at the given SINR
   */
  double GetSf11Csr (double sinr, uint32_t nbits) const;
  /**
   * Return Chunk Success Rate of SF12 at the given SINR.
   *
   * \param sinr sinr ratio (not dB)
   * \param nbits the number of bits in the chunk
   *
   * \return CSR of SF12 at the given SINR
   */
  double GetSf12Csr (double sinr, uint32_t nbits) const;

};

} //namespace ns3

#endif /* LORA_ERROR_RATE_MODEL_H */

