/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Davide Magrin <magrinda@dei.unipd.it>, Romagnolo Stefano <romagnolostefano93@gmail.com>
 */

#include "ns3/lora-tag.h"
#include "ns3/tag.h"
#include "ns3/uinteger.h"

namespace ns3 {

  NS_OBJECT_ENSURE_REGISTERED (LoraTag);

  TypeId
  LoraTag::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::LoraTag")
      .SetParent<Tag> ()
      .SetGroupName("lora")
      .AddConstructor<LoraTag> ()
      ;
    return tid;
  }

  TypeId
  LoraTag::GetInstanceTypeId (void) const
  {
    return GetTypeId ();
  }

  LoraTag::LoraTag ()
  {
  }

  LoraTag::LoraTag (uint8_t sf)
    : m_sf (sf)
  {
  }

  LoraTag::LoraTag (uint8_t sf, uint32_t id)
    : m_sf (sf), m_id (id)
  {
  }

  LoraTag::LoraTag (uint8_t sf, uint8_t destroyedBy)
    : m_sf (sf), m_destroyedBy (destroyedBy)
  {
  }
  
  LoraTag::LoraTag (uint32_t id, uint8_t destroyedBy)
    : m_destroyedBy (destroyedBy), m_id (id)
  {
  }
  
  LoraTag::LoraTag (uint8_t sf, uint8_t destroyedBy, uint32_t id)
    : m_sf (sf), m_destroyedBy (destroyedBy), m_id (id)
  {
  }

  LoraTag::~LoraTag ()
  {
  }

  uint32_t
  LoraTag::GetSerializedSize (void) const
  {
    return 6; // Each datum about a SF is 8 bits
  }

  void
  LoraTag::Serialize (TagBuffer i) const
  {
    i.WriteU8 (m_sf);
    i.WriteU8 (m_destroyedBy);
    i.WriteU32 (m_id);
  }

  void
  LoraTag::Deserialize (TagBuffer i)
  {
    m_sf = i.ReadU8 ();
    m_destroyedBy = i.ReadU8();
    m_id = i.ReadU32 ();
  }

  void
  LoraTag::Print (std::ostream &os) const
  {
    os << m_sf << m_destroyedBy << m_id;
  }

  uint8_t
  LoraTag::GetSpreadingFactor () const
  {
    return m_sf;
  }

  uint8_t
  LoraTag::GetDestroyedBy () const
  {
    return m_destroyedBy;
  }

  void
  LoraTag::SetDestroyedBy (uint8_t sf)
  {
    m_destroyedBy = sf;
  }

  void
  LoraTag::SetSpreadingFactor (uint8_t sf)
  {
    m_sf = sf;
  }
  void
  LoraTag::SetSenderId(uint32_t id)
  {
	  m_id = id;
  }
  uint32_t
  LoraTag::GetSenderId () const
  {
    return m_id;
  }

} // namespace ns3

