/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/end-device-lora-mac.h"
#include "ns3/end-device-lora-phy.h"
#include "ns3/spectrum-end-device-lora-phy.h"
#include "ns3/simulator.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("EndDeviceLoraMac");

  NS_OBJECT_ENSURE_REGISTERED (EndDeviceLoraMac);

  TypeId
  EndDeviceLoraMac::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::EndDeviceLoraMac")
      .SetParent<LoraMac> ()
      .SetGroupName ("Lora")
      .AddConstructor<EndDeviceLoraMac> ();
    return tid;
  }

  EndDeviceLoraMac::EndDeviceLoraMac () :
    m_spreadingFactor (12),                 // Start with conservative settings
    m_codingRate (1),                       // LoraWAN default
    m_headerDisabled (0),                   // LoraWAN default
    m_receiveDelay1 (Seconds (1)),          // LoraWAN default
    m_receiveDelay2 (Seconds (2)),          // LoraWAN default
    m_receiveWindowDuration (Seconds (0.5)) // LoraWAN default
  {
    NS_LOG_FUNCTION (this);

    // Add SubBands to the m_channelHelper. These should be immutable
    // for the whole simulation.
    Ptr<SubBand> subBand1 = CreateObject<SubBand> (868, 868.6, 0.01);
    m_channelHelper.AddSubBand (subBand1);
    Ptr<SubBand> subBand2 = CreateObject<SubBand> (868.7, 869.2, 0.001);
    m_channelHelper.AddSubBand (subBand2);
    Ptr<SubBand> subBand3 = CreateObject<SubBand> (869.4, 869.65, 0.1);
    m_channelHelper.AddSubBand (subBand3);
    // These are assumed to be used by the whole LoRaWAN network.
    Ptr<LogicalLoraChannel> lc1 = CreateObject<LogicalLoraChannel> (868.10, 0.125, subBand1);  // LC1, uplink 1% Duty Cycle
    Ptr<LogicalLoraChannel> lc2 = CreateObject<LogicalLoraChannel> (868.30, 0.125, subBand1);  // LC2, uplink 1% Duty Cycle
    Ptr<LogicalLoraChannel> lc3 = CreateObject<LogicalLoraChannel> (868.50, 0.125, subBand1);  // LC3, uplink 1% Duty Cycle
    // Ptr<LogicalLoraChannel> lc6 = CreateObject<LogicalLoraChannel> (869.525, 0.125, subBand3);  // LC6, downlink 1% Duty Cycle
    m_channelHelper.AddChannel (lc1);
    m_channelHelper.AddChannel (lc2);
    m_channelHelper.AddChannel (lc3);
    // m_channelHelper.AddChannel (lc6);

    // Ptr<LogicalLoraChannel> lc4 = CreateObject<LogicalLoraChannel> (868.85, 0.125);  // LC4, uplink 1% Duty Cycle
    // Ptr<LogicalLoraChannel> lc5 = CreateObject<LogicalLoraChannel> (869.05, 0.125);  // LC5, uplink 1% Duty Cycle

    // Start the device listening on this channel
    m_currentLogicalChannel = lc1;

    // Initialize the random variable we'll use to decide which channel to
    // transmit on
    m_uniformRV = CreateObject<UniformRandomVariable> ();
  }

  EndDeviceLoraMac::~EndDeviceLoraMac ()
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  void
  EndDeviceLoraMac::SetSpreadingFactor (uint8_t sf)
  {
    m_spreadingFactor = sf;
  }

  uint8_t
  EndDeviceLoraMac::GetSpreadingFactor (void)
  {
    return m_spreadingFactor;
  }

  void
  EndDeviceLoraMac::Send(Ptr<Packet> packet)
  {
    NS_LOG_FUNCTION (this << packet);
    
    //DEBUG
    //std::cout << "packet size (packet->GetSize()) " << packet->GetSize() << " ";

    NS_LOG_DEBUG ("Current Time: " << Simulator::Now ().GetSeconds());

    // Enable this block to block transmission or scheduling of new packets
    // If there is an event that was previously scheduled, don't do anything
    // if (!Simulator::IsExpired (m_resend))
    //   {
    //     NS_LOG_DEBUG ("Not sending the packet because there's already one in the queue");
    //     return;
    //   }

    // Add the Lora frame header to the packet
    // TODO: Expand this section to support multiple options
    LoraFrameHeader frameHdr;
    frameHdr.SetFPort (uint8_t(1));
    packet->AddHeader(frameHdr);
    //DEBUG
    //std::cout << "packet size with fhdr (packet->GetSize()) " << packet->GetSize() << " ";

    // Add the Lora Mac header to the packet
    LoraMacHeader macHdr;
    macHdr.SetMType (LoraMacHeader::UNCONFIRMED_DATA_UP);
    packet->AddHeader(macHdr);
    //DEBUG
    //std::cout << "packet size with mhdr (packet->GetSize()) " << packet->GetSize() << " ";

    // Generate a vector of channel numbers and shuffle it
    std::vector<Ptr<LogicalLoraChannel> > logicalChannels;
    logicalChannels = m_channelHelper.GetLogicalChannels ();
    logicalChannels = Shuffle (logicalChannels);

    // Initialize the shortest waiting time in any of the logical channels
    Time shortestWaitingTime = Time::Max();

    // Try every channel
    std::vector<Ptr<LogicalLoraChannel> >::iterator it;
    for (it = logicalChannels.begin (); it != logicalChannels.end(); ++it)
      {

        Ptr<LogicalLoraChannel> logicalChannel = *it;
        NS_ASSERT (logicalChannel != NULL);

        double frequency = logicalChannel->GetFrequency ();
        NS_LOG_DEBUG ("Frequency of the current channel: " << frequency);

        // Verify that we can send the packet
        Time waitingTime = m_channelHelper.GetWaitingTime (logicalChannel);

        // Update the shortest waiting time
        if (waitingTime < shortestWaitingTime)
          {
            shortestWaitingTime = waitingTime;
            NS_LOG_DEBUG ("Shortest waiting time is " << waitingTime.GetSeconds());
          }

        NS_LOG_DEBUG ("Waiting time for current channel = " <<
                      waitingTime.GetSeconds());

        if (waitingTime == Seconds(0))
          {
            Simulator::Cancel (m_resend); // We will send immediately
            
            if (m_spectrumPhy)
              {
			    m_phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SwitchToStandby ();
			  }
			else
			  {
			    m_phy->GetObject<EndDeviceLoraPhy> ()->SwitchToStandby ();	  
			  }

            Time duration = m_channelHelper.GetOnAirTime (packet,
                                                             m_spreadingFactor,
                                                             m_headerDisabled, m_codingRate,
                                                             logicalChannel->GetBandwidth (), 8);
            // DEBUG 05/07/17
            //std::cout << "ToA " << duration.GetSeconds() << std::endl;

            // Register the sent packet into the DutyCycleHelper
            m_channelHelper.AddEvent (duration, logicalChannel);

            /*
             * Compute the duration on air of the packet. The packet handled to this
             * layer is assumed to already have the MAC header, and the GetOnAirTime
             * takes into account the PHY preamble for its computations.
             */
            NS_LOG_DEBUG ("Computed on-air time: " << duration.GetSeconds() <<
                          " seconds");

            // Immediately send the packet.
            // This also makes the PHY switch to the TX state.
            m_phy->Send (packet, m_spreadingFactor, duration, logicalChannel);

            // Switch the PHY to the channel so that it will listen here for downlink
            if (m_spectrumPhy)
              {
			    m_phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SetLogicalChannel (logicalChannel);
			  }
			else
			  {
			   m_phy->GetObject<EndDeviceLoraPhy> ()->SetLogicalChannel (logicalChannel);	  
			  }

            return;
          }
        else
          {
            NS_LOG_DEBUG ("Packet cannot be immediately transmitted on " <<
                          "the current channel because of duty cycle limitations");
          }
      }
    m_cannotSendBecauseDutyCycle (packet);

    // Schedule the retransmission as soon as possible
    NS_LOG_DEBUG ("Canceling old resend event and scheduling a new one");
    Simulator::Cancel (m_resend);
    m_resend = Simulator::Schedule (shortestWaitingTime,
                                    &EndDeviceLoraMac::Send, this, packet);
  }

  void
  EndDeviceLoraMac::Receive(Ptr<Packet> packet)
  {
    NS_LOG_FUNCTION (this << packet);

    bool messageForUs = false;

    // TODO: Determine whether this packet is for us

    if (messageForUs)
      {
        // Cancel the closeWindow event
        // Simulator::Cancel (m_secondReceiveWindow);

        // Turn PHY layer to SLEEP mode
        if (m_spectrumPhy)
          {
		    m_phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SwitchToSleep ();
		  }
		else
		  {
		    m_phy->GetObject<EndDeviceLoraPhy> ()->SwitchToSleep ();	  
		  }
      }
    else
      {
        // Schedule the opening of the second receive window
        m_secondReceiveWindow = Simulator::Schedule (m_receiveDelay2,
                                                     &EndDeviceLoraMac::OpenSecondReceiveWindow,
                                                     this);
      }

    // TODO: Check the incoming message for MAC commands!
  }

  void
  EndDeviceLoraMac::TxFinished (Ptr<Packet> packet)
  {
    NS_LOG_FUNCTION_NOARGS ();

    // Schedule the opening of the first receive window
    Simulator::Schedule (m_receiveDelay1, &EndDeviceLoraMac::OpenFirstReceiveWindow,
                         this);
   
    // Turn PHY layer to SLEEP mode
    if (m_spectrumPhy)
      {
	    m_phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SwitchToSleep ();
	  }
	else
	  {
	    m_phy->GetObject<EndDeviceLoraPhy> ()->SwitchToSleep ();	  
	  }
  }

  void
  EndDeviceLoraMac::OpenFirstReceiveWindow (void)
  {
    NS_LOG_FUNCTION_NOARGS ();

    // Set Phy in Standby mode
    if (m_spectrumPhy)
      {
	    m_phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SwitchToStandby ();
	  }
	else
	  {
	    m_phy->GetObject<EndDeviceLoraPhy> ()->SwitchToStandby ();	  
	  }

    // TODO: Switch to appropriate channel

    // Schedule return to sleep after "at least the time required by the end
    // device's radio transceiver to effectively detect a downlink preamble"
    // (LoraWAN specification)
    m_closeWindow = Simulator::Schedule (m_receiveWindowDuration,
                         &EndDeviceLoraMac::CloseReceiveWindow, this);
  }

  void
  EndDeviceLoraMac::OpenSecondReceiveWindow (void)
  {
    NS_LOG_FUNCTION_NOARGS ();

    // Set Phy in Standby mode
    if (m_spectrumPhy)
      {
	    m_phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SwitchToStandby ();
	  }
	else
	  {
	    m_phy->GetObject<EndDeviceLoraPhy> ()->SwitchToStandby ();	  
	  }

    // TODO: Switch to appropriate channel

    // Schedule return to sleep after "at least the time required by the end
    // device's radio transceiver to effectively detect a downlink preamble"
    // (LoraWAN specification)
    m_closeWindow = Simulator::Schedule (m_receiveWindowDuration,
                                         &EndDeviceLoraMac::CloseReceiveWindow, this);
  }

  Ptr<LogicalLoraChannel>
  EndDeviceLoraMac::GetCurrentLogicalChannel (void)
  {
    NS_LOG_FUNCTION_NOARGS ();

    return m_currentLogicalChannel;
  }

  void
  EndDeviceLoraMac::CloseReceiveWindow (void)
  {
    NS_LOG_FUNCTION_NOARGS ();

    // If we get to this point, it means that no packet was received during the
    // receive window.
    if (m_spectrumPhy)
      {
	    Ptr<SpectrumEndDeviceLoraPhy> phy = m_phy->GetObject<SpectrumEndDeviceLoraPhy> (); 
	    // Check the Phy layer's state:
		// - RX -> We have received a preamble.
		// - STANDBY -> Nothing was detected.
		switch (phy->m_state)
		  {
		  case SpectrumEndDeviceLoraPhy::TX:
			break;
		  case SpectrumEndDeviceLoraPhy::SLEEP:
			break;
		  case SpectrumEndDeviceLoraPhy::RX:
			// PHY is receiving: let it finish
			break;
		  //case SpectrumEndDeviceLoraPhy::STANDBY:
		  case SpectrumEndDeviceLoraPhy::IDLE:
			// Turn PHY layer to sleep
			phy->SwitchToSleep ();
			break;
		  } 
	  }
	else
	  {
	    Ptr<EndDeviceLoraPhy> phy = m_phy->GetObject<EndDeviceLoraPhy> (); 
	    // Check the Phy layer's state:
		// - RX -> We have received a preamble.
		// - STANDBY -> Nothing was detected.
		switch (phy->m_state)
		  {
		  case EndDeviceLoraPhy::TX:
			break;
		  case EndDeviceLoraPhy::SLEEP:
			break;
		  case EndDeviceLoraPhy::RX:
			// PHY is receiving: let it finish
			break;
		  //case EndDeviceLoraPhy::STANDBY:
		  case EndDeviceLoraPhy::IDLE:
			// Turn PHY layer to sleep
			phy->SwitchToSleep ();
			break;
		  }   
	  }

  }

  std::vector<Ptr<LogicalLoraChannel> >
  EndDeviceLoraMac::Shuffle (std::vector<Ptr<LogicalLoraChannel> > vector)
  {
    NS_LOG_FUNCTION_NOARGS ();

    int size = vector.size ();

    for (int i = 0; i < size; ++i)
      {
        uint16_t random = std::floor (m_uniformRV->GetValue (0, size));
        Ptr<LogicalLoraChannel> temp = vector.at (random);
        vector.at (random) = vector.at (i);
        vector.at (i) = temp;
      }

    return vector;
  }

  void
  EndDeviceLoraMac::SetDeviceAddress (LoraDeviceAddress address)
  {
    m_address = address;
  }

  LoraDeviceAddress
  EndDeviceLoraMac::GetDeviceAddress (void)
  {
    NS_LOG_FUNCTION_NOARGS ();

    return m_address;
  }
}
