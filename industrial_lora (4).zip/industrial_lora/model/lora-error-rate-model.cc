/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#include "ns3/lora-error-rate-model.h"
#include <cmath>

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (LoraErrorRateModel);

TypeId LoraErrorRateModel::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoraErrorRateModel")
    .SetParent<Object> ()
    .SetGroupName ("Lora")
    .AddConstructor<LoraErrorRateModel> ()
  ;
  return tid;
}

LoraErrorRateModel::LoraErrorRateModel ()
{
}

double
LoraErrorRateModel::CalculateSnr (uint8_t sf, double ber) const
{
  //This is a very simple binary search.
  double low, high, precision;
  low = 1e-25;
  high = 1e25;
  precision = 1e-12;
  while (high - low > precision)
    {
      NS_ASSERT (high >= low);
      double middle = low + (high - low) / 2;
      if ((1 - GetChunkSuccessRate (sf, middle, 1)) > ber)
        {
          low = middle;
        }
      else
        {
          high = middle;
        }
    }
  return low;
}

double
LoraErrorRateModel::GetChunkSuccessRate (uint8_t sf, double sinr, uint32_t nbits) const
{
  switch (sf) {
  case 7:
    {
      return GetSf7Csr (sinr, nbits); 
    }
  case 8:
    {
      return GetSf8Csr (sinr, nbits); 
    }
  case 9:
    {
      return GetSf9Csr (sinr, nbits); 
    }
  case 10:
    {
      return GetSf10Csr (sinr, nbits); 
    }
  case 11:
    {
      return GetSf11Csr (sinr, nbits); 
    }
  case 12:
    {
      return GetSf12Csr (sinr, nbits); 
    }  
  }
  return 0;
}

// BER vs. SINR for SF7
const double LoraErrorRateModel::berSf7[51] =
    {0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.489415403032721,
		0.485953711093376,
		0.479948124501197,
		0.470331205107741,
		0.461622106943336,
		0.442817238627295,
		0.426536312849162,
		0.392228651237031,
		0.354249800478851,
		0.307811252992817,
		0.241809656823623,
		0.170969672785315,
		0.111053471667997,
		0.0571328810853951,
		0.0218076616121309,
		0.00664405426975259,
		0.00132681564245810,
		0.000239425379090184,
		0.0000199521149241820,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0};
		
// BER vs. SINR for SF8
const double LoraErrorRateModel::berSf8[51] =
	{0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.488425557324841,
		0.479120222929936,
		0.473596735668790,
		0.463425557324841,
		0.446914808917197,
		0.423328025477707,
		0.388614649681529,
		0.345093550955414,
		0.279657643312102,
		0.212340764331210,
		0.139580015923567,
		0.0748706210191083,
		0.0290107484076433,
		0.00858877388535032,
		0.00160230891719745,
		0.000338375796178344,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0};

// BER vs. SINR for SF9
const double LoraErrorRateModel::berSf9[51] =
	{0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.489108713029576,
		0.486520783373301,
		0.482394084732214,
		0.474050759392486,
		0.463169464428457,
		0.440287769784173,
		0.413359312549960,
		0.377098321342926,
		0.322002398081535,
		0.247122302158273,
		0.169294564348521,
		0.0994004796163070,
		0.0429956035171863,
		0.0138189448441247,
		0.00219824140687450,
		0.000259792166266986,
		0.0000499600319744205,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0};
		
// BER vs. SINR for SF10
const double LoraErrorRateModel::berSf10[51] =
	{0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.489010000000000,
		0.482510000000000,
		0.475520000000000,
		0.456020000000000,
		0.430310000000000,
		0.400310000000000,
		0.350110000000000,
		0.283540000000000,
		0.203950000000000,
		0.122990000000000,
		0.0621100000000000,
		0.0191700000000000,
		0.00457000000000000,
		0.000330000000000000,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0};

// BER vs. SINR for SF11
const double LoraErrorRateModel::berSf11[51] =
	{0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.489732854864434,
		0.488596491228070,
		0.485177432216906,
		0.468450956937799,
		0.450548245614035,
		0.422059409888357,
		0.377063397129187,
		0.317583732057416,
		0.235097687400319,
		0.151874003189793,
		0.0759868421052632,
		0.0267543859649123,
		0.00607057416267943,
		0.000757575757575758,
		0.0000598086124401914,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0};

// BER vs. SINR for SF12
const double LoraErrorRateModel::berSf12[51] =
	{0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.500000000000000,
		0.488293650793651,
		0.475605158730159,
		0.466458333333333,
		0.440962301587302,
		0.405248015873016,
		0.345188492063492,
		0.271210317460318,
		0.176755952380952,
		0.0917162698412698,
		0.0334126984126984,
		0.00809523809523810,
		0.00147817460317460,
		0.000168650793650794,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0};

double
LoraErrorRateModel::GetSf7Csr (double sinr, uint32_t nbits) const
{
  // Lookup table for B = 125kHz and 4/5 code rate
  double ber, sinr_min = -40, sinr_max = 10;
  double sinr_db = 10 * std::log10(sinr);
  if (sinr_db < sinr_min)
    {
      return 0.0;
    }
  else if (sinr_db > sinr_max)
    {
      return 1.0;
    }
  else 
    {
      double sinr_curr = sinr_min;
      uint32_t count = 0;
      while (sinr_db > sinr_curr)
        {
		  sinr_curr = sinr_curr + 1.0;
		  count = count + 1;	
		}
	  ber = LoraErrorRateModel::berSf7[count];	
	  return std::pow (1 - ber, static_cast<double> (nbits));	  
	}  
	  
  return 0;
}

double
LoraErrorRateModel::GetSf8Csr (double sinr, uint32_t nbits) const
{
  // Lookup table for B = 125kHz and 4/5 code rate
  double ber, sinr_min = -40, sinr_max = 10;
  double sinr_db = 10 * log10(sinr);
  if (sinr_db < sinr_min)
    {
      return 0.0;
    }
  else if (sinr_db > sinr_max)
    {
      return 1.0;
    }
  else 
    {
      double sinr_curr = sinr_min;
      uint32_t count = 0;
      while (sinr_db > sinr_curr)
        {
		  sinr_curr = sinr_curr + 1.0;
		  count = count + 1;	
		}
	  ber = LoraErrorRateModel::berSf8[count];	
	  return std::pow (1 - ber, static_cast<double> (nbits));	  
	}  
	  
  return 0;
}

double
LoraErrorRateModel::GetSf9Csr (double sinr, uint32_t nbits) const
{
  // Lookup table for B = 125kHz and 4/5 code rate
  double ber, sinr_min = -40, sinr_max = 10;
  double sinr_db = 10 * log10(sinr);
  if (sinr_db < sinr_min)
    {
      return 0.0;
    }
  else if (sinr_db > sinr_max)
    {
      return 1.0;
    }
  else 
    {
      double sinr_curr = sinr_min;
      uint32_t count = 0;
      while (sinr_db > sinr_curr)
        {
		  sinr_curr = sinr_curr + 1.0;
		  count = count + 1;	
		}
	  ber = LoraErrorRateModel::berSf9[count];	
	  return std::pow (1 - ber, static_cast<double> (nbits));	  
	}  
	  
  return 0;
}

double
LoraErrorRateModel::GetSf10Csr (double sinr, uint32_t nbits) const
{
  // Lookup table for B = 125kHz and 4/5 code rate
  double ber, sinr_min = -40, sinr_max = 10;
  double sinr_db = 10 * log10(sinr);
  if (sinr_db < sinr_min)
    {
      return 0.0;
    }
  else if (sinr_db > sinr_max)
    {
      return 1.0;
    }
  else 
    {
      double sinr_curr = sinr_min;
      uint32_t count = 0;
      while (sinr_db > sinr_curr)
        {
		  sinr_curr = sinr_curr + 1.0;
		  count = count + 1;	
		}
	  ber = LoraErrorRateModel::berSf10[count];	
	  return std::pow (1 - ber, static_cast<double> (nbits));	  
	}  
	  
  return 0;
}

double
LoraErrorRateModel::GetSf11Csr (double sinr, uint32_t nbits) const
{
  // Lookup table for B = 125kHz and 4/5 code rate
  double ber, sinr_min = -40, sinr_max = 10;
  double sinr_db = 10 * log10(sinr);
  if (sinr_db < sinr_min)
    {
      return 0.0;
    }
  else if (sinr_db > sinr_max)
    {
      return 1.0;
    }
  else 
    {
      double sinr_curr = sinr_min;
      uint32_t count = 0;
      while (sinr_db > sinr_curr)
        {
		  sinr_curr = sinr_curr + 1.0;
		  count = count + 1;	
		}
	  ber = LoraErrorRateModel::berSf11[count];	
	  return std::pow (1 - ber, static_cast<double> (nbits));	  
	}  
	  
  return 0;
}

double
LoraErrorRateModel::GetSf12Csr (double sinr, uint32_t nbits) const
{

  // Lookup table for B = 125kHz and 4/5 code rate
  double ber, sinr_min = -40, sinr_max = 10;
  double sinr_db = 10 * log10(sinr);
  if (sinr_db < sinr_min)
    {
      return 0.0;
    }
  else if (sinr_db > sinr_max)
    {
      return 1.0;
    }
  else 
    {
      double sinr_curr = sinr_min;
      uint32_t count = 0;
      while (sinr_db > sinr_curr)
        {
		  sinr_curr = sinr_curr + 1.0;
		  count = count + 1;	
		}
	  ber = LoraErrorRateModel::berSf12[count];	
	  return std::pow (1 - ber, static_cast<double> (nbits));	  
	}  
	  
  return 0;
}

} //namespace ns3
