/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/lora-mac.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LoraMac");

  NS_OBJECT_ENSURE_REGISTERED (LoraMac);

  TypeId
  LoraMac::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::LoraMac")
      .SetParent<Object> ()
      .SetGroupName ("Lora")
      .AddTraceSource ("CannotSendBecauseDutyCycle",
                       "Trace source indicating a packet "
                       "could not be sent immediately because of duty cycle limitations",
                       MakeTraceSourceAccessor (&LoraMac::m_cannotSendBecauseDutyCycle),
                       "ns3::Packet::TracedCallback");
    return tid;
  }

  LoraMac::LoraMac () :
    m_spectrumPhy(false) 
  {  
    NS_LOG_FUNCTION (this);
  }

  LoraMac::~LoraMac () {
    NS_LOG_FUNCTION (this);
  }

  void
  LoraMac::SetDevice (Ptr<NetDevice> device)
  {
    m_device = device;
  }

  Ptr<LoraPhy>
  LoraMac::GetPhy (void)
  {
    return m_phy;
  }
  
  void
  LoraMac::SetSpectrumPhy (bool spectrumPhy)
  {
    m_spectrumPhy = spectrumPhy;	  
  }

  void
  LoraMac::SetPhy (Ptr<LoraPhy> phy)
  {
    // Set the phy
    m_phy = phy;
    // Connect the receive callbacks
    m_phy->SetReceiveOkCallback (MakeCallback (&LoraMac::Receive, this));
    m_phy->SetTxFinishedCallback (MakeCallback (&LoraMac::TxFinished, this));
  }
}
