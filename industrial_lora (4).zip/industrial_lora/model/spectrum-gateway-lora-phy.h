/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#ifndef SPECTRUM_GATEWAY_LORA_PHY_H
#define SPECTRUM_GATEWAY_LORA_PHY_H

#include "ns3/object.h"
#include "ns3/net-device.h"
#include "ns3/nstime.h"
#include "ns3/mobility-model.h"
#include "ns3/node.h"
#include "ns3/lora-phy.h"
#include "ns3/traced-value.h"
#include <list>
#include "ns3/antenna-model.h"
#include "ns3/lora-gateway-spectrum-phy-interface.h"
#include "ns3/lora-spectrum-value-helper.h"
#include "ns3/spectrum-lora-interference-helper.h"
#include "ns3/spectrum-channel.h"
#include "ns3/spectrum-interference.h"

namespace ns3 {

  class SpectrumGatewayLoraPhy : public LoraPhy
  {
  public:

	// Similar to GatewayLoraPhy

    static TypeId GetTypeId (void);

    SpectrumGatewayLoraPhy();
    virtual ~SpectrumGatewayLoraPhy();

    Ptr<NetDevice> GetDevice (void) const;

    virtual void StartReceive (Ptr<Packet> packet, double rxPowerDbm, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);
    virtual void EndReceive (Ptr<Packet> packet, Ptr<LoraInterferenceHelper::Event> event);
    virtual void Send (Ptr<Packet> packet, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);
    void SpectrumEndReceive (Ptr<Packet> packet, Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event);

    virtual void SetReceiveOkCallback (RxOkCallback callback);
    virtual void SetTxFinishedCallback (TxFinishedCallback callback);
    
    virtual bool IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel);

    double GetTxPowerdBm ();
    void SetTxPowerdBm (double power);
    
    static const double sensitivity[6]; 
    
    void AddReceptionPath (Ptr<LogicalLoraChannel> logicalChannel);
    void ResetReceptionPaths (void);
    
    // Similar to WifiPhy
    
    void SetErrorRateModel (Ptr<LoraErrorRateModel> rate);
    Ptr<LoraErrorRateModel> GetErrorRateModel (void) const;
    
    // Similar to SpectrumWifiPhy
    
    void StartRx (Ptr<SpectrumSignalParameters> rxParams);
	
	void SetAntenna (Ptr<AntennaModel> antenna);
    Ptr<AntennaModel> GetRxAntenna (void) const;
	Ptr<const SpectrumModel> GetRxSpectrumModel (uint8_t index) const;
    
    typedef Callback<void,bool> RxCallback;
	void SetPacketReceivedCallback (RxCallback callback);
	typedef void (* SignalArrivalCallback) (bool signalType, uint32_t senderNodeId, double rxPower, Time duration);
    
    void SetChannel (Ptr<SpectrumChannel> channel);
	
  private:

	// Similar to GatewayLoraPhy

	class SpectrumReceptionPath : public SimpleRefCount<SpectrumGatewayLoraPhy::SpectrumReceptionPath>
    {

    public:

      ~SpectrumReceptionPath();
      SpectrumReceptionPath (Ptr<LogicalLoraChannel> logicalChannel);

      Ptr<LogicalLoraChannel> GetLogicalChannel (void);
      void SetLogicalChannel (Ptr<LogicalLoraChannel> logicalChannel);
      
      bool IsAvailable (void);
      void Free (void);

      void LockOnEvent (Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event);
      void SetEvent (Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event);
      Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> GetEvent (void);

    private:

      Ptr<LogicalLoraChannel> m_logicalChannel;
      bool m_available;
      Ptr< SpectrumLoraInterferenceHelper::SpectrumEvent > m_event;
    };

    double m_txPowerdBm; 
    std::list<Ptr<SpectrumReceptionPath> > m_receptionPaths;
	TracedValue<int> m_occupiedReceptionPaths;    
    
    // Similar to WifiPhy
    
    TracedCallback<Ptr<const Packet>, double, double, uint8_t> m_phyMonitorSniffRxTrace;
	TracedCallback<Ptr<const Packet>, double, double, uint8_t> m_phyMonitorSniffTxTrace;
    
    SpectrumLoraInterferenceHelper m_spectrumInterference;        
    
    Ptr<UniformRandomVariable> m_random; 
    
    // Similar to SpectrumWifiPhy
    
    Ptr<SpectrumValue> GetTxPowerSpectralDensity (double centerFrequency, double channelWidth, double txPowerW) const;

	Ptr<SpectrumChannel> m_spectrumChannel;        

	std::vector<Ptr<LoraGatewaySpectrumPhyInterface> > m_loraGwSpectrumPhyInterfaces;
	std::vector<Ptr<const SpectrumModel> > m_rxSpectrumModels;
	Ptr<AntennaModel> m_antenna;
	
	RxCallback m_rxCallback;
	TracedCallback<bool, uint32_t, double, Time> m_signalCb;
	
	// New ones
	
	TracedCallback<Ptr<Packet> > m_failedDecoding;

  };

} /* namespace ns3 */

#endif /* SPECTRUM_GATEWAY_LORA_PHY_H */
