/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LORA_PHY_H
#define LORA_PHY_H

#include "ns3/object.h"
#include "ns3/callback.h"
#include "ns3/net-device.h"
#include "ns3/nstime.h"
#include "ns3/mobility-model.h"
#include "ns3/node.h"
#include "ns3/lora-channel.h"
#include "ns3/net-device.h"
#include "ns3/lora-interference-helper.h"
#include <list>

namespace ns3 {

  class LoraChannel;

  /**
   * \ingroup lora
   *
   * \brief Base class for PHY layers implementing the lora modulation scheme.
   *
   */
  class LoraPhy : public Object
  {
  public:

    static TypeId GetTypeId (void);

    /**
     * Constructor and destructor
     */
    LoraPhy();
    virtual ~LoraPhy();

    /**
     * Type definition for a callback to call when the packet is correctly
     * received.
     */
    typedef Callback<void, Ptr<Packet> > RxOkCallback;

    /**
     * Type definition for a callback to call when a packet has finished
     * sending and the device is in sleep mode.
     * This callback is expected to be set and used by the MAC layer, to
     * determine when and where to open a receive window.
     */
    typedef Callback<void, Ptr<Packet> > TxFinishedCallback;

    /**
     * Start receiving a packet.
     * This method is called by LoraChannel.
     *
     * \param packet The packet that is arriving at this phy layer.
     * \param rxPowerDbm The power that this arriving packet has (assumed to
     * be constant for the whole reception).
     * \param sf The spreading factor of the arriving packet.
     * \param duration The on air time of this packet.
     * \param logicalChannel The logical channel number this packet is being transmitted on.
     */
    virtual void StartReceive (Ptr<Packet> packet, double rxPowerDbm, uint8_t
                               sf, Time duration, Ptr<LogicalLoraChannel>
                               logicalChannel) = 0;

    /**
     * The Phy finishes reception of a packet.
     *
     * \param packet The received packet.
     * \param event The event that is tied to this packet in the
     * LoraInterferenceHelper.
     */
    virtual void EndReceive (Ptr<Packet> packet,
                             Ptr<LoraInterferenceHelper::Event> event) = 0;

    /**
     * Ask the PHY to send a packet.
     *
     * \param packet The packet to send.
     * \param sf The spreading factor to send the packet with.
     * \param logicalChannel The channel to send the packet in.
     */
    virtual void Send (Ptr<Packet> packet, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel) = 0;

    /**
     * Set the callback to call upon successful reception of a packet.
     * This method is typically called by an upper MAC layer that wants to be
     * notified after the successful reception of a packet.
     */
    virtual void SetReceiveOkCallback (RxOkCallback callback) = 0;

    /**
     * Set the callback to call after transmission of a packet.
     * This method is typically called by an upper MAC layer that wants to be
     * notified after the transmission of a packet.
     */
    virtual void SetTxFinishedCallback (TxFinishedCallback callback) = 0;

    /**
     * Whether this device is or is not listening on the specified channel
     * number.
     * \param chNumber The channel number.
     * \returns true if the device is listening on that channel, false
     * otherwise.
     */
    virtual bool IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel) = 0;

    /**
     * Get the NetDevice associated to this PHY.
     */
    Ptr<NetDevice> GetDevice (void) const;

    /**
     * Get the mobility model associated to this PHY.
     */
    Ptr<MobilityModel> GetMobility();

    /**
     * Set the mobility model associated to this PHY.
     */
    void SetMobility(Ptr<MobilityModel> mobility);

    /**
     * Set the channel instance PHY transmits on.
     */
    void SetChannel (Ptr<LoraChannel> channel);

    /**
     * Get the channel instance associated to this PHY.
     */
    Ptr<LoraChannel> GetChannel (void) const;

    /**
     * Set the NetDevice that owns this PHY.
     */
    void SetDevice (Ptr<NetDevice> device);

  private:

    Ptr<NetDevice> m_device; //!< The net device this PHY is attached to.

    Ptr<MobilityModel> m_mobility; //!< The mobility model associated to this PHY

  protected:

    Ptr<LoraChannel> m_channel; //!< The channel this PHY is on

    /**
     * The trace source fired when a packet begins the reception process from
     * the medium.
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<const Packet> > m_phyRxBeginTrace;

    /**
     * The trace source fired when a packet cannot be received because
     * its power is below the sensitivity threshold.
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<Packet> > m_underSensitivity;

    /**
     * The trace source fired when a packet's end of reception is called.
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<const Packet> > m_phyRxEndTrace;

    /**
     * The trace source fired when a packet cannot be received because of
     * interference.
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<Packet> > m_interferedPacket;

    /**
     * The trace source fired when a packet cannot be received because all
     * available demodulators are busy.
     *
     * In the case of End Devices, this trace source is called when the PHY is
     * busy receiving a packet, while for Gateways this is called when no more
     * Receive Paths are available.
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<const Packet> > m_noMoreDemodulators;

    /**
     * The trace source fired when a packet was correctly received, with a
     * pointer to the packet.
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<Packet> > m_successfullyReceivedPacket;

    /**
     * The trace source fired when we begin sending a packet
     *
     * \see class CallBackTraceSource
     */
    TracedCallback<Ptr<Packet> > m_startSending;

    /**
     * The InterferenceHelper associated to this PHY.
     */
    LoraInterferenceHelper m_interference;

    /**
     * The callback associated to a correct reception of a packet.
     */
    RxOkCallback m_rxOkCallback;

    /**
     * The callback associated to the end of the sending of a packet.
     */
    TxFinishedCallback m_txFinishedCallback;
  };

} /* namespace ns3 */

#endif /* LORA_PHY_H */
