/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/gateway-lora-phy.h"
#include "ns3/lora-tag.h"
#include "ns3/simulator.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("GatewayLoraPhy");

  NS_OBJECT_ENSURE_REGISTERED (GatewayLoraPhy);

  /****************************************************************************
   *                     Implementation of ReceptionPath                       *
   ****************************************************************************/
  GatewayLoraPhy::ReceptionPath::ReceptionPath(Ptr<LogicalLoraChannel> logicalChannel) :
    m_logicalChannel (logicalChannel),
    m_available (1)
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  GatewayLoraPhy::ReceptionPath::~ReceptionPath()
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  Ptr<LogicalLoraChannel>
  GatewayLoraPhy::ReceptionPath::GetLogicalChannel ()
  {
    return m_logicalChannel;
  }

  bool
  GatewayLoraPhy::ReceptionPath::IsAvailable ()
  {
    return m_available;
  }

  void
  GatewayLoraPhy::ReceptionPath::Free ()
  {
    m_available = true;
    m_event = NULL;
  }

  void
  GatewayLoraPhy::ReceptionPath::LockOnEvent (Ptr< LoraInterferenceHelper::Event > event)
  {
    m_available = false;
    m_event = event;
  }

  void
  GatewayLoraPhy::ReceptionPath::SetEvent (Ptr<LoraInterferenceHelper::Event> event)
  {
    m_event = event;
  }

  Ptr<LoraInterferenceHelper::Event>
  GatewayLoraPhy::ReceptionPath::GetEvent (void)
  {
    return m_event;
  }

  void
  GatewayLoraPhy::ReceptionPath::SetLogicalChannel(Ptr<LogicalLoraChannel> logicalChannel)
  {
    m_logicalChannel = logicalChannel;
  }

  /****************************************************************************
   *                    Implementation of Gateway methods                      *
   ****************************************************************************/

  TypeId
  GatewayLoraPhy::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::GatewayLoraPhy")
      .SetParent<LoraPhy> ()
      .SetGroupName ("Lora")
      .AddConstructor<GatewayLoraPhy> ()
      .AddTraceSource ("OccupiedReceptionPaths",
                       "Number of currently occupied reception paths",
                       MakeTraceSourceAccessor
                       (&GatewayLoraPhy::m_occupiedReceptionPaths),
                       "ns3::TracedValueCallback::Int");
    return tid;
  }

  GatewayLoraPhy::GatewayLoraPhy () :
    m_txPowerdBm (27)
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  GatewayLoraPhy::~GatewayLoraPhy ()
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  // Uplink sensitivity (Source: Lebreton)
  const double GatewayLoraPhy::sensitivity[6] =
    {-127.5, -130, -132.5, -135, -137.5, -140};

  void
  GatewayLoraPhy::AddReceptionPath (Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << logicalChannel);

    m_receptionPaths.push_back (Create<GatewayLoraPhy::ReceptionPath> (logicalChannel));
  }

  void
  GatewayLoraPhy::ResetReceptionPaths (void)
  {
    NS_LOG_FUNCTION (this);

    m_receptionPaths.clear ();
  }

  double
  GatewayLoraPhy::GetTxPowerdBm (void)
  {
    return m_txPowerdBm;
  }

  void
  GatewayLoraPhy::SetTxPowerdBm (double txPowerdBm)
  {
    m_txPowerdBm = txPowerdBm;
  }

  void
  GatewayLoraPhy::Send (Ptr<Packet> packet, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << packet << unsigned(sf));

    // Send the packet over the channel
    NS_LOG_INFO ("Sending the packet in the channel");

    /*
     *  Gateway sending is assumed to have priority over reception. Even if
     *  the gateway is receiving a packet on the channel when it is asked to
     *  transmit by the upper layer, in order not to miss the receive window
     *  of the end device, the gateway will still send the packet. The send
     *  event is registered in the gateway's InterferenceHelper as a received
     *  event. While this may not destroy the incoming packet, this is almost
     *  always guaranteed to do so due to the fact that this event has a 27
     *  dBm power. This behaviour should be further clarified by reading the
     *  SX1301 datasheet.
     *
     */
    m_interference.Add (duration, m_txPowerdBm, sf, packet, logicalChannel);

    // Send the packet in the channel
    m_channel -> Send (this, packet, m_txPowerdBm, sf, duration, logicalChannel);

    // Fire the trace source
    m_startSending (packet);
  }

  void
  GatewayLoraPhy::StartReceive (Ptr<Packet> packet, double rxPowerDbm, uint8_t
                                sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << packet << rxPowerDbm << unsigned(sf) <<
                     duration << logicalChannel);

    m_phyRxBeginTrace (packet);

    // Add the event to the LoraInterferenceHelper
    Ptr<LoraInterferenceHelper::Event> event;
    event = m_interference.Add (duration, rxPowerDbm, sf, packet, logicalChannel);

    // Cycle over the receive paths to check availability to receive the packet
    std::list<Ptr<GatewayLoraPhy::ReceptionPath> > list = m_receptionPaths;
    std::list<Ptr<GatewayLoraPhy::ReceptionPath> >::iterator it;

    for (it = list.begin(); it != list.end(); ++it)
      {
        Ptr<GatewayLoraPhy::ReceptionPath> currentPath = *it;

        NS_LOG_DEBUG ("Current ReceptionPath has channel number = " <<
                      currentPath->GetLogicalChannel ());

        // If the receive path is available and listening on the channel of
        // interest, start reception on that receive path.
        if (currentPath->GetLogicalChannel () == logicalChannel &&
            currentPath->IsAvailable())
          {
            // See whether the reception power is above or below the sensitivity
            // for that spreading factor
            double sensitivity = GatewayLoraPhy::sensitivity[unsigned(sf)-7];

            if (rxPowerDbm < sensitivity) // Packet arrived below sensitivity
              {
                NS_LOG_INFO ("Dropping packet reception of packet with sf = "
                             << unsigned(sf) <<
                             " because under the sensitivity of "
                             << sensitivity << " dBm");

                m_underSensitivity (packet);

                return;
              }
            else  // We have sufficient sensitivity to start receiving
              {
                NS_LOG_INFO ("Scheduling reception of a packet, " <<
                "occupying one demodulator");

                // Block this resource
                currentPath->LockOnEvent (event);
                m_occupiedReceptionPaths++;

                // Schedule the end of the reception of the packet
                Simulator::Schedule (duration, &LoraPhy::EndReceive, this,
                                     packet, event);
                return;
              }
          }
      }
    // If we get to this point, there are no demodulators we can use
    NS_LOG_INFO ("Dropping packet reception of packet with sf = "
                 << unsigned(sf) <<
                 " because no suitable demodulator was found");

    // Fire the trace source
    m_noMoreDemodulators(packet);
  }

  void
  GatewayLoraPhy::EndReceive (Ptr<Packet> packet,
                              Ptr<LoraInterferenceHelper::Event> event)
  {
    NS_LOG_FUNCTION (this << packet << event);

    // Call the trace source
    m_phyRxEndTrace (packet);

    // Call the LoraInterferenceHelper to determine whether there was
    // destructive interference. If the packet is correctly received, this
    // method returns a 0.
    uint8_t packetDestroyed = 0;
    packetDestroyed = m_interference.IsDestroyedByInterference(event);
    NS_LOG_DEBUG ("packetDestroyed by " << unsigned(packetDestroyed));

    // Fire the trace source if packet was destroyed
    if (packetDestroyed != uint8_t(0))
      {
        LoraTag tag;
        packet->RemovePacketTag (tag);
        tag.SetDestroyedBy (packetDestroyed);
        NS_LOG_DEBUG ("Tag value: " << unsigned(tag.GetDestroyedBy()));
        packet->AddPacketTag (tag);
        m_interferedPacket (packet);
      }
    else
      {
        NS_LOG_INFO ("Packet with SF " <<
                     unsigned(event->GetSpreadingFactor()) <<
                     " received correctly");

        m_successfullyReceivedPacket (packet);

        // Forward the packet to the upper layer
        if (!m_rxOkCallback.IsNull ())
          {
            m_rxOkCallback (packet);
          }

      }

    // Search for the demodulator that was locked on this event.
    // Alternatively, we could move this information to a parameter of the
    // function.
    std::list< Ptr< GatewayLoraPhy::ReceptionPath > > list = m_receptionPaths;
    std::list< Ptr< GatewayLoraPhy::ReceptionPath > >::iterator it;

    for (it = list.begin(); it != list.end(); ++it)
      {
        Ptr<GatewayLoraPhy::ReceptionPath> currentPath = *it;

        if (currentPath->GetEvent () == event)
          {
            currentPath->Free();
            m_occupiedReceptionPaths--;
            return;
          }
      }
  }

  void
  GatewayLoraPhy::SetReceiveOkCallback (RxOkCallback callback)
  {
    m_rxOkCallback = callback;
  }

  void
  GatewayLoraPhy::SetTxFinishedCallback (TxFinishedCallback callback)
  {
    m_txFinishedCallback = callback;
  }

  bool
  GatewayLoraPhy::IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << logicalChannel);

    std::list< Ptr< GatewayLoraPhy::ReceptionPath > > list = m_receptionPaths;
    std::list< Ptr< GatewayLoraPhy::ReceptionPath > >::iterator it;

    for (it = list.begin(); it != list.end(); ++it)
      {
        Ptr<GatewayLoraPhy::ReceptionPath> currentPath = *it;

        NS_LOG_DEBUG ("Current reception path is on channel " << currentPath->GetLogicalChannel ());

        if (currentPath->GetLogicalChannel() == logicalChannel)
          {
            return true;
          }
      }
    return false;
  }
}
