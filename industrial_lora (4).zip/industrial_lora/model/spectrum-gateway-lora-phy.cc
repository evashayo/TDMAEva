/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#include <algorithm>
#include <cmath>
#include "ns3/simulator.h"
#include "ns3/logical-lora-channel.h"
#include "ns3/lora-tag.h"
#include "ns3/log.h"
#include "ns3/spectrum-gateway-lora-phy.h"
#include "ns3/spectrum-channel.h"
#include "ns3/spectrum-value.h"
#include "ns3/assert.h"
#include "ns3/double.h"
#include "ns3/boolean.h"
#include "ns3/lora-spectrum-signal-parameters.h"
#include "ns3/antenna-model.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("SpectrumGatewayLoraPhy");

  NS_OBJECT_ENSURE_REGISTERED (SpectrumGatewayLoraPhy);
  
  /****************************************************************************
   *            Implementation of SpectrumReceptionPath                       *
   ****************************************************************************/
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::SpectrumReceptionPath(Ptr<LogicalLoraChannel> logicalChannel) :
    m_logicalChannel (logicalChannel),
    m_available (1)
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  SpectrumGatewayLoraPhy::SpectrumReceptionPath::~SpectrumReceptionPath()
  {
    NS_LOG_FUNCTION_NOARGS ();
  }

  Ptr<LogicalLoraChannel>
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::GetLogicalChannel ()
  {
    return m_logicalChannel;
  }

  bool
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::IsAvailable ()
  {
    return m_available;
  }

  void
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::Free ()
  {
    m_available = true;
    m_event = NULL;
  }

  void
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::LockOnEvent (Ptr< SpectrumLoraInterferenceHelper::SpectrumEvent > event)
  {
    m_available = false;
    m_event = event;
  }

  void
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::SetEvent (Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event)
  {
    m_event = event;
  }

  Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent>
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::GetEvent (void)
  {
    return m_event;
  }

  void
  SpectrumGatewayLoraPhy::SpectrumReceptionPath::SetLogicalChannel(Ptr<LogicalLoraChannel> logicalChannel)
  {
    m_logicalChannel = logicalChannel;
  }

  /****************************************************************************
   *           Implementation of SpectrumGateway methods                      *
   ****************************************************************************/

  TypeId
  SpectrumGatewayLoraPhy::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::SpectrumGatewayLoraPhy")
      .SetParent<LoraPhy> ()
      .SetGroupName ("Lora")
      .AddConstructor<SpectrumGatewayLoraPhy> ()
      .AddTraceSource ("SignalArrival",
                     "Signal arrival",
                     MakeTraceSourceAccessor (&SpectrumGatewayLoraPhy::m_signalCb),
                     "ns3::SpectrumGatewayLoraPhy::SignalArrivalCallback")
      .AddTraceSource ("LostPacketBecauseFailedDecoding",
                       "Trace source indicating a packet "
                       "could not be correctly received because"
                       "the SNR is too low for successful decoding",
                       MakeTraceSourceAccessor (&SpectrumGatewayLoraPhy::m_failedDecoding),
                       "ns3::Packet::TracedCallback")
      .AddTraceSource ("OccupiedReceptionPaths",
                       "Number of currently occupied reception paths",
                       MakeTraceSourceAccessor
                       (&SpectrumGatewayLoraPhy::m_occupiedReceptionPaths),
                       "ns3::TracedValueCallback::Int");
    ;
    return tid;
  }

  SpectrumGatewayLoraPhy::SpectrumGatewayLoraPhy () :
    m_txPowerdBm (27) 
  {
    m_random = CreateObject<UniformRandomVariable> ();
    m_spectrumInterference.SetNoiseFigure(6);
  }

  SpectrumGatewayLoraPhy::~SpectrumGatewayLoraPhy ()
  {
  }

  // Uplink sensitivity (Source: Lebreton)
  const double SpectrumGatewayLoraPhy::sensitivity[6] =
    {-127.5, -130, -132.5, -135, -137.5, -140};

  double
  SpectrumGatewayLoraPhy::GetTxPowerdBm ()
  {
    return m_txPowerdBm;
  }

  void
  SpectrumGatewayLoraPhy::SetTxPowerdBm (double power)
  {
    m_txPowerdBm = power;
  }
  
  void
  SpectrumGatewayLoraPhy::AddReceptionPath (Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << logicalChannel);
	
	//Look for logical channel among current reception paths
	bool found = IsOnChannel(logicalChannel);
	
	// If not already present, add LoraGatewaySpectrumPhyInterface and RxSpectrumModel to the lists and to the channel
	if (!found)
	  {
	    uint8_t lgspi_index = m_loraGwSpectrumPhyInterfaces.size();
	    NS_ASSERT(lgspi_index == m_rxSpectrumModels.size());
	    Ptr<LoraGatewaySpectrumPhyInterface> interface = CreateObject<LoraGatewaySpectrumPhyInterface> ();
		interface->SetSpectrumLoraPhy (this);
		interface->SetDevice (LoraPhy::GetDevice());	
		interface->SetIndex (lgspi_index);					
		m_loraGwSpectrumPhyInterfaces.push_back (interface);
		m_rxSpectrumModels.push_back (LoraSpectrumValueHelper::GetSpectrumModel (logicalChannel->GetFrequency(), logicalChannel->GetBandwidth()));
		NS_ASSERT(m_spectrumChannel);
		m_spectrumChannel->AddRx (interface);		  
	  }
	
	m_receptionPaths.push_back (Create<SpectrumGatewayLoraPhy::SpectrumReceptionPath> (logicalChannel));
    
  }

  void
  SpectrumGatewayLoraPhy::ResetReceptionPaths (void)
  {
    NS_LOG_FUNCTION (this);

    m_receptionPaths.clear ();
  }

  void
  SpectrumGatewayLoraPhy::Send (Ptr<Packet> packet, uint8_t sf, Time duration,
                          Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << packet << unsigned(sf) << duration << logicalChannel);

    /*
     *  Gateway sending is assumed to have priority over reception. Even if
     *  the gateway is receiving a packet on the channel when it is asked to
     *  transmit by the upper layer, in order not to miss the receive window
     *  of the end device, the gateway will still send the packet. The send
     *  event is registered in the gateway's InterferenceHelper as a received
     *  event. While this may not destroy the incoming packet, this is almost
     *  always guaranteed to do so due to the fact that this event has a 27
     *  dBm power. This behaviour should be further clarified by reading the
     *  SX1301 datasheet.
     *
     */
    m_spectrumInterference.Add (duration, m_txPowerdBm, sf, packet, logicalChannel);

    // Tag the packet with information about its Spreading Factor
    LoraTag tag (sf);
    packet->AddPacketTag (tag);
    
    // Obtain non-const Packet
    Ptr<Packet> newPacket = packet->Copy ();    

    // Add spectrum elements and send the packet over the channel
    NS_LOG_INFO ("Sending the packet in the channel");
    NS_LOG_DEBUG ("Transmission signal power before antenna gain: " << GetTxPowerdBm() << " dBm");
    double bandwidthMHz = logicalChannel->GetBandwidth();
    double frequencyMHz = logicalChannel->GetFrequency();
	double txPowerWatts = (std::pow (10.0, GetTxPowerdBm() / 10.0)) / 1000.0;
    Ptr<SpectrumValue> txPowerSpectrum = GetTxPowerSpectralDensity (frequencyMHz, bandwidthMHz, txPowerWatts);	
	Ptr<LoraSpectrumSignalParameters> txParams = Create<LoraSpectrumSignalParameters> ();
	txParams->duration = duration;
	txParams->psd = txPowerSpectrum;
	txParams->logicalChannel = logicalChannel;
	NS_ASSERT_MSG (!m_loraGwSpectrumPhyInterfaces.empty(), "No SpectrumPhy interfaces on this gateway");
	txParams->txPhy = m_loraGwSpectrumPhyInterfaces.at(0)->GetObject<SpectrumPhy> ();
	txParams->txAntenna = m_antenna;
	txParams->packet = newPacket;
	NS_LOG_DEBUG ("Starting transmission with integrated spectrum power " << (10.0 * std::log10 ((Integral (*txPowerSpectrum)) * 1000.0)) << " dBm; spectrum model Uid: " << txPowerSpectrum->GetSpectrumModel ()->GetUid ());
	m_spectrumChannel->StartTx (txParams);

    // Schedule the callback, if it was set by an upper layer
    if (!m_txFinishedCallback.IsNull ())
      {
        Simulator::Schedule (duration, &SpectrumGatewayLoraPhy::m_txFinishedCallback,
                             this, packet);
      }

	// Callbacks
	m_phyMonitorSniffTxTrace (packet, frequencyMHz, bandwidthMHz, sf);	
    m_startSending (packet);
  }

  void
  SpectrumGatewayLoraPhy::StartReceive (Ptr<Packet> packet, double rxPowerDbm, uint8_t
                                  sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel)
  {
	NS_LOG_FUNCTION (this << packet << rxPowerDbm << unsigned(sf) << logicalChannel);
	
	m_phyRxBeginTrace (packet);

    // Add the event to the SpectrumLoraInterferenceHelper
    Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event;
    event = m_spectrumInterference.Add (duration, rxPowerDbm, sf, packet, logicalChannel);
    
    // Cycle over the receive paths to check availability to receive the packet
    std::list<Ptr<SpectrumGatewayLoraPhy::SpectrumReceptionPath> > list = m_receptionPaths;
    std::list<Ptr<SpectrumGatewayLoraPhy::SpectrumReceptionPath> >::iterator it;
    
    for (it = list.begin(); it != list.end(); ++it)
      {
        Ptr<SpectrumGatewayLoraPhy::SpectrumReceptionPath> currentPath = *it;

        NS_LOG_DEBUG ("Current SpectrumReceptionPath has channel number = " <<
                      currentPath->GetLogicalChannel ());
        
        // If the receive path is available and listening on the channel of
        // interest, start reception on that receive path.
        if (currentPath->GetLogicalChannel () == logicalChannel &&
            currentPath->IsAvailable())
          {
            // See whether the reception power is above or below the sensitivity
            // for that spreading factor
            double sensitivity = SpectrumGatewayLoraPhy::sensitivity[unsigned(sf)-7];            
                      
			if (rxPowerDbm < sensitivity)
			  {
				NS_LOG_INFO ("Dropping packet reception of packet with sf = " <<
							 unsigned(sf) << " because under the sensitivity of " <<
							 sensitivity << " dBm");

				// Fire the trace source for this event.
				m_underSensitivity(packet);
				
				return;
			  }
			else
			  {
				NS_LOG_INFO ("Scheduling reception of a packet, " <<
                "occupying one demodulator");
				
				// Block this resource
                currentPath->LockOnEvent (event);
                m_occupiedReceptionPaths++;
                
				// Schedule the end of the reception of the packet
				Simulator::Schedule (duration, &SpectrumGatewayLoraPhy::SpectrumEndReceive, this, packet,
									 event);
				  
				return;
			  }
		  }
      }
    // If we get to this point, there are no demodulators we can use
    NS_LOG_INFO ("Dropping packet reception of packet with sf = "
                 << unsigned(sf) <<
                 " because no suitable demodulator was found");

    // Fire the trace source
    m_noMoreDemodulators(packet);
  }
  
  void
  SpectrumGatewayLoraPhy::EndReceive (Ptr<Packet> packet,
                                Ptr<LoraInterferenceHelper::Event> event)
  {
  }

  void
  SpectrumGatewayLoraPhy::SpectrumEndReceive (Ptr<Packet> packet,
                                Ptr<SpectrumLoraInterferenceHelper::SpectrumEvent> event)
  {
	NS_LOG_FUNCTION (this << packet << event);
	NS_ASSERT (event->GetEndTime () == Simulator::Now ());
	
	// Call the trace source
    m_phyRxEndTrace (packet);

    // Check error probability
    double per = m_spectrumInterference.CalculatePer (event);
	NS_LOG_DEBUG ("PER = " << per);
	//std::cout << "PHY: Gateway has received packet with power " << event->GetRxPowerdBm()  << " corresponding to PER of " << per << " at time " << Simulator::Now().GetMilliSeconds() << " ms\n";

	if (m_random->GetValue () > per) // decoding succeeded
	  {
		
		NS_LOG_INFO ("Packet with SF " <<
                     unsigned(event->GetSpreadingFactor()) <<
                     " received correctly");
                     
        m_successfullyReceivedPacket (packet);
		
		// If there is one, perform the callback to inform the upper layer
        if (!m_rxOkCallback.IsNull ())
          {
            m_rxOkCallback (packet);
          }
          
		 Ptr<LogicalLoraChannel> channel = event->GetLogicalChannel();
		 m_phyMonitorSniffRxTrace (packet, channel->GetFrequency(), channel->GetBandwidth(), event->GetSpreadingFactor());	
	  
	  }
	else // decoding failed
	  {	
		// Fire the trace source for this event.
		m_failedDecoding(packet);
      }
      
    // Search for the demodulator that was locked on this event.
    // Alternatively, we could move this information to a parameter of the
    // function.
    std::list< Ptr< SpectrumGatewayLoraPhy::SpectrumReceptionPath > > list = m_receptionPaths;
    std::list< Ptr< SpectrumGatewayLoraPhy::SpectrumReceptionPath > >::iterator it;

    for (it = list.begin(); it != list.end(); ++it)
      {
        Ptr<SpectrumGatewayLoraPhy::SpectrumReceptionPath> currentPath = *it;

        if (currentPath->GetEvent () == event)
          {
            currentPath->Free();
            m_occupiedReceptionPaths--;
            return;
          }
      }

  }

  void
  SpectrumGatewayLoraPhy::SetReceiveOkCallback (RxOkCallback callback)
  {
    m_rxOkCallback = callback;
  }

  void
  SpectrumGatewayLoraPhy::SetTxFinishedCallback (TxFinishedCallback callback)
  {
    m_txFinishedCallback = callback;
  }

  bool
  SpectrumGatewayLoraPhy::IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel)
  {
    NS_LOG_FUNCTION (this << logicalChannel);

    std::list< Ptr< SpectrumGatewayLoraPhy::SpectrumReceptionPath > > list = m_receptionPaths;
    std::list< Ptr< SpectrumGatewayLoraPhy::SpectrumReceptionPath > >::iterator it;

    for (it = list.begin(); it != list.end(); ++it)
      {
        Ptr<SpectrumGatewayLoraPhy::SpectrumReceptionPath> currentPath = *it;

        NS_LOG_DEBUG ("Current reception path is on channel " << currentPath->GetLogicalChannel ());

        if (currentPath->GetLogicalChannel() == logicalChannel)
          {
            return true;
          }
      }
    return false;
  }
  
  Ptr<const SpectrumModel>
  SpectrumGatewayLoraPhy::GetRxSpectrumModel (uint8_t index) const
  {
    NS_LOG_FUNCTION (this);
    NS_ASSERT(m_rxSpectrumModels.size() > index);
    return m_rxSpectrumModels.at(index);;
  }
  
  void
  SpectrumGatewayLoraPhy::SetChannel (Ptr<SpectrumChannel> channel)
  {
    m_spectrumChannel = channel;
  }
  
  void
  SpectrumGatewayLoraPhy::SetPacketReceivedCallback (RxCallback callback)
  {
    m_rxCallback = callback;
  }

  void
  SpectrumGatewayLoraPhy::StartRx (Ptr<SpectrumSignalParameters> rxParams)
  {
	NS_LOG_FUNCTION (this << rxParams);
	
	// Recover duration, PSD and node ID
	Time rxDuration = rxParams->duration;
	Ptr<SpectrumValue> receivedSignalPsd = rxParams->psd;
	NS_LOG_DEBUG ("Received signal with PSD " << *receivedSignalPsd << " and duration " << rxDuration.As (Time::NS));
	uint32_t senderNodeId = 0;
	if (rxParams->txPhy)
      {
        senderNodeId = rxParams->txPhy->GetDevice ()->GetNode ()->GetId ();
      }
	NS_LOG_DEBUG ("Received signal from " << senderNodeId << " with unfiltered power " << (10.0 * std::log10 ((Integral (*receivedSignalPsd)) * 1000.0)) << " dBm");
	
	// Integrate over our receive bandwidth (i.e., all that the receive
	// spectral mask representing our filtering allows) to find the
	// total energy apparent to the "demodulator".
	double rxPowerW = Integral (*receivedSignalPsd);
	double rxPowerDbm = 10.0 * std::log10 (rxPowerW * 1000.0);
	NS_LOG_DEBUG ("Signal power received: " << rxPowerW << " W (" << rxPowerDbm << " dBm)");
	//std::cout << "PHY: Gateway has received signal from " << senderNodeId << " with power " << rxPowerDbm  << " dBm at time " << Simulator::Now().GetMilliSeconds() << " ms\n";

	// Log the signal arrival to the trace source
	Ptr<LoraSpectrumSignalParameters> loraRxParams = DynamicCast<LoraSpectrumSignalParameters> (rxParams);
	m_signalCb (loraRxParams ? true : false, senderNodeId, rxPowerDbm, rxDuration);
	if (loraRxParams == 0)
      {
        NS_LOG_INFO ("Received non LoRa signal");
        m_spectrumInterference.AddForeignSignal (rxDuration, rxPowerW);
        return;
      }
    NS_LOG_INFO ("Received LoRa signal");
    Ptr<LogicalLoraChannel> logicalChannel = loraRxParams->logicalChannel;
	Ptr<Packet> packet = loraRxParams->packet->Copy ();
	LoraTag tag;
	bool found = packet->PeekPacketTag (tag);
	if (!found)
	  {
		NS_FATAL_ERROR ("Received LoRa Spectrum Signal with no LoraTag");
		return;
	  }
	uint8_t sf = tag.GetSpreadingFactor();
  
	// Schedule StartReceive (if we have received something)
	if (rxPowerW != 0)
		Simulator::ScheduleNow (&SpectrumGatewayLoraPhy::StartReceive, this,
                                                      packet, rxPowerDbm, sf, rxDuration, logicalChannel);
                                                      
    return;
  }
  
  Ptr<AntennaModel>
  SpectrumGatewayLoraPhy::GetRxAntenna (void) const
  {
    return m_antenna;
  }

  void
  SpectrumGatewayLoraPhy::SetAntenna (Ptr<AntennaModel> a)
  {
    NS_LOG_FUNCTION (this << a);
    m_antenna = a;
  }
  
  Ptr<SpectrumValue>
  SpectrumGatewayLoraPhy::GetTxPowerSpectralDensity (double centerFrequency, double channelWidth, double txPowerW) const
  {
    NS_LOG_FUNCTION (centerFrequency << channelWidth << txPowerW);
    Ptr<SpectrumValue> v = LoraSpectrumValueHelper::CreateLoraTxPowerSpectralDensity (centerFrequency, channelWidth, txPowerW);	
    return v;
  }
  
  void
  SpectrumGatewayLoraPhy::SetErrorRateModel (Ptr<LoraErrorRateModel> rate)
  {
    m_spectrumInterference.SetErrorRateModel (rate);
  }

  Ptr<LoraErrorRateModel>
  SpectrumGatewayLoraPhy::GetErrorRateModel (void) const
  {
    return m_spectrumInterference.GetErrorRateModel ();
  }

}
