/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/sub-band.h"
#include "ns3/log.h"

namespace ns3 {

  // SubBand implementation
  NS_LOG_COMPONENT_DEFINE ("SubBand");

  NS_OBJECT_ENSURE_REGISTERED (SubBand);

  TypeId
  SubBand::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::SubBand")
      .SetParent<Object> ()
      .SetGroupName ("Lora");
    return tid;
  }

  SubBand::SubBand ()
  {
    NS_LOG_FUNCTION (this);
  }

  SubBand::SubBand (double firstFrequency, double lastFrequency, double dutyCycle) :
    m_firstFrequency (firstFrequency),
    m_lastFrequency (lastFrequency),
    m_dutyCycle (dutyCycle)
  {
    NS_LOG_FUNCTION (this << firstFrequency << lastFrequency << dutyCycle);
  }

  SubBand::~SubBand ()
  {
    NS_LOG_FUNCTION (this);
  }

  double
  SubBand::GetFirstFrequency (void)
  {
    return m_firstFrequency;
  }

  double
  SubBand::GetDutyCycle (void)
  {
    return m_dutyCycle;
  }

  bool
  SubBand::BelongsToSubBand (double frequency, double bandwidth)
  {
    return ((frequency-bandwidth/2) > m_firstFrequency &&
            (frequency+bandwidth/2) < m_lastFrequency);
  }

  void
  SubBand::SetNextTransmissionTime (Time nextTime)
  {
    m_nextTransmissionTime = nextTime;
  }

  Time
  SubBand::GetNextTransmissionTime (void)
  {
    return m_nextTransmissionTime;
  }

}
