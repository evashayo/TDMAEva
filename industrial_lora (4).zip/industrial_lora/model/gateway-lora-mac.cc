/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/gateway-lora-mac.h"
#include "ns3/lora-mac-header.h"
#include "ns3/lora-frame-header.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("GatewayLoraMac");

  NS_OBJECT_ENSURE_REGISTERED (GatewayLoraMac);

  TypeId
  GatewayLoraMac::GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::GatewayLoraMac")
      .SetParent<LoraMac> ()
      .AddConstructor<GatewayLoraMac> ()
      .SetGroupName ("Lora");
    return tid;
  }

  GatewayLoraMac::GatewayLoraMac () {
    NS_LOG_FUNCTION (this);
    m_channelHelper.AddSubBand (868, 868.6, 0.01);
    m_channelHelper.AddChannel (868.10, 0.125);
    m_channelHelper.AddChannel (868.30, 0.125);
    m_channelHelper.AddChannel (868.50, 0.125);
    m_channelHelper.AddChannel (869.525, 0.125);
    // m_channelHelper.AddChannel (868.85, 0.125);
    // m_channelHelper.AddChannel (869.05, 0.125);
  }

  GatewayLoraMac::~GatewayLoraMac () {
    NS_LOG_FUNCTION (this);
  }

  void
  GatewayLoraMac::Send(Ptr<Packet> packet)
  {
    NS_LOG_FUNCTION (this << packet);

    Ptr<LogicalLoraChannel> logicalChannel = *(m_channelHelper.GetChannelList
                                               ().begin());

    LoraFrameHeader frameHdr;
    frameHdr.SetFPort (uint8_t(1));
    packet->AddHeader(frameHdr);

    // Add the Lora Mac header to the packet
    LoraMacHeader macHdr;
    macHdr.SetMType (LoraMacHeader::CONFIRMED_DATA_DOWN);
    packet->AddHeader(macHdr);

    // Get the duration
    Time duration = m_channelHelper.GetOnAirTime (packet,
                                                  12,
                                                  0, 1,
                                                  logicalChannel->GetBandwidth (), 8);

    // TODO: Determine SF for the response
    m_phy -> Send (packet, 12, duration, logicalChannel);
  }

  void
  GatewayLoraMac::Receive(Ptr<Packet> packet)
  {
    NS_LOG_FUNCTION (this << packet);

    NS_LOG_INFO ("MAC layer receive function called!");

    // Schedule downlink
    
  }

  void
  GatewayLoraMac::TxFinished (Ptr<Packet> packet)
  {
    NS_LOG_FUNCTION_NOARGS ();
  }
}
