/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef SUB_BAND_H
#define SUB_BAND_H

#include "ns3/object.h"
#include "ns3/logical-lora-channel.h"
#include "ns3/nstime.h"

namespace ns3 {

  class LogicalLoraChannel;

  class SubBand : public Object
  {
  public:

    static TypeId GetTypeId (void);

    SubBand ();

    /**
     * Create a new subband, also specifying its duty cycle
     */
    SubBand (double firstFrequency, double lastFrequency, double dutyCycle);

    virtual ~SubBand ();

    /**
     * Get the first frequency of the subband
     */
    double GetFirstFrequency (void);

    /**
     * Get the last frequency of the subband
     */
    double GetLastFrequency (void);

    /**
     * Get the duty cycle of the subband
     */
    double GetDutyCycle (void);

    /**
     * Update the next transmission time
     * This function is used by LogicalLoraChannelHelper, which computes the
     * time based on the subband's duty cycle.
     */
    void SetNextTransmissionTime (Time nextTime);

    /**
     * Return whether or not a frequency belongs to this subband
     * \param frequency the frequency we want to test against the current subband
     */
    bool BelongsToSubBand (double frequency, double bandwidth);

    /**
     * Return whether or not a channel belongs to this subband
     * \param channel the channel we want to test against the current subband
     */
    bool BelongsToSubBand (Ptr<LogicalLoraChannel> channel);

    /**
     * Returns the next time from which transmission on this subband will be possible
     */
    Time GetNextTransmissionTime (void);

  private:

    double m_firstFrequency; //<! Starting frequency of the subband, in MHz
    double m_lastFrequency; //<! Ending frequency of the subband, in MHz
    double m_dutyCycle; //<! The duty cycle that needs to be enforced on this subband
    Time m_nextTransmissionTime; //!< The next time a transmission will be allowed in this subband

  };
} /* namespace ns3 */
#endif /* SUB_BAND_H */
