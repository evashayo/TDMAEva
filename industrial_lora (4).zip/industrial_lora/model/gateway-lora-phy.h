/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef GATEWAY_LORA_PHY_H
#define GATEWAY_LORA_PHY_H

#include "ns3/object.h"
#include "ns3/net-device.h"
#include "ns3/nstime.h"
#include "ns3/mobility-model.h"
#include "ns3/node.h"
#include "ns3/lora-phy.h"
#include "ns3/traced-value.h"
#include <list>

namespace ns3 {

  class LoraChannel;

  /**
   * /brief Class describing a Lora SX1301 chip.
   *
   * This class models the behaviour of the chip employed in Lora gateways.
   * These chips are characterized by the presence of 8 receive paths, or
   * parallel receivers, which can be employed to listen to different channels
   * simultaneously. This characteristic of the chip is modeled using the
   * ReceivePath class, which describes a single parallel receiver. A
   * GatewayLoraPhy holds a collection of these objects, and decides how to
   * allocate them.
   *
   */
  class GatewayLoraPhy : public LoraPhy
  {
  public:

    static TypeId GetTypeId (void);

    GatewayLoraPhy();
    virtual ~GatewayLoraPhy();

    Ptr<NetDevice> GetDevice (void) const;

    virtual void StartReceive (Ptr<Packet> packet, double rxPowerDbm,
                               uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);

    virtual void EndReceive (Ptr<Packet> packet,
                             Ptr<LoraInterferenceHelper::Event> event);

    virtual void SetReceiveOkCallback (RxOkCallback callback);

    virtual void SetTxFinishedCallback (TxFinishedCallback callback);

    Ptr< MobilityModel > GetMobility();

    void Send (Ptr<Packet> packet, uint8_t sf, Time duration, Ptr<LogicalLoraChannel> logicalChannel);

    double GetTxPowerdBm ();

    void SetTxPowerdBm (double txPowerdBm);

    virtual bool IsOnChannel (Ptr<LogicalLoraChannel> logicalChannel);

    /**
     * Add a reception path, locked on a specific channel number.
     */
    void AddReceptionPath (Ptr<LogicalLoraChannel> logicalChannel);

    /**
     * Reset the list of reception paths.
     */
    void ResetReceptionPaths (void);

    /**
     * A vector containing the sensitivities required to correctly decode
     * different spreading factors.
     */
    static const double sensitivity[6];

  private:

    /**
     * This class represents a configurable reception path. A ReceptionPath
     * can be either locked on an event or free. In the case it's free, it is
     * configured to listen on a specific channel.
     */
    class ReceptionPath : public SimpleRefCount<GatewayLoraPhy::ReceptionPath>
    {

    public:

      ~ReceptionPath();

      /**
       * Constructor
       * \param channel the channel this path is set to listen on.
       */
      ReceptionPath (Ptr<LogicalLoraChannel> logicalChannel);

      /**
       * Getter for the channel.
       */
      Ptr<LogicalLoraChannel> GetLogicalChannel (void);

      /**
       * Setter for the logical channel.
       */
      void SetLogicalChannel (Ptr<LogicalLoraChannel> logicalChannel);

      /**
       * Query whether this reception path is available to lock on a
       * signal.
       */
      bool IsAvailable (void);

      /**
       * Set this reception path as available.
       */
      void Free (void);

      /**
       * Set this reception path as not available and lock it on the
       * provided event.
       */
      void LockOnEvent (Ptr<LoraInterferenceHelper::Event> event);

      /**
       * Set the event this reception path is currently on.
       */
      void SetEvent (Ptr<LoraInterferenceHelper::Event> event);

      /**
       * Get the event this reception path is currently on.
       * \returns null if no event is currently being received, a pointer to
       * the event otherwise
       */
      Ptr<LoraInterferenceHelper::Event> GetEvent (void);

    private:

      /**
       * The channel number this path is currently listening on.
       */
      Ptr<LogicalLoraChannel> m_logicalChannel;

      /**
       * Whether this reception path is available to lock on a signal or
       * not.
       */
      bool m_available;

      /**
       * The event this reception path is currently locked on.
       */
      Ptr< LoraInterferenceHelper::Event > m_event;
    };

    /**
     * Transmit power (dBm) this gateway uses.
     */
    double m_txPowerdBm;

    /**
     * A list containing the states of the various parallel receivers we can
     * use.
     */
    std::list<Ptr<ReceptionPath> > m_receptionPaths;

    /**
     * The number of occupied reception paths.
     */
    TracedValue<int> m_occupiedReceptionPaths;
  };

} /* namespace ns3 */

#endif /* GATEWAY_LORA_PHY_H */
