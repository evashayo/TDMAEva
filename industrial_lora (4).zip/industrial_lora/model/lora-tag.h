/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Davide Magrin <magrinda@dei.unipd.it>, Romagnolo Stefano <romagnolostefano93@gmail.com>
 */

#ifndef LORA_TAG_H
#define LORA_TAG_H

#include "ns3/tag.h"

namespace ns3 {

  /**
   * Tag used to save various data about a packet, like its Spreading Factor and
   * data about interference.
   */
  class LoraTag : public Tag
  {
  public:
    static TypeId GetTypeId (void);
    virtual TypeId GetInstanceTypeId (void) const;

    /**
     * Create an empty LoraTag
     */
    LoraTag ();

    /**
     * Create a LoraTag with a given spreading factor
     */
    LoraTag (uint8_t sf);

    /**
     * Create a LoraTag with a given spreading factor and ID (which identifies which ED has sent the packet)
     */
    LoraTag (uint8_t sf, uint32_t id);

    /**
     * Create a LoraTag with a given spreading factor and collision
     */
    LoraTag (uint8_t sf, uint8_t destroyedBy);
    
    /**
     * Create an ID (which identifies which ED has sent the packet) and collision
     */
    LoraTag (uint32_t id, uint8_t destroyedBy);
    
    /**
     * Create a LoraTag with a given spreading factor, collision and ID (which identifies which ED has sent the packet)
     */
    LoraTag (uint8_t sf, uint8_t destroyedBy, uint32_t id);

    virtual ~LoraTag ();

    virtual void Serialize (TagBuffer i) const;
    virtual void Deserialize (TagBuffer i);
    virtual uint32_t GetSerializedSize () const;
    virtual void Print (std::ostream &os) const;

    /**
     * Read which Spreading Factor this packet was transmitted with
     */
    uint8_t GetSpreadingFactor () const;
    /**
     * Read which Spreading Factor this packet was destroyed by
     */
    uint8_t GetDestroyedBy () const;
    /**
     * Set which Spreading Factor this packet was transmitted with
     */
    void SetSpreadingFactor (uint8_t sf);
    /**
     * Set which Spreading Factor this packet was destroyed by
     */
    void SetDestroyedBy (uint8_t sf);
    /**
     * Set which is the ID of the ED that has sent this packet 
     */
    void SetSenderId(uint32_t id);
    /**
     * Read which is the ID of the ED that has sent the packet
     */
    uint32_t GetSenderId () const;

  private:
    uint8_t m_sf;
    uint8_t m_destroyedBy;
    uint32_t m_id;
  };
} // namespace ns3
#endif

