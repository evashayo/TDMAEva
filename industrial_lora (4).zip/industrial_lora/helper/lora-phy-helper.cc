/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/lora-phy-helper.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LoraPhyHelper");

  LoraPhyHelper::LoraPhyHelper ()
  {
  }

  void
  LoraPhyHelper::SetChannel (Ptr<LoraChannel> channel)
  {
    m_channel = channel;
  }

  void
  LoraPhyHelper::SetDeviceType (enum DeviceType dt)
  {

    NS_LOG_FUNCTION (this << dt);
    switch (dt)
      {
      case GW:
        m_phy.SetTypeId ("ns3::GatewayLoraPhy");
        break;
      case ED:
        m_phy.SetTypeId ("ns3::EndDeviceLoraPhy");
        break;
      }
  }

  void
  LoraPhyHelper::Set (std::string name, const AttributeValue &v)
  {
    m_phy.Set (name, v);
  }

  Ptr<LoraPhy>
  LoraPhyHelper::Create (Ptr<Node> node, Ptr<NetDevice> device) const
  {
    NS_LOG_FUNCTION (this << node << device);
    Ptr<LoraPhy> phy = m_phy.Create<LoraPhy> ();
    phy->SetChannel (m_channel);

    std::string typeId = m_phy.GetTypeId ().GetName ();

    if (typeId == "ns3::GatewayLoraPhy")
      {
        phy->GetObject<GatewayLoraPhy> ()->SetTxPowerdBm (27);
        m_channel->Add (phy); // Don't add devices to channel, only gateways
      }
    else if (typeId == "ns3::EndDeviceLoraPhy")
      {
        phy->GetObject<EndDeviceLoraPhy> ()->SetTxPowerdBm (14);
        m_channel->Add (phy); // Comment to speed up uplink-only simulations
      }
    phy->SetDevice (device);
    return phy;
  }
}
