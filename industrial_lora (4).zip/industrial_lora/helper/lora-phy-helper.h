/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LORA_PHY_HELPER_H
#define LORA_PHY_HELPER_H

#include "ns3/object-factory.h"
#include "ns3/net-device.h"
#include "ns3/lora-channel.h"
#include "ns3/lora-phy.h"
#include "ns3/end-device-lora-phy.h"
#include "ns3/gateway-lora-phy.h"
#include "ns3/lora-mac.h"

namespace ns3 {

  class LoraPhyHelper
  {
  public:

    enum DeviceType
      {
        GW,
        ED
      };

    /**
     * Create a phy helper without any parameter set. The user must set
     * them all to be able to call Install later.
     */
    LoraPhyHelper ();

    /**
     * \param channel the channel to associate to this helper
     *
     * Every PHY created by a call to Install is associated to this channel.
     */
    void SetChannel (Ptr<LoraChannel> channel);

    /**
     * Set the kind of PHY this helper will create
     * \param dt the device type (either gateway or end device)
     */
    void SetDeviceType (enum DeviceType dt);

    /**
     * \param name the name of the attribute to set
     * \param v the value of the attribute
     *
     * Set an attribute of the underlying PHY object.
     */
    void Set (std::string name, const AttributeValue &v);

    /**
     * \param node the node on which we wish to create a wifi PHY
     * \param device the device within which this PHY will be created
     * \returns a newly-created PHY object.
     */
    Ptr<LoraPhy> Create (Ptr<Node> node, Ptr<NetDevice> device) const;

  private:

    ObjectFactory m_phy;
    Ptr<LoraChannel> m_channel;
  };

} //namespace ns3

#endif /* LORA_PHY_HELPER_H */
