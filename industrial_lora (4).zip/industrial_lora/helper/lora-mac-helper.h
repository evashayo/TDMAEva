/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#ifndef LORA_MAC_HELPER_H
#define LORA_MAC_HELPER_H

#include "ns3/net-device.h"
#include "ns3/lora-channel.h"
#include "ns3/lora-phy.h"
#include "ns3/lora-mac.h"
#include "ns3/end-device-lora-mac.h"
#include "ns3/gateway-lora-mac.h"

namespace ns3 {

  class LoraMacHelper
  {
  public:

    enum DeviceType
      {
        GW,
        ED
      };

    /**
     * Create a mac helper without any parameter set. The user must set
     * them all to be able to call Install later.
     */
    LoraMacHelper ();

    /**
     * Set an attribute of the underlying PHY object.
     *
     * \param name the name of the attribute to set
     * \param v the value of the attribute
     */
    void Set (std::string name, const AttributeValue &v);

    /**
     * Set the kind of MAC this helper will create
     *
     * \param dt the device type (either gateway or end device)
     */
    void SetDeviceType (enum DeviceType dt);

    /**
     * \param node the node on which we wish to create a wifi PHY
     * \param device the device within which this PHY will be created
     * \returns a newly-created PHY object.
     */
    Ptr<LoraMac> Create (Ptr<Node> node, Ptr<NetDevice> device) const;

  private:

    ObjectFactory m_mac;
  };

} //namespace ns3

#endif /* LORA_PHY_HELPER_H */
