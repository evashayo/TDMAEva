/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#ifndef SPECTRUM_LORA_PHY_HELPER_H
#define SPECTRUM_LORA_PHY_HELPER_H

#include "lora-phy-helper.h"
#include "ns3/trace-helper.h"

namespace ns3 {

class SpectrumChannel;

/**
 * \brief Make it easy to create and manage PHY objects for the spectrum model.
 *
 */
class SpectrumLoraPhyHelper : public LoraPhyHelper
{
public:

  /**
   * Create a phy helper without any parameter set. The user must set
   * them all to be able to call Install later.
   */
  SpectrumLoraPhyHelper ();

  /**
   * Create a phy helper in a default working state.
   */
  static SpectrumLoraPhyHelper Default (void);

  /**
   * \param channel the channel to associate to this helper
   *
   * Every PHY created by a call to Install is associated to this channel.
   */
  void SetChannel (Ptr<SpectrumChannel> channel);
  
  /**
   * \param channelName The name of the channel to associate to this helper
   *
   * Every PHY created by a call to Install is associated to this channel.
   */
  void SetChannel (std::string channelName);
  
  /**
    * Set the kind of PHY this helper will create
    * \param dt the device type (either gateway or end device)
    */
  void SetDeviceType (enum DeviceType dt);
   
  /**
  * \param name the name of the error rate model to set.
  * \param n0 the name of the attribute to set
  * \param v0 the value of the attribute to set
  * \param n1 the name of the attribute to set
  * \param v1 the value of the attribute to set
  * \param n2 the name of the attribute to set
  * \param v2 the value of the attribute to set
  * \param n3 the name of the attribute to set
  * \param v3 the value of the attribute to set
  * \param n4 the name of the attribute to set
  * \param v4 the value of the attribute to set
  * \param n5 the name of the attribute to set
  * \param v5 the value of the attribute to set
  * \param n6 the name of the attribute to set
  * \param v6 the value of the attribute to set
  * \param n7 the name of the attribute to set
  * \param v7 the value of the attribute to set
  *
  * Set the error rate model and its attributes to use when Install is called.
  */
  void SetErrorRateModel (std::string name,
                          std::string n0 = "", const AttributeValue &v0 = EmptyAttributeValue (),
                          std::string n1 = "", const AttributeValue &v1 = EmptyAttributeValue (),
                          std::string n2 = "", const AttributeValue &v2 = EmptyAttributeValue (),
                          std::string n3 = "", const AttributeValue &v3 = EmptyAttributeValue (),
                          std::string n4 = "", const AttributeValue &v4 = EmptyAttributeValue (),
                          std::string n5 = "", const AttributeValue &v5 = EmptyAttributeValue (),
                          std::string n6 = "", const AttributeValue &v6 = EmptyAttributeValue (),
                          std::string n7 = "", const AttributeValue &v7 = EmptyAttributeValue ());
  
  /**
     * \param node the node on which we wish to create a wifi PHY
     * \param device the device within which this PHY will be created
     * \returns a newly-created PHY object.
     */
  Ptr<LoraPhy> Create (Ptr<Node> node, Ptr<NetDevice> device) const;

private:
  
  ObjectFactory m_phy;
  ObjectFactory m_errorRateModel;
  Ptr<SpectrumChannel> m_channel;
};

} //namespace ns3

#endif /* SPECTRUM_LORA_PHY_HELPER_H */
