/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Davide Magrin <magrinda@dei.unipd.it>
 */

#include "ns3/lora-mac-helper.h"
#include "ns3/log.h"

namespace ns3 {

  NS_LOG_COMPONENT_DEFINE ("LoraMacHelper");

  LoraMacHelper::LoraMacHelper ()
  {
  }

  void
  LoraMacHelper::Set (std::string name, const AttributeValue &v)
  {
    m_mac.Set (name, v);
  }

  void
  LoraMacHelper::SetDeviceType (enum DeviceType dt)
  {
    NS_LOG_FUNCTION (this << dt);
    switch (dt)
      {
      case GW:
        m_mac.SetTypeId ("ns3::GatewayLoraMac");
        break;
      case ED:
        m_mac.SetTypeId ("ns3::EndDeviceLoraMac");
        break;
      }
  }

  Ptr<LoraMac>
  LoraMacHelper::Create (Ptr<Node> node, Ptr<NetDevice> device) const
  {
    Ptr<LoraMac> mac = m_mac.Create<LoraMac> ();
    mac->SetDevice (device);
    return mac;
  }

}

