/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Michele Luvisotto <michele.luvisotto@dei.unipd.it>
 */

#include "ns3/trace-helper.h"
#include "spectrum-lora-phy-helper.h"
#include "ns3/spectrum-channel.h"
#include "ns3/spectrum-end-device-lora-phy.h"
#include "ns3/spectrum-gateway-lora-phy.h"
#include "ns3/names.h"
#include "ns3/log.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("SpectrumLoraPhyHelper");

SpectrumLoraPhyHelper::SpectrumLoraPhyHelper ()
  : m_channel (0)
{
  m_phy.SetTypeId ("ns3::LoraPhy");
  m_errorRateModel.SetTypeId ("ns3::LoraErrorRateModel");
}

SpectrumLoraPhyHelper
SpectrumLoraPhyHelper::Default (void)
{
  SpectrumLoraPhyHelper helper;
  helper.SetErrorRateModel ("ns3::LoraErrorRateModel");			
  return helper;
}

void
SpectrumLoraPhyHelper::SetChannel (Ptr<SpectrumChannel> channel)
{
  m_channel = channel;
}

void
SpectrumLoraPhyHelper::SetChannel (std::string channelName)
{
  Ptr<SpectrumChannel> channel = Names::Find<SpectrumChannel> (channelName);
  m_channel = channel;
}

void
SpectrumLoraPhyHelper::SetDeviceType (enum DeviceType dt)
{

  NS_LOG_FUNCTION (this << dt);
  switch (dt)
    {
    case GW:
      m_phy.SetTypeId ("ns3::SpectrumGatewayLoraPhy");
      break;
    case ED:
      m_phy.SetTypeId ("ns3::SpectrumEndDeviceLoraPhy");
      break;
    }
}

void
SpectrumLoraPhyHelper::SetErrorRateModel (std::string name,
                                      std::string n0, const AttributeValue &v0,
                                      std::string n1, const AttributeValue &v1,
                                      std::string n2, const AttributeValue &v2,
                                      std::string n3, const AttributeValue &v3,
                                      std::string n4, const AttributeValue &v4,
                                      std::string n5, const AttributeValue &v5,
                                      std::string n6, const AttributeValue &v6,
                                      std::string n7, const AttributeValue &v7)
{
  m_errorRateModel = ObjectFactory ();
  m_errorRateModel.SetTypeId (name);
  m_errorRateModel.Set (n0, v0);
  m_errorRateModel.Set (n1, v1);
  m_errorRateModel.Set (n2, v2);
  m_errorRateModel.Set (n3, v3);
  m_errorRateModel.Set (n4, v4);
  m_errorRateModel.Set (n5, v5);
  m_errorRateModel.Set (n6, v6);
  m_errorRateModel.Set (n7, v7);
}

Ptr<LoraPhy>
SpectrumLoraPhyHelper::Create (Ptr<Node> node, Ptr<NetDevice> device) const
{
  NS_LOG_FUNCTION (this << node << device);

  Ptr<LoraPhy> phy = m_phy.Create<LoraPhy> (); 	
  Ptr<LoraErrorRateModel> error = m_errorRateModel.Create<LoraErrorRateModel> ();		
  
  std::string typeId = m_phy.GetTypeId ().GetName ();
  
  if (typeId == "ns3::SpectrumGatewayLoraPhy")
    {
      phy->GetObject<SpectrumGatewayLoraPhy> ()->SetTxPowerdBm (27);
      phy->GetObject<SpectrumGatewayLoraPhy> ()->SetErrorRateModel (error);
      phy->GetObject<SpectrumGatewayLoraPhy> ()->SetChannel (m_channel);
  }
  else if (typeId == "ns3::SpectrumEndDeviceLoraPhy")
    {
      phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SetTxPowerdBm (14);
      phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SetErrorRateModel (error);
      phy->GetObject<SpectrumEndDeviceLoraPhy> ()->CreateLoraEdSpectrumPhyInterface (device);
      phy->GetObject<SpectrumEndDeviceLoraPhy> ()->SetChannel (m_channel);
    }
  phy->SetDevice (device);
  phy->SetMobility (node->GetObject<MobilityModel> ());
  
  return phy;
}

} //namespace ns3
